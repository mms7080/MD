const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const fs = require('fs');
const httpsServer = require('https');
const dotenv = require('dotenv');
const proxyList = JSON.parse(fs.readFileSync('./proxyList.json', {encoding:'utf-8'}));
const privateKey = fs.readFileSync('./privkey.pem', 'utf8');
const certificate = fs.readFileSync('./cert.pem', 'utf8');
const ca = fs.readFileSync('./root-chain-bundle.pem', 'utf8');
const credentials = {
    key: privateKey,
	cert: certificate,
    ca:ca
};
dotenv.config({path:'.env'});
const http = express({xPoweredBy:false});
for(let target of proxyList.http){
    target.middleware = target.target ?
        createProxyMiddleware({target:target.target, changeOrigin:true}) :
        undefined;
}
for(let target of proxyList.https){
    target.middleware = target.target ?
        createProxyMiddleware({target:target.target, changeOrigin:true}) :
        undefined;
}
http.use((req,res,next)=>{
    for(let target of proxyList.http){
        if(req.hostname === target.hostname){
            return target.target ?
                target.middleware(req,res,next) :
                res.redirect(target.redirect);
        }
    }
    res.redirect(process.env.HTTP_DEFAULT);
})
const https = express({xPoweredBy:false});
https.use((req,res,next)=>{
    for(let target of proxyList.https){
        if(req.hostname === target.hostname){
            return target.target ?
                target.middleware(req,res,next) :
                res.redirect(target.redirect);
        }
    }
    res.redirect(process.env.HTTPS_DEFAULT);
})

Promise.all([
    new Promise(resolve=>{http.listen(parseInt(process.env.HTTP_PORT), ()=>console.log(`${process.env.HTTP_PORT} OPEN`)); resolve();}),
    new Promise(resolve=>{httpsServer.createServer(credentials, https).listen(parseInt(process.env.HTTPS_PORT), ()=>console.log(`${process.env.HTTPS_PORT} OPEN`)); resolve();})
]);