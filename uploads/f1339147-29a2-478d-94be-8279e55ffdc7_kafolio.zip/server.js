import https from 'https';
import express from 'express';
import session from 'express-session';
import redis from 'redis';
import connectRedis from 'connect-redis';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import passport from 'passport';
import { Strategy as localS } from 'passport-local';
// import { Strategy as kakaoS } from 'passport-kakao';
// import { Strategy as googleS } from 'passport-google-oauth20';
// import { Strategy as naverS } from 'passport-naver-v2';
import sirv from 'sirv';
import compression from 'compression';
import fs from 'fs';

dotenv.config({path:"./.env", encoding:"UTF-8"});
const app = express({xPoweredBy:false});
app.set('view engine', 'ejs');
app.set('views', 'src/views');

const schemas = {};
const redisClient = redis.createClient({url:process.env.REDIS_URI});
await mongoose.connect(process.env.MONGO_URI, {
    autoIndex:true,
    maxPoolSize:200,
    minPoolSize:50
});
await redisClient.connect();
let models = fs.readdirSync("./src/models", {encoding:"utf-8"});
for(let key of models) schemas[key.replace(".js","")] = mongoose.model(key.replace(".js",""), (await import(`./src/models/${key}`)).default);
app.use(express.json());
app.use(express.raw());
app.use(express.text());
app.use(express.urlencoded({extended:true}));
app.use((req,res,next)=>{
    try { req.body = JSON.parse(req.body); } catch(e) {}
    next();
});
app.use(session({
    secret:process.env.COOKIE_SECRET,
    resave:true,
    saveUninitialized:true,
    rolling:true,
    cookie:{
        maxAge:parseInt(process.env.MAX_AGE),
        secure:false
    },
    store: new connectRedis({
        prefix:"ssid:",
        ttl:parseInt(process.env.MAX_AGE),
        scanCount:100,
        client:redisClient
    })
}));
app.use(cors({
    origin:`${process.env.PROTOCOL}${process.env.DOMAIN}`,
    methods:['get','post','put','delete'],
    allowedHeaders:['Content-Type'],
    exposedHeaders:['Content-Type'],
    maxAge:parseInt(process.env.MAX_AGE)
}));
app.use('/static', express.static('static', {
    dotfiles:'ignore',
    extensions:[],
    fallthrough:true,
    immutable:false,
    maxAge:parseInt(process.env.MAX_AGE),
    index:false,
    redirect:false
}));
app.use('/robots.txt', (req,res,next)=>{
    res.type('text/plain').send(fs.readFileSync('./robots.txt', {encoding:'utf-8'}));
});
app.use((req,res,next)=>{ req.mongo = schemas; next(); });
app.use(passport.initialize());
app.use(passport.session());

passport.use('local', new localS({
    usernameField:"id",
    passwordField:"pw",
    passReqToCallback:true,
}, async (req, id, pw, done)=>{
    try{
        let user = await req.mongo.user.findOne({id:{$regex:new RegExp("^"+req.body.id+"$", 'i')},pw:pw});
        if(user == null) throw new Error("Error");
        done(null, user);
    } catch(e) { done(e); }
}));
// passport.use('kakao', new kakaoS({
//     clientID:process.env.KAKAO_ID,
//     clientSecret:process.env.KAKAO_SECRET,
//     callbackURL:process.env.KAKAO_CALLBACK,
//     passReqToCallback:true
// }, async(req, access, refresh, profile, done)=>{
//     try{
//         // 로그인 관련 기능
//         done(null, undefined /** 유저 정보 */);
//     } catch(e) { done(e); }
// }));
// passport.use('naver', new naverS({
//     clientID:process.env.NAVER_ID,
//     clientSecret:process.env.NAVER_SECRET,
//     callbackURL:process.env.NAVER_CALLBACK,
//     passReqToCallback:true
// }, async(req, access, refresh, profile, done)=>{
//     try{
//         // 로그인 관련 기능
//         done(null, undefined /** 유저 정보 */);
//     } catch(e) { done(e); }
// }));
// passport.use('google', new googleS({
//     clientID:process.env.GOOGLE_ID,
//     clientSecret:process.env.GOOGLE_SECRET,
//     callbackURL:process.env.GOOGLE_CALLBACK,
//     passReqToCallback:true
// }, async(req, access, refresh, profile, done)=>{
//     try{
//         // 로그인 관련 기능
//         done(null, undefined /** 유저 정보 */);
//     } catch(e) { done(e); }
// }));

passport.serializeUser((req, data, done)=>{
    done(null, {id:data.id});
});
passport.deserializeUser((req,data,done)=>{
    done(null, {id:data.id});
});

app.post(process.env.LOCAL_CALLBACK, passport.authenticate('local',{
    successRedirect:process.env.REFRESH,
    failureRedirect:process.env.LOGIN
}));

// app.get(process.env.NAVER_CALLBACK, passport.authenticate('naver',{
//     successRedirect:process.env.HOME,
//     failureRedirect:process.env.LOGIN
// }));
// app.get(process.env.KAKAO_CALLBACK, passport.authenticate('kakao',{
//     successRedirect:process.env.HOME,
//     failureRedirect:process.env.LOGIN
// }));
// app.get(process.env.GOOGLE_CALLBACK, passport.authenticate('google',{
//     successRedirect:process.env.HOME,
//     failureRedirect:process.env.LOGIN,
//     scope:['profile','email']
// }));

const templateBuild = process.env.TYPE == 'dev' ?
    undefined : 
    fs.readFileSync('./dist/client/index.html', {encoding:"utf-8"});
const ssrManifest = process.env.TYPE == 'dev' ?
    undefined : 
    fs.readFileSync('./dist/client/.vite/ssr-manifest.json', {encoding:"utf-8"});
const renderBuild = process.env.TYPE == 'dev' ?
    undefined :
    (await import("./dist/server/index-server.js")).render;
const vite = process.env.TYPE != 'dev' ?
    undefined :
    await (await import('vite')).createServer({
        server:{
            middlewareMode:true,
            watch:{
                usePolling:true,
                interval:1000
            }
        },
        appType:"custom",
        base: process.env.APP_BASE
    });

if(process.env.TYPE == 'dev') app.use(process.env.APP_BASE, vite.middlewares);
else {
    app.use(compression());
    app.use(sirv('./dist/client', {extensions:[]}));
}

app.use(process.env.APP_BASE, async (req,res,next)=>{
    try{
        const url = req.originalUrl;
        let template = process.env.TYPE == 'dev' ?
            await vite.transformIndexHtml(url, fs.readFileSync('./index.html', {encoding:"utf-8"})) :
            templateBuild;
        let render = process.env.TYPE == 'dev' ?
            (await vite.ssrLoadModule('./src/index-server.jsx')).render :
            renderBuild;
        res.status(200).set({'Content-Type':'text/html'}).send(
            template.replace(
                process.env.CONTAINER_HOLDER,
                (await render(url, ssrManifest)).html
            )
        );
    } catch(e){ next(new Error('react')); }
});

let postLogics = fs.readdirSync("./src/logic/post", {encoding:"utf-8", recursive:true, withFileTypes:true}).filter(p=>p.isFile()).map(p=>`${p.path}/${p.name}`.replaceAll("\\","/").replace(/^src\/logic/,"./src/logic").replace("./src/logic/post/",""));
let getLogics = fs.readdirSync("./src/logic/get", {encoding:"utf-8", recursive:true, withFileTypes:true}).filter(p=>p.isFile()).map(p=>`${p.path}/${p.name}`.replaceAll("\\","/").replace(/^src\/logic/,"./src/logic").replace("./src/logic/get/",""));
for(let key of postLogics){
    const logic = (await import(`./src/logic/post/${key}`)).default;
    if(Array.isArray(logic))
        app.post(process.env.API_BASE + `/${key.replace(".js","")}`,  ...logic);
    else
        app.post(process.env.API_BASE + `/${key.replace(".js","")}`, logic);
}
for(let key of getLogics){
    const logic = (await import(`./src/logic/get/${key}`)).default;
    if(Array.isArray(logic))
        app.get(process.env.API_BASE + `/${key.replace(".js","")}`, ...logic);
    else
        app.get(process.env.API_BASE + `/${key.replace(".js","")}`, logic);
}

app.use((req,res,next)=>{
    res.redirect(process.env.APP_BASE);
});

app.use((err,req,res,next)=>{
    if(err.message == 'react'){
        setTimeout(()=>{
            res.redirect(process.env.APP_BASE);
        }, 100);
    }
    else { res.redirect(process.env.APP_BASE); }
})

if(process.env.PROTOCOL.startsWith("https")){
    const httpsOption = {
        key:fs.readFileSync(process.env.KEY),
        cert:fs.readFileSync(process.env.CERT),
        ca:fs.readFileSync(process.env.CHAIN)
    };
    const server = https.createServer(httpsOption, app);
    server.listen(process.env.PORT, ()=>{
        console.log(`Port ${process.env.PORT} server open!`);
    })
}
else{
    app.listen(process.env.PORT, ()=>{
        console.log(`Port ${process.env.PORT} server open!`);
    })
}
