/** @type {import('tailwindcss').Config} */
export default {
    content: ['./src/**/*.jsx'],
    safelist:[
      {
        pattern:/text-[a-zA-Z]*-\d*/
      },
      {
        pattern:/text-(11|10|9|8|7)xl/
      },
      {
        pattern:/bg-[a-zA-Z]*/
      },
      {
        pattern:/text-[a-zA-Z]*/
      },
      {
        pattern:/border-[a-zA-Z]*-\d*/
      },
    ],
    theme: {
      extend: {
        colors:{},
        spacing:{},
        typography:{},
        border:{},
        opacity:{},
        zIndex:{},
        screens:{},
        fontSize:{
          '10xl':'9rem',
          '11xl':'10rem'
        },
        rotate:{
          '0':'0deg',
          '1':'30deg',
          '2':'60deg',
          '3':'90deg',
          '4':'120deg',
          '5':'150deg',
          '6':'180deg',
          '7':'210deg',
          '8':'240deg',
          '9':'270deg',
          '10':'300deg',
          '11':'330deg',
        }
    },
    variants:{
      extend:{
      }
    },
    plugins: [],
  }
}
  
  