export default (req,res,next)=>{
    if(req.user) next();
    else next(new Error('Error'));
}