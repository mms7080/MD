export default async (req,res,next)=>{
    if(!req.user) next(new Error('Error'));
    const user = await req.mongo.user.findOne({id:{$regex:new RegExp("^"+req.user.id+"$", 'i')}});
    if(user.role != 'admin') next(new Error('Error'));
    next();
}