(await import("dotenv")).default.config({path:'./.env'});
export default [
    (await import("./../../logistic/logincheck.js")).default,
        async (req,res,next)=>{
        const user = await req.mongo.user.findOne({id:{$regex:new RegExp("^"+req.user.id+"$", 'i')}});
        user.name = req.body.name;
        await user.save();
        res.redirect(process.env.MYPAGE);
    }
]