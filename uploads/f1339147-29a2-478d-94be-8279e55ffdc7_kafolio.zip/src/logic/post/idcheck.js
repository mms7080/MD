(await import("dotenv")).default.config({path:'./.env'});
function idcheck(id){
    if(
        id == undefined ||
        id.length < 6 ||
        id.length > 20 ||
        id.search(/[^a-zA-Z0-9_]/) > -1
    ) return false;
    return true;
}
export default async (req,res,next)=>{
    if(idcheck(req.body.id)){
        const user = await req.mongo.user.findOne({id:{$regex:new RegExp("^"+req.body.id+"$", 'i')}});
        res.status(200).send({message : user == null ? true : false});
    }
    else res.status(200).send({message : false});
};