(await import("dotenv")).default.config({path:'./.env'});
function idcheck(id){
    if(
        id == undefined ||
        id.length < 6 ||
        id.length > 20 ||
        id.search(/[^a-zA-Z0-9_]/) > -1
    ) return false;
    return true;
}
function emailcheck(email){
    if(!/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i.test(email)) return false;
    return true;
}
export default [
    (await import("./../../logistic/logoutcheck.js")).default,
    async (req,res,next)=>{
        try{
            if(!idcheck(req.body.id) || !(req.body.email && emailcheck(req.body.email))) throw new Error("Error");
            const user = new req.mongo.user();
            user.id = req.body.id;
            user.pw = req.body.pw;
            user.email = req.body.email;
            user.name = req.body.name;
            await user.save();
            res.redirect(process.env.LOGIN);
        } catch (e){ res.redirect(process.env.SIGNUP); }
    }
]