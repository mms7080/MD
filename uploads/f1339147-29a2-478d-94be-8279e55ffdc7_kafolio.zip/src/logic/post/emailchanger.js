(await import("dotenv")).default.config({path:'./.env'});
function emailcheck(email){
    if(!/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i.test(email)) return false;
    return true;
}
export default [
    (await import("./../../logistic/logincheck.js")).default,
    async (req,res,next)=>{
        if(emailcheck(req.body.email)){
            const user = await req.mongo.user.findOne({id:{$regex:new RegExp("^"+req.user.id+"$", 'i')}});
            user.email = req.body.email;
            await user.save();
        }
        res.redirect(process.env.MYPAGE);
    }
]