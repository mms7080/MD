import mongoose from 'mongoose';
(await import("dotenv")).default.config({path:'./.env'});
export default [
    (await import("../../logistic/logincheck.js")).default,
    async (req,res,next)=>{
        try{
            const request = await req.mongo.request.findOne({owner:{$regex:new RegExp("^"+req.user.id+"$", 'i')}, _id:new mongoose.Types.ObjectId(req.body.id)});
            request.isrequest = request.isrequest ? false : true;
            await request.save();
            res.status(200).send("Succeed!");
        } catch(e){ next(new Error("error")); }
    }
]