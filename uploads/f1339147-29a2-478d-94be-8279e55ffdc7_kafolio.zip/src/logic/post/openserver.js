import mongoose from 'mongoose';
(await import("dotenv")).default.config({path:'./.env'});
export default [
    (await import("../../logistic/admincheck.js")).default,
    async (req,res,next)=>{
        const request = await req.mongo.request.findOne({_id:new mongoose.Types.ObjectId(req.body.id)});
        request.isopen = true;
        request.link = req.body.url;
        request.isrequest = false;
        await request.save();
        res.status(200).send("Succeed");
    }
]