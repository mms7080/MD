import mongoose from 'mongoose';
(await import("dotenv")).default.config({path:'./.env'});
export default [
    async (req,res,next)=>{
        if(!req.body.id) return res.redirect(process.env.REQUEST);
        try{
            let request = await req.mongo.request.findOne({owner:req?.user?.id,_id:new mongoose.Types.ObjectId(req.body.id)});
            if(!request){ 
                request = await req.mongo.request.findOne({_id:new mongoose.Types.ObjectId(req.body.id)});
                return res.send({
                    tools:request.tools,
                    language:request.language,
                    views:request.views,
                    like:request.like,
                    name:request.name,
                    boards:request.boards,
                    teamnames:request.teamnames,
                    teamroles:request.teamroles,
                    link:request.link,
                    owner:request.owner,
                    writedate:request.writedate,
                    alterdate:request.alterdate,
                    altercount:request.altercount,
                    icon:request.icon,
                    fileoriginal:request.fileoriginal,
                    file:request.file,
                    name:request.name,
                });
            }
            else
            res.send({
                isopen:request.isopen,
                isrequest:request.isrequest,
                tools:request.tools,
                language:request.language,
                views:request.views,
                like:request.like,
                name:request.name,
                boards:request.boards,
                teamnames:request.teamnames,
                teamroles:request.teamroles,
                link:request.link,
                owner:request.owner,
                writedate:request.writedate,
                alterdate:request.alterdate,
                altercount:request.altercount,
                icon:request.icon,
                fileoriginal:request.fileoriginal,
                readme:request.readme,
                readmeoriginal:request.readmeoriginal,
                file:request.file,
                name:request.name,
            });
        } catch(e){res.redirect(process.env.REQUEST);}
    }
]