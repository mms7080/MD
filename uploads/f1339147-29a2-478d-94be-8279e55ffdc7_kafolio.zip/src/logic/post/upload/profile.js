import multer from 'multer';
import fs from 'fs';
import pkg from 'crypto-js';
const { SHA256 } = pkg;
(await import("dotenv")).default.config({path:'./.env'});
const profileUploader = multer({
    storage:multer.diskStorage({
        destination:(req,file,done)=>{
            let now = new Date();
            if(!fs.existsSync(`static/profile/${now.getFullYear()}/${now.getMonth() + 1}/${now.getDate()}`))
                fs.mkdirSync(`static/profile/${now.getFullYear()}/${now.getMonth() + 1}/${now.getDate()}`, {recursive:true});
            done(null, `static/profile/${now.getFullYear()}/${now.getMonth() + 1}/${now.getDate()}`);
        },
        filename:(req,file,done)=>{
            if(!['.jpg','.jpeg','.png','.gif','.webp','.bmp','.jfjf'].includes(file.originalname.slice(file.originalname.lastIndexOf('.')))) return done(new Error('Error'));
            done(null, 
                btoa(SHA256(`${new Date().toJSON()}${file.originalname}${process.env.COOKIE_SECRET}`)) + 
                file.originalname.slice(file.originalname.lastIndexOf('.'))
            )
        }
    })
});

export default [
    (req,res,next)=>{ req.body = JSON.parse(JSON.stringify(req.body)); next(); },
    (await import("./../../../logistic/logincheck.js")).default, profileUploader.single('profile'),
    async (req,res,next)=>{
        const user = await req.mongo.user.findOne({id:req.user.id});
        user.profile = req.file.path.replaceAll("\\","/").startsWith("/") ? req?.file?.path?.replaceAll("\\","/") : "/" + req?.file?.path?.replaceAll("\\","/");
        await user.save();
        res.redirect(process.env.MYPAGE);
    }
]