import multer from 'multer';
import fs from 'fs';
import mongoose from 'mongoose';
import pkg from 'crypto-js';
const { SHA256 } = pkg;
(await import("dotenv")).default.config({path:'./.env'});
const requestUploader = multer({
    storage:multer.diskStorage({
        destination:(req,file,done)=>{
            let now = new Date();
            if(!fs.existsSync(`static/requests/${now.getFullYear()}/${now.getMonth() + 1}/${now.getDate()}/${file.fieldname}`))
                fs.mkdirSync(`static/requests/${now.getFullYear()}/${now.getMonth() + 1}/${now.getDate()}/${file.fieldname}`, {recursive:true});
            done(null, `static/requests/${now.getFullYear()}/${now.getMonth() + 1}/${now.getDate()}/${file.fieldname}`);
        },
        filename:(req,file,done)=>{
            if(
                file.fieldname == 'boards' &&
                !['.jpg','.jpeg','.png','.gif','.webp','.bmp','.jfjf'].includes(file.originalname.slice(file.originalname.lastIndexOf('.')))
            ) return done(new Error('Error'));
            if(
                file.fieldname == 'icon' &&
                !['.jpg','.jpeg','.png','.gif','.webp','.bmp','.jfjf'].includes(file.originalname.slice(file.originalname.lastIndexOf('.')))
            ) return done(new Error('Error'));
            done(null, 
                btoa(SHA256(`${new Date().toJSON()}${file.originalname}${process.env.COOKIE_SECRET}`)) + 
                file.originalname.slice(file.originalname.lastIndexOf('.'))
            )
        }
    })
});

export default [
    (await import("./../../../logistic/logincheck.js")).default, 
    (req,res,next)=>{ req.body = JSON.parse(JSON.stringify(req.body)); next(); },
    requestUploader.fields([
        {name:'readme',maxCount:1},
        {name:'file',maxCount:1},
        {name:'icon',maxCount:1},
        {name:'boards',maxCount:50}
    ]),
    async (req,res,next)=>{
        try{
            let request = null;
            if(req.body.before){ 
                request = await req.mongo.request.findOne({owner:req.user.id,_id:new mongoose.Types.ObjectId(req.body.before)});
                request.altercount += 1;
                request.alterdate = Date.now();
            }
            else request = new req.mongo.request();
            request.owner = req.user.id;
            request.name = req.body.name || "Project";
            if(req.files?.boards?.length) request.boards = req?.files?.boards?.map(v=>v.path.replaceAll("\\","/")).map(v=>v.startsWith("/") ? v : "/" + v) || [];
            if(req.files?.icon?.length) request.icon = req?.files?.icon[0]?.path.replaceAll("\\","/").startsWith("/") ? req?.files?.icon[0]?.path.replaceAll("\\","/") : "/" + req?.files?.icon[0]?.path.replaceAll("\\","/") || "";
            if(req.files?.file?.length) {
                request.file = req?.files?.file[0]?.path.replaceAll("\\","/").startsWith("/") ? req?.files?.file[0]?.path.replaceAll("\\","/") : "/" + req?.files?.file[0]?.path.replaceAll("\\","/") || "";
                request.fileoriginal = Buffer.from(req?.files?.file[0]?.originalname, 'latin1').toString("utf8");
            }
            if(req.files?.readme?.length){
                request.readme = req?.files?.readme[0]?.path.replaceAll("\\","/").startsWith("/") ? req?.files?.readme[0]?.path.replaceAll("\\","/") : "/" + req?.files?.readme[0]?.path.replaceAll("\\","/") || "";
                request.readmeoriginal = Buffer.from(req?.files?.readme[0].originalname, 'latin1').toString("utf8");
            }
            request.language = Array.from(new Set(req.body.language.toUpperCase().split(" ").flatMap(v=>v)));
            request.tools = Array.from(new Set(req.body.tools.toUpperCase().split(" ").flatMap(v=>v)));
            let i = 1;
            const names = [], roles = [];
            while(true){
                if(!req.body[`team${i}name`]) break;
                names.push(req.body[`team${i}name`]);
                roles.push(req.body[`team${i}job`]);
                i += 1;
            }
            request.teamnames = names;
            request.teamroles = roles;
            await request.save();
            res.redirect(process.env.REQUEST);
        } catch (e){ res.redirect(process.env.HOME); }
    }
]