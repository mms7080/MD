(await import("dotenv")).default.config({path:'./.env'});
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}
export default [
    async (req,res,next)=>{
        try{
            let requests = 
            req.body.ismine ?
            await req.mongo.request.find({owner:{$regex:new RegExp("^"+req.user.id+"$", 'i')}}) :
            await req.mongo.request.find({isopen:true});
            requests = req.body.random ? shuffleArray(requests) : requests.sort((a,b)=>b.writedate - a.writedate);
            requests = req.body.slice ? requests.slice(0, parseInt(req.body.slice)) : requests;
            res.send(
                requests ?
                requests.map(request=>{
                    return {
                        link:request._id,
                        name:request.name,
                        mainsrc:request?.boards?.at(0) || "",
                        iconsrc:request?.icon,
                        language:request.language,
                        tools:request.tools,
                        views:request.views,
                        like:request.like,
                        isopen:`${request.isopen}`,
                        isrequest:`${request.isrequest}`
                    }
                }) : []);
        } catch(e){ next(new Error("error")); }
    }
]