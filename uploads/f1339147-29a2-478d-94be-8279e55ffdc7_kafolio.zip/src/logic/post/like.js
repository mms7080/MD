import mongoose from 'mongoose';
(await import("dotenv")).default.config({path:'./.env'});
export default [
    (await import("./../../logistic/logincheck.js")).default,
    async (req,res,next)=>{
        if(!req.body.id) return next(new Error("Error"));
        const like = await req.mongo.like.findOne({id:req.user.id, folio:req.body.id});
        if(like) return res.status(200).send({message:false});
        else {
            const request = await req.mongo.request.findOne({_id:new mongoose.Types.ObjectId(req.body.id)});
            request.like += 1;
            const newlike = new req.mongo.like();
            newlike.id = req.user.id;
            newlike.folio = req.body.id;
            await newlike.save();
            await request.save();
            res.status(200).send({message:true});
        }
    }
]