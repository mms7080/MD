(await import("dotenv")).default.config({path:'./.env'});
export default [
    (await import("./../../logistic/logincheck.js")).default,
    async (req,res,next)=>{
        if(req.logout) req.logout(()=>{});
        req.session.destroy();
        res.redirect(`${process.env.API_BASE}/refresh`);
    }
]