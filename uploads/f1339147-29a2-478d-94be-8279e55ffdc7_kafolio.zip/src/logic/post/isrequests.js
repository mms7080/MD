(await import("dotenv")).default.config({path:'./.env'});
export default [
    (await import("../../logistic/admincheck.js")).default,
    async (req,res,next)=>{
        const requests = await req.mongo.request.find({isrequest:true});
        res.send(
            requests ?
            requests.map(request=>{
                return {
                    id:request._id,
                    link:request.link,
                    name:request.name,
                    file:request.file,
                    readme:request.readme,
                    isopen:request.isopen,
                }
            }) : []);
    }
]