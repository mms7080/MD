(await import("dotenv")).default.config({path:'./.env'});
export default async (req,res,next)=>{
    const response = (data)=>{ res.send(JSON.stringify(data)); }
    let user = null;
    switch(req.query.type){
        case 'login': return response({"message" : {
            isLogin: req.user != null ? true : false,
            isAdmin: req.user != null ? (await req.mongo.user.findOne({id:{$regex:new RegExp("^"+req.user.id+"$", 'i')}})).role == 'admin' : false,
        }});
        case 'user': 
        if(!req.user) return response({'message':'error'});
        user = await req.mongo.user.findOne({id:{$regex:new RegExp("^"+req.user.id+"$", 'i')}});
        return response({'message' : {
            id: user.id,
            signupdate : user.signupdate,
            email: user.email,
            name: user.name,
            profile: user.profile
        }});
    }
}