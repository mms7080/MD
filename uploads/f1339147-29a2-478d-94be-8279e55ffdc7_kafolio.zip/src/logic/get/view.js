import mongoose from 'mongoose';
(await import("dotenv")).default.config({path:'./.env'});
export default [
    async (req,res,next)=>{
        if(!req.query.id) return next(new Error("Error"));
        const view = await req.mongo.view.findOne({sid:req.sessionId, folio:req.query.id});
        if(view) {
            if(view.removeview.getTime() < new Date().getTime() - 1000 * 60 * 60){
                const request = await req.mongo.request.findOne({_id:new mongoose.Types.ObjectId(req.query.id)});
                request.views += 1;
                view.removeview = new Date();
                await view.save();
                await request.save();    
            }
        }
        else {
            const request = await req.mongo.request.findOne({_id:new mongoose.Types.ObjectId(req.query.id)});
            request.views += 1;
            const newview = new req.mongo.view();
            newview.sid = req.sessionId;
            newview.folio = req.query.id;
            await newview.save();
            await request.save();
        }
        res.status(200).send({message:"success"});
    }
]