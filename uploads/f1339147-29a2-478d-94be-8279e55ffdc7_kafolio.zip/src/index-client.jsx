import React from 'react';
import { hydrateRoot } from 'react-dom/client';
import { ChakraProvider } from '@chakra-ui/react';
import { BrowserRouter } from 'react-router-dom';
import { useStatic } from './hook/index';
import App from './component/app';
import './index.css';

function Output(){
    return <BrowserRouter basename='/app'>
        <ChakraProvider>
            <useStatic.Provider value={{}}>
                <App/>
            </useStatic.Provider>
        </ChakraProvider>
    </BrowserRouter>
}

hydrateRoot(
    document.querySelector("#root"),
    <Output/>
)