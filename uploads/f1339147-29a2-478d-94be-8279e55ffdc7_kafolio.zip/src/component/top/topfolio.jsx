import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ViewIcon, StarIcon } from '@chakra-ui/icons';
import { useInfo } from '../../hook';

const n2s = (number)=>{
    const sizes = ['','K','M','G','T','P','E','Z','Y'];
    let index = 0;
    while(number > 1000) {
        number = parseInt((number / 1000) * 10) / 10;
        index += 1;
    }
    return `${number}${sizes[index]}`;
};

const n2s2 = (number)=>{
    return `${number}`.replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
}

export default ({target})=>{
    let polios = useInfo({method:'post', url:'/requests', def:[], ismine:false});
    const vu = (a,b)=>b.views-a.views;
    const lu = (a,b)=>b.like-a.like;
    const navigation = useNavigate();
    return <div>
        <div className='grid grid-cols-3 gap-6'>
            {
                polios.sort((a,b)=>{
                        let result = target == "view" ? vu(a,b) : lu(a,b);
                        if(result == 0) return target == "view" ? lu(a,b) : vu(a,b);
                        return result;
                    }).slice(0,3).map((v,index)=>
                        <div key={index} className='cursor-pointer' onClick={()=>navigation(`/folio/${v.link}`)}>
                            <div className='w-full h-[36rem] rounded-xl overflow-hidden'>
                                <img className='w-full h-full object-cover' src={v.mainsrc} loading="lazy"/>
                            </div>
                            <div className='mt-3'>
                                <div className='rounded-full overflow-hidden inline-block'>
                                    <img className='w-24 h-24 object-cover' src={v.iconsrc} loading="lazy"/>
                                </div>
                                <div className='grid grid-rows-3 gap-3 w-[70%] float-right mr-5'>
                                    <div className='m-auto'>
                                        <span className='top-[0.1rem] relative font-bold'>{v.name}</span>
                                    </div>
                                    <div className='m-auto'>
                                        <span className='top-[0.1rem] mr-1 relative font-bold'>{n2s2(v.views)}</span>
                                        <ViewIcon/>
                                    </div>
                                    <div className='m-auto'>
                                        <span className='top-[0.1rem] mr-1 relative font-bold'>{n2s2(v.like)}</span>
                                        <StarIcon/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )
            }
        </div>
        <div className='grid grid-cols-5 gap-6 mt-8'>
            {
                polios.sort((a,b)=>{
                    let result = target == "view" ? vu(a,b) : lu(a,b);
                    if(result == 0) return target == "view" ? lu(a,b) : vu(a,b);
                    return result;
                }).slice(3).map((v,index)=>
                    <div key={index} className='h-[28rem] cursor-pointer' onClick={()=>navigation(`/folio/${v.link}`)}>
                        <div className='w-full h-96 rounded-xl overflow-hidden'>
                            <img className='w-full h-full object-cover' src={v.mainsrc}/>
                        </div>
                        <div className='mt-3'>
                            <div className='rounded-full overflow-hidden inline-block'>
                                <img className='w-8 h-8 object-cover' src={v.iconsrc}/>
                            </div>
                            <div className='ml-2 inline-block font-semibold text-xs relative -top-[0.6rem]'>{v.name}</div>
                            <div className='inline-block float-right relative top-1'>
                                <ViewIcon/>
                                <div className='mx-2 inline-block font-semibold text-xs'>{n2s(v.views)}</div>
                                <StarIcon/>
                                <div className='mx-2 inline-block font-semibold text-xs'>{n2s(v.like)}</div>
                            </div>
                        </div>
                    </div>
                )
            }
        </div>
    </div>
}