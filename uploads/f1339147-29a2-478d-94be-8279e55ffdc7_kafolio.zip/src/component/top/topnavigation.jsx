import React from 'react';
import { Image, Tabs, TabList, Tab, TabIndicator } from '@chakra-ui/react';

export default ({navIndex, navIndexChanger})=>{
    return <Tabs 
        variant="unstyled" 
        isFitted
        mb="2.5rem"
        index={navIndex} 
        onChange={navIndexChanger}
    >
        <TabList>
            <Tab fontWeight="600">VIEW</Tab>
            <Tab fontWeight="600">LIKE</Tab>
        </TabList>
        <TabIndicator 
            mt="0.5rem"
            height="2px"
            bg="black"
            borderRadius="1px"
        />
    </Tabs>
}