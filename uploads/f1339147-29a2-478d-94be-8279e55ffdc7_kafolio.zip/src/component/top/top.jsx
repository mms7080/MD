import React, { useState } from 'react';
import Topfolio from './topfolio';
import Navigation from './topnavigation';

export default ()=>{
    const [navIndex, navIndexChanger] = useState(0);
    return <div className='mx-16 mt-5'>
        <div className='sticky top-14 bg-white h-14 z-40'>
            <Navigation navIndex={navIndex} navIndexChanger={navIndexChanger}/>
        </div>
        <Topfolio target={
            navIndex == 0 ? 'view' : 'like'
        }/>
    </div>
}