import React, { useState } from 'react';
import { Routes, Route, Outlet, useNavigate } from 'react-router-dom';
import Navigation from './navigation';
import Home from './home/home';
import Top from './top/top';
import Detail from './detail/detail';
import Signup from './signup/signup';
import Login from './login/login';
import Mypage from './mypage/mypage';
import RequestList from './request/requestlist';
import RequestWrite from './request/requestwrite';
import RequestAlter from './request/requestalter';
import Requestfolio from './folio/requestfolio';
import Dashboard from './dashboard/dashboard';
import Openfolio from './folio/openfolio';

export default ()=>{
    const [navIndex, navIndexChanger] = useState(-1);
    const navigate = useNavigate();
    return <div>
        <Navigation navIndex={navIndex} navIndexChanger={(index)=>{
            navIndexChanger(index);
            navigate(
                index == 0 ? "/" :
                index == 1 ? "/top" : 
                index == 2 ? "/detail" : 
                index == 3 ? "/request/list" : 
                index == 4 ? "/dashboard" : 
                index == 66 ? "/mypage" :
                index == 77 ? "/login" :
                index == 88 ? "/signup" : "/"
            )
        }}/>
        <Routes>
            <Route path="/" element={<Home/>}/>
            <Route path="/top" element={<Top/>}/>
            <Route path="/detail" element={<Detail/>}/>
            <Route path="/login" element={<Login/>}/>
            <Route path="/signup" element={<Signup/>}/>
            <Route path="/mypage" element={<Mypage/>}/>
            <Route path="/request" element={<Outlet/>}>
                <Route path="write" element={<RequestWrite/>}/>
                <Route path="list" element={<RequestList/>}/>
                <Route path=":id" element={<Requestfolio/>}/>
                <Route path="alter/:id" element={<RequestAlter/>}/>
            </Route>
            <Route path="/dashboard" element={<Dashboard/>}/>
            <Route path="/folio/:id" element={<Openfolio/>}/>
        </Routes>
    </div>
}