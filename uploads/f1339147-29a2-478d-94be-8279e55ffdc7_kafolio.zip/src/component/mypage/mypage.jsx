import React, { useState } from 'react';
import { Divider, useDisclosure, Button, Input } from '@chakra-ui/react';
import { useInfo } from '../../hook';
import Modal from '../modal';
import Dropzone from "../dropzone";

const dateFormat = (date)=>{
    return `${date.getFullYear()}년 ${date.getMonth() + 1}월 ${date.getDate()}일`
}

export default ()=>{
    const [isOver, isOverChanger] = useState(false);
    const [modalIndex, modalIndexChanger] = useState(0);
    const {isOpen, onOpen, onClose} = useDisclosure();
    const openModal = (index)=>{
        modalIndexChanger(index);
        onOpen();
    }
    const user = useInfo({type:'user'})?.message;
    return <div className='mx-auto w-[40rem] mt-8 border-2 border-gray-200 rounded-md p-6'>
        <Modal 
            isCentered 
            onClose={onClose} 
            isOpen={isOpen} 
            motionPreset="slideInBottom"
            header={
                modalIndex == 0 ? "프로필 변경" :
                modalIndex == 1 ? "이메일 변경" :
                modalIndex == 2 ? "이름 변경" : undefined
            }
        >
            {
                modalIndex == 0 ?
                <Dropzone text="드래그 & 드랍" 
                    action='/api/upload/profile'
                    onDragEnter={()=>isOverChanger(true)}
                    onDragLeave={()=>isOverChanger(false)}
                    onDragOver={()=>isOverChanger(true)}
                    onDragDrop={()=>isOverChanger(false)}
                    onSubmit={onClose}
                    previewType='img'
                    requireFile={1}
                    beforePreview={(file, index)=>
                        <img key={index}
                            className='mx-auto w-[25rem] mb-6'
                            src={file} loading="lazy"
                        />
                    }
                    name='profile'
                    className={`mb-6 block px-20 py-2 text-center border-dashed border-2 rounded-lg border-${isOver ? 'green' : 'gray'}-300 text-${isOver ? 'green' : 'gray'}-400 text-xl`}>
                    <Button mb="1rem" w="100%" type="submit">변경</Button>
                </Dropzone>
                : <form action={
                        modalIndex == 1 ? '/api/emailchanger' : 
                        modalIndex == 2 ? "/api/namechanger" : 
                        undefined 
                    } method="post">
                    <Input name={
                        modalIndex == 1 ? "email" :
                        modalIndex == 2 ? "name" :
                        undefined
                    }/>
                    <Button  mb="1rem" w="100%" type="submit">변경</Button>
                </form>
            }
        </Modal>
        <div className="w-44 rounded-full overflow-hidden left-1/2 relative -translate-x-1/2 cursor-pointer">
            <img src={user?.profile ? user?.profile : '/static/profile.jpg'} loading="lazy" onClick={()=>openModal(0)}/>
        </div>
        <div className='mt-6 grid grid-cols-12'>
            <div className='grid grid-cols-1 gap-3 col-span-2'>
                {
                    ["ID", "E-Mail", "NAME", "Signup"].map((v,index)=>
                        <div key={index} className='text-center'>
                            {v}
                        </div>
                    )
                }
            </div>
            <Divider orientation='vertical' gridColumn="span 1"/>
            <div className='grid grid-cols-1 gap-3 col-span-9'>
                <div className='text-center'>
                    {user?.id}
                </div>
                <div className='text-center cursor-pointer' onClick={()=>openModal(1)}>
                    {user?.email ? user?.email : "Unknown"}
                </div>
                <div className='text-center cursor-pointer' onClick={()=>openModal(2)}>
                    {user?.name ? user?.name : "Unknown"}
                </div>
                <div className='text-center'>
                    {dateFormat(new Date(user?.signupdate))}
                </div>
            </div>
        </div>
    </div>
}