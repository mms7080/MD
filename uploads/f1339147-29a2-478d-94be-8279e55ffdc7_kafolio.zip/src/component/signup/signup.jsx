import React, { useState, useEffect } from 'react';
import { FormControl, FormLabel, FormHelperText, InputLeftElement, Input, InputGroup, InputRightElement, Button, Divider } from '@chakra-ui/react';
import { ViewIcon, ViewOffIcon, CloseIcon, CheckCircleIcon } from '@chakra-ui/icons';
import pkg from 'crypto-js';
import { useInfo } from '../../hook/index';
const { SHA512 } = pkg;

export default ()=>{
    const [psdShow, psdShowChanger] = useState(false);
    const [idcheck, idcheckChanger] = useState(false);
    const [pscheck, pscheckChanger] = useState(false);
    const [pw, pwChanger] = useState('');
    const passwordcheck = (ps)=>{
        if(
            ps == undefined ||
            ps.length < 6 ||
            ps.length > 20 ||
            ps.search(/[a-z]/) < 0 ||
            ps.search(/[A-Z]/) < 0 ||
            ps.search(/\d/) < 0
        ) return false;
        return true;
    }
    return <div className='mx-auto w-[40rem] mt-8 border-2 border-gray-200 rounded-md p-6'>
        <form action="/api/signup" method="post">
            <FormControl isRequired>
                <FormLabel>ID</FormLabel>
                <InputGroup>
                    <Input variant="flushed" type="text" name="id" onChange={async (e)=>{
                        const result = await fetch('/api/idcheck',{method:"post", body:JSON.stringify({id:e.currentTarget.value})}).then(v=>v.json());
                        idcheckChanger(result.message);
                    }}/>
                    <InputRightElement>
                        {
                            idcheck ? 
                            <CheckCircleIcon color="green"/> :
                            <CheckCircleIcon color="red"/>
                        }
                    </InputRightElement>
                </InputGroup>
                <FormHelperText> * 6 - 20 글자</FormHelperText>
            </FormControl>
            <Input name="pw" defaultValue={pw} hidden/>
            <FormControl isRequired>
                <FormLabel>Password</FormLabel>
                <InputGroup>
                    <InputLeftElement>
                        <Button onClick={()=>psdShowChanger(!psdShow)}>
                            { psdShow ? <ViewIcon/> : <ViewOffIcon/> }
                        </Button>
                    </InputLeftElement>
                    <Input 
                        variant="flushed" 
                        type={psdShow ? "text" : "password"}
                        name="pw_in" onChange={async (e)=>{
                            pscheckChanger(passwordcheck(e.currentTarget.value));
                            pwChanger(SHA512(e.currentTarget.value).toString());
                        }}
                    />
                    <InputRightElement>
                        {
                            pscheck ? 
                            <CheckCircleIcon color="green"/> :
                            <CheckCircleIcon color="red"/>
                        }
                    </InputRightElement>
                </InputGroup>
                <FormHelperText> * 6 - 20 글자(대소문자, 숫자 포함)</FormHelperText>
            </FormControl>
            <FormControl>
                <FormLabel>Name</FormLabel>
                <Input variant="flushed" type="text" name="name"/>
            </FormControl>
            <FormControl>
                <FormLabel>E-mail</FormLabel>
                <Input variant="flushed" type="email" name="email"/>
            </FormControl>
            <Button type="submit" mt="1rem" w="100%" isDisabled={!(idcheck && pscheck)}>
                회원가입
            </Button>
        </form>
        {/* <Divider mt="1rem"/>
        <div className='grid grid-cols-3 gap-6 mt-4'>
            <form action="/oauth/naver" method="get" className="cursor-pointer w-16 h-16 relative left-1/2 -translate-x-1/2"><button type="submit"><img src="/static/naver.png" loading="lazy"/></button></form>
            <form action="/oauth/kakao" method="get" className="cursor-pointer w-16 h-16 relative left-1/2 -translate-x-1/2"><button type="submit"><img src="/static/kakao.png" loading="lazy"/></button></form>
            <form action="/oauth/google" method="get" className="cursor-pointer w-16 h-16 relative left-1/2 -translate-x-1/2"><button type="submit"><img src="/static/google.png" loading="lazy"/></button></form>
        </div> */}
    </div>
}