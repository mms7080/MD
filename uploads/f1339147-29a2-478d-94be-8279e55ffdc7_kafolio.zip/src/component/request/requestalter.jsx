import React, { useState, useRef, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Button, FormControl, FormLabel, InputGroup, Input, InputRightElement, InputLeftElement, FormHelperText, InputLeftAddon, InputRightAddon } from '@chakra-ui/react';
import { AddIcon, CloseIcon } from '@chakra-ui/icons';
import { useInfo } from '../../hook';
import Multidropzone from '../multidropzone';
import Singledropzone from '../singledropzone';

export default ()=>{
    const [isOver, isOverChanger] = useState([false,false,false,false]);
    const [languages, languagesChanger] = useState([]);
    const [tools, toolsChanger] = useState([]);
    const [teams, teamsChanger] = useState([0]);
    const [teamnames, teamnamesChanger] = useState(['']);
    const [teamroles, teamrolesChanger] = useState(['']);
    const languageRef = useRef(null);
    const toolsRef = useRef(null);
    const params = useParams();
    const def = useInfo({method:'post',url:'/singlerequest',def:{},id:params?.id});
    useEffect(()=>{
        languagesChanger(def.language);
        toolsChanger(def.tools);
        if(def.teamnames){
            teams.pop();
            teamnames.pop();
            teamroles.pop();
            for(let _ in def.teamnames){
                teams.push(0);
                teamnames.push(def.teamnames[_]);
                teamroles.push(def.teamroles[_]);
            }
            teamsChanger(teams);
            teamnamesChanger(teamnames);
            teamrolesChanger(teamroles);
        }
    }, [def]);
    useEffect(()=>{
        languageRef.current.value = languages?.join(" ");
    },[languages]);
    useEffect(()=>{
        toolsRef.current.value = tools?.join(" ");
    },[tools]);
    return <div className='mt-8 mx-16 p-8 border-gray-200 rounded-xl border-2'>
        <Multidropzone 
            action="/api/upload/request"
            className="grid grid-cols-3 gap-8"
        >
            <Input hidden name="before" defaultValue={params?.id || ""}/>
            <FormControl gridColumnStart="span 3">
                <FormLabel>Owner</FormLabel>
                <Input variant="flushed" readOnly value={def?.owner || "Unknown"}/>
            </FormControl>
            <FormControl gridColumnStart="span 3" isRequired>
                <FormLabel>Project Name</FormLabel>
                <Input variant="flushed" name="name" defaultValue={def?.name}/>
            </FormControl>
            <div className='col-span-3 border-dashed border-2 border-gray-300 rounded-xl p-2'>
                {
                    languages?.map((v,index)=><Button color="gray" mr="0.5rem" key={index} onClick={()=>languagesChanger(languages.filter((l,i)=>i!=index))}>
                        {v}
                    </Button>)
                }
            </div>
            <Input ref={languageRef} hidden name="language"/>
            <FormControl gridColumnStart="span 3">
                <FormLabel>Language</FormLabel>
                <InputGroup>
                    <Input variant="flushed" name="_language" onKeyPress={(e)=>{
                        if(e.code == 'Space' || e.code == 'Enter'){
                            e.preventDefault();
                            e.stopPropagation();
                            if(e.currentTarget.value.trim().length > 0){
                                languagesChanger([...languages, e.currentTarget.value.trim()]);
                                e.currentTarget.value = "";
                            }
                        }
                        }}
                        onKeyDown={(e)=>{
                            if(e.code == 'Backspace'){
                                if(e.currentTarget.value.length == 0){
                                    e.preventDefault();
                                    e.stopPropagation();
                                    if(languages.length > 0){
                                        const last = languages[languages.length - 1];
                                        languagesChanger(languages.slice(0, languages.length - 1));
                                        e.currentTarget.value = last;
                                    }
                                }
                            }
                    }}/>
                </InputGroup>
                <FormHelperText>Space or Enter is splitter</FormHelperText>
            </FormControl>
            <div className='col-span-3 border-dashed border-2 border-gray-300 rounded-xl p-2'>
                {
                    tools?.map((v,index)=><Button color="gray" mr="0.5rem" key={index} onClick={()=>toolsChanger(tools.filter((l,i)=>i!=index))}>
                        {v}
                    </Button>)
                }
            </div>
            <Input ref={toolsRef} hidden name="tools"/>
            <FormControl gridColumnStart="span 3">
                <FormLabel>Tool</FormLabel>
                <InputGroup>
                    <Input variant="flushed" name="_tools" 
                    onKeyPress={(e)=>{
                        if(e.code == 'Space' || e.code == 'Enter'){
                            e.preventDefault();
                            e.stopPropagation();
                            if(e.currentTarget.value.trim().length > 0){
                                toolsChanger([...tools, e.currentTarget.value.trim()]);
                                e.currentTarget.value = "";
                            }
                        }
                    }}
                    onKeyDown={(e)=>{
                        if(e.code == 'Backspace'){
                            if(e.currentTarget.value.length == 0){
                                e.preventDefault();
                                e.stopPropagation();
                                if(tools.length > 0){
                                    const last = tools[tools.length - 1];
                                    toolsChanger(tools.slice(0, tools.length - 1));
                                    e.currentTarget.value = last;
                                }
                            }
                        }
                    }}/>
                </InputGroup>
                <FormHelperText>Space or Enter is splitter</FormHelperText>
            </FormControl>
            <div className='col-span-3 grid grid-cols-1 gap-6'>
                {
                    teams.map((_,index)=>
                        <InputGroup key={index}>
                            <InputLeftAddon>Team {index + 1}</InputLeftAddon>
                            <Input name={`team${index + 1}name`} w="20%" textAlign="center" rounded="0" defaultValue={teamnames[index]}/>
                            <Input name={`team${index + 1}job`} defaultValue={teamroles[index]}/>
                            <InputRightAddon>
                                <Button onClick={()=>teamsChanger(teams.filter((_,i)=>i!=index))}>
                                    <CloseIcon color="red"/>
                                </Button>
                            </InputRightAddon>
                        </InputGroup>
                    )
                }
                <Button onClick={()=>teamsChanger([...teams, 0])}>
                    <AddIcon color="green"/>
                </Button>
            </div>
            <Singledropzone 
                onDragEnter={()=>isOverChanger([true,false,false,false])}
                onDragLeave={()=>isOverChanger([false,false,false,false])}
                onDragOver={()=>isOverChanger([true,false,false,false])}
                onDragDrop={()=>isOverChanger([false,false,false,false])}
                name="file" 
                fileLimit={1}
                text={(files)=>{
                    if(files.length > 0)
                        return <div className="absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2">{
                            typeof files[0] == 'string' || !files[0] ? files[0] : JSON.stringify(files[0].name)
                        }</div>
                    return <div className="absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2">프로젝트 압축 파일</div>;
                }}
                className={(files)=>{
                    return `border-dashed border-2 text-center border-${
                        isOver[0] ? 'green' : 'gray'
                    }-300 rounded-xl p-3 box-border inline-block w-full h-full text-${
                        files.length > 0 ? 'green' :
                        isOver[0] ? 'green' : 'gray'
                    }-400 text-xl relative`
                }}
                divClassName="h-44"
            />
            <Singledropzone 
                onDragEnter={()=>isOverChanger([false,true,false,false])}
                onDragLeave={()=>isOverChanger([false,false,false,false])}
                onDragOver={()=>isOverChanger([false,true,false,false])}
                onDragDrop={()=>isOverChanger([false,false,false,false])}
                name="readme" 
                fileLimit={1}
                text={(files)=>{
                    if(files.length > 0)
                        return <div className="absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2">{
                            typeof files[0] == 'string' || !files[0] ? files[0] : JSON.stringify(files[0].name)
                        }</div>
                    return <div className="absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2">프로젝트 필요사항을 적은 파일</div>;
                }}
                className={(files)=>{
                    return `border-dashed border-2 text-center border-${
                        isOver[1] ? 'green' : 'gray'
                    }-300 rounded-xl p-3 box-border inline-block w-full h-full text-${
                        files.length > 0 ? 'green' :
                        isOver[1] ? 'green' : 'gray'
                    }-400 text-xl relative`
                }}
                divClassName="h-44"
            />
            <Singledropzone 
                onDragEnter={()=>isOverChanger([false,false,true,false])}
                onDragLeave={()=>isOverChanger([false,false,false,false])}
                onDragOver={()=>isOverChanger([false,false,true,false])}
                onDragDrop={()=>isOverChanger([false,false,false,false])}
                name="icon" 
                fileLimit={1}
                beforePreview={file=>undefined}
                previewType='img'
                text={(files,filePreviews)=>{
                    if(files.length > 0)
                        return <div className="absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2"><img className="h-40" src={filePreviews[0]}/></div>
                    return <div className="absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2">프로젝트 아이콘</div>;
                }}
                className={(files)=>{
                    return `border-dashed border-2 text-center border-${
                        isOver[2] ? 'green' : 'gray'
                    }-300 rounded-xl p-3 box-border inline-block w-full h-full text-${
                        files.length > 0 ? 'green' :
                        isOver[2] ? 'green' : 'gray'
                    }-400 text-xl relative`
                }}
                divClassName="h-44"
            />
            <Singledropzone 
                onDragEnter={()=>isOverChanger([false,false,false,true])}
                onDragLeave={()=>isOverChanger([false,false,false,false])}
                onDragOver={()=>isOverChanger([false,false,false,true])}
                onDragDrop={()=>isOverChanger([false,false,false,false])}
                name="boards" 
                fileLimit={50}
                beforePreview={file=>undefined}
                previewType='img'
                text={(files,filePreviews,removeFile)=>{
                    if(files.length > 0)
                        return <div className="w-full grid grid-cols-6 gap-6 p-6">{
                            filePreviews.map((file,index)=><div key={index} className='overflow-hidden rounded-xl'>
                                <img className='object-cover w-full h-full' src={file} onClick={removeFile(index)}/>
                            </div>)
                        }</div>
                    return <div className="absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2">프로젝트 설명 이미지</div>;
                }}
                className={(files)=>{
                    return `border-dashed border-2 text-center border-${
                        isOver[3] ? 'green' : 'gray'
                    }-300 rounded-xl p-3 box-border inline-block w-full h-full text-${
                        files.length > 0 ? 'green' :
                        isOver[3] ? 'green' : 'gray'
                    }-400 text-xl relative`
                }}
                divClassName={(files)=>{
                    if(files.length > 0) return "col-span-3"
                    return "h-44 col-span-3"
                }}
            />
            <Button type="submit" gridColumnStart="span 3" h="4rem">수정</Button>
        </Multidropzone>
    </div>
}