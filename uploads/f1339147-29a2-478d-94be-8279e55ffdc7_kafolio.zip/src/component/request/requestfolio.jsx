import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ViewIcon, StarIcon, LinkIcon, LockIcon, UnlockIcon, NotAllowedIcon } from '@chakra-ui/icons';

function intersection(arr1, arr2){
    return arr1.filter(v=>arr2.indexOf(v) > -1);
}

const n2s = (number)=>{
    const sizes = ['','K','M','G','T','P','E','Z','Y'];
    let index = 0;
    while(number > 1000) {
        number = parseInt((number / 1000) * 10) / 10;
        index += 1;
    }
    return `${number}${sizes[index]}`;
};

export default ({selector, folios})=>{
    const navigation = useNavigate();
    return <div className='grid grid-cols-5 gap-6 mt-6'>
        {
            folios
            .filter(v=>
                Object.entries(selector.language).filter(v=>v[1]).map(v=>v[1]).filter(v=>v).length < 1 || 
                intersection(Object.entries(selector.language).filter(v=>v[1]).map(v=>v[0]), v.language).length > 0
            )
            .filter(v=>
                Object.entries(selector.tools).filter(v=>v[1]).map(v=>v[1]).filter(v=>v).length < 1 || 
                intersection(Object.entries(selector.tools).filter(v=>v[1]).map(v=>v[0]), v.tools).length > 0
            )
            .filter(v=>
                Object.entries(selector.isopen).filter(v=>v[1]).map(v=>v[1]).filter(v=>v).length < 1 || 
                intersection(Object.entries(selector.isopen).filter(v=>v[1]).map(v=>v[0]), `${v.isopen}`).length > 0
            )
            .filter(v=>
                Object.entries(selector.isrequest).filter(v=>v[1]).map(v=>v[1]).filter(v=>v).length < 1 || 
                intersection(Object.entries(selector.isrequest).filter(v=>v[1]).map(v=>v[0]), `${v.isrequest}`).length > 0
            )
                .map((v,index)=>
                    <div key={index} className='cursor-pointer' onClick={()=>{navigation(`/request/${v.link}`)}}>
                        <div>
                            <div className='rounded-full overflow-hidden inline-block'>
                                <img className='w-8 h-8 object-cover' src={v.iconsrc} loading="lazy"/>
                            </div>
                            <div className='ml-2 inline-block font-semibold text-xs relative -top-[0.6rem]'>{v.name}</div>
                            <div className='inline-block float-right relative top-1'>
                                <ViewIcon/>
                                <div className='mx-2 inline-block font-semibold text-xs'>{n2s(v.views)}</div>
                                <StarIcon/>
                                <div className='mx-2 inline-block font-semibold text-xs'>{n2s(v.like)}</div>
                                {
                                    JSON.parse(v.isrequest) ?
                                    <LockIcon color="green"/> : <UnlockIcon color="red"/>
                                }
                                {
                                    JSON.parse(v.isopen) ?
                                    <LinkIcon mx="0.5rem" color="green"/> : <NotAllowedIcon mx="0.5rem" color="red"/>
                                }
                            </div>
                        </div>
                    </div>
                )
        }
    </div>
}