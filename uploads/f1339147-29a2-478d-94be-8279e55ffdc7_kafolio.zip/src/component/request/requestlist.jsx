import React, { useReducer, useState, useEffect } from 'react';
import { Button } from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import Searches from '../detail/searches';
import Requestfolio from './requestfolio';
import { useInfo } from '../../hook/index';

export default ()=>{
    const navigation = useNavigate();
    const [r1,r2] = useState(false);
    const rerender = ()=>r2(!r1);
    const [selector, selectorChanger] = useReducer((state, action)=>{
        state[action.category][action.value] = !state[action.category][action.value];
        return state;
    },{
        "language":{},
        "tools":{},
        "isopen":{},
        "isrequest":{}
    });
    const folios = useInfo({method:'post', url:'/requests', def:[], ismine:true});
    const collections = [
        {
            type:"language",
            datas:Array.from(new Set(folios.flatMap(v=>v.language)))
        },
        {
            type:"tools",
            datas:Array.from(new Set(folios.flatMap(v=>v.tools)))
        },
        {
            type:"isopen",
            datas:Array.from(new Set(folios.flatMap(v=>v.isopen)))
        },
        {
            type:"isrequest",
            datas:Array.from(new Set(folios.flatMap(v=>v.isrequest)))
        }
    ];
    return <div className='mx-16 mt-8'>
        <Searches rerender={rerender} selector={selector} selectorChanger={selectorChanger} collections={collections}/>
        <Requestfolio selector={selector} folios={folios}/>
        <Button w="100%" onClick={()=>{navigation('/request/write')}}>추가</Button>
    </div>
}