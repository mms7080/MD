import React, { useState } from 'react';
import { useDisclosure, Input, Button } from '@chakra-ui/react';
import { LinkIcon, NotAllowedIcon, DownloadIcon, InfoOutlineIcon } from '@chakra-ui/icons';
import { useNavigate } from 'react-router-dom';
import { useInfo } from '../../hook/index';
import Modal from '../modal';

export default ()=>{
    const folios = useInfo({url:"/isrequests",method:"post", def:[]});
    const navigation = useNavigate();
    const {isOpen, onClose, onOpen} = useDisclosure();
    const [id, idChanger] = useState('');
    const [url, urlChanger] = useState('');
    return <div className='mx-16 mt-8'>
        <Modal 
            onClose={onClose} 
            isOpen={isOpen} 
            header="요청 허락"
            footer={<>
                <Button onClick={()=>{fetch("/api/openserver", {method:'post', body:JSON.stringify({id:id, url:url})}).then(_=>navigation(0));onClose();}}>확인</Button>
                <Button onClick={onClose}>취소</Button>
            </>}
        >
            <Input onChange={(e)=>{
                urlChanger(e.currentTarget.value);
            }}/>
        </Modal>
        {
            folios?.map((v,index)=><div key={index}>
                <div className='border-2 border-gray-300 rounded-2xl p-3'>
                    <div className='cursor-pointer inline-block' onClick={()=>{
                        idChanger(v.id);
                        onOpen();
                    }}>{v.name}</div>
                    {
                        v.link && v.link.startsWith("http") ?
                        [ <a href={v.link} target="_blank">{v.link}</a> ]
                        :undefined
                    }
                    <div className='float-right grid grid-cols-3 gap-4'>
                        <a href={v.file} download><DownloadIcon/></a>
                        <a href={v.readme} download><InfoOutlineIcon/></a>
                        <div>{v.isopen ? <LinkIcon color="green"/> : <NotAllowedIcon color="red"/>}</div>
                    </div>
                </div>
            </div>)
        }
    </div>
}