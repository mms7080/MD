import React, { useState, useEffect } from 'react';

export default ({
        onSubmit = (e)=>{},
        action = "/", className, children})=>{
    const [files, filesChanger] = useState(
        children
            .filter(child=>child.props.name && !child.props.type)
            .map(child=>{return {name:child.props.name,files:[],filePreviews:[], requireFile:parseInt(child?.props?.requireFile || 0)}})
            .reduce((prev,child)=>{
                prev[child.name] = child;
                return prev;
            },{})
    );
    return <form className={className} onSubmit={(e)=>{
        e.preventDefault();
        e.stopPropagation();
        for(let child of Object.values(files)){
            if(child.files.length<child.requireFile) return;
        }
        const form = new FormData(e.target);
        for(let child of Object.values(files)){
            child.files.forEach(file=>form.append(typeof file == 'string' ? `default_${child.name}` : child.name,file));
        }
        fetch(action, {method:'post', encType:'multipart/form-data', body:form, redirect:'follow'}).then(res=>{
            if(res.redirected) window.location.href = res.url;
        })
        onSubmit(e);
    }}>
        {children.map((child,index)=>{
            if(!(
                child.props.onDragEnter || child.props.onDragLeave || child.props.onDragOver || child.props.onDragDrop || child.props.onChangeFiles ||
                child.props.previewType || child.props.beforePreview || child.props.afterPreview || child.props.fileLimit || child.props.requireFile ||
                child.props.divClassName || child.props.text
            )) return child;
            return React.cloneElement(child, {key:index, 
                files:files[child.props.name].files, 
                filesChanger:(newfiles)=>{
                    const news = files;
                    news[child.props.name].files = newfiles;
                    filesChanger({...news});
                }, 
                filePreviews:files[child.props.name].filePreviews, 
                filePreviewsChanger:(newfilePreviews)=>{
                    const news = files;
                    news[child.props.name].filePreviews = newfilePreviews;
                    filesChanger({...news});
                }
            });
        })}
    </form>
}