import React from 'react';
import { Image, Tabs, TabList, Tab, TabIndicator } from '@chakra-ui/react';
import { Input, InputGroup, InputLeftElement, Button } from '@chakra-ui/react';
import { Search2Icon } from '@chakra-ui/icons';
import { useInfo } from '../hook';

export default ({navIndex, navIndexChanger})=>{
    const { message } = useInfo({type:'login'});
    const { isLogin, isAdmin } = {isLogin : message?.isLogin, isAdmin : message?.isAdmin};
    return <div className='w-full inline-block pt-2 pb-2 border-b-gray-200 border-b-2 sticky top-0 bg-white z-50'>
        <Image 
            display="inline-block"
            ml={5}
            w="100"
            src="/static/icon.ico" 
            objectFit="cover"
            cursor="pointer"
            onClick={()=>navIndexChanger(0)}
        />
        <Tabs variant="unstyled" display="inline-block" ml={5} index={navIndex} onChange={navIndexChanger}>
            <TabList>
                <Tab fontWeight="600">HOME</Tab>
                <Tab fontWeight="600">TOP</Tab>
                <Tab fontWeight="600">DETAIL</Tab>
                {
                    isLogin ?
                    <Tab fontWeight="600">REQUEST</Tab> : undefined
                }
                {
                    isAdmin ?
                    <Tab fontWeight="600">DASHBOARD</Tab> : undefined
                }
            </TabList>
            <TabIndicator 
                mt="0.9rem"
                height="2px"
                bg="black"
                borderRadius="1px"
            />
        </Tabs>
        <div className='inline-block float-right mr-3'>
            <InputGroup>
                {/* <InputLeftElement>
                    <Search2Icon/>
                </InputLeftElement>
                <Input 
                    focusBorderColor='gray.200'
                    fontSize="0.9rem"
                    w="20rem"
                    borderRadius="20px"
                    bg="gray.100"
                    placeholder='검색 내용'
                /> */}
                {
                    isLogin ?
                    
                    <Button
                        onClick={()=>navIndexChanger(66)}
                        variant="outline"
                        borderRadius="20px"
                        ml="0.5rem"
                        fontSize="0.8rem"
                    >
                        마이페이지
                    </Button> :
                    <Button
                        onClick={()=>navIndexChanger(77)}
                        variant="outline"
                        borderRadius="20px"
                        ml="0.5rem"
                        fontSize="0.8rem"
                    >
                        로그인
                    </Button>
                }
                {
                    isLogin ?
                    <form action="/api/logout" method="post">
                        <Button
                            type="submit"
                            variant="outline"
                            borderRadius="20px"
                            ml="0.5rem"
                            fontSize="0.8rem"
                        >로그아웃</Button>
                    </form> :
                    <Button
                        onClick={()=>navIndexChanger(88)}
                        variant="outline"
                        borderRadius="20px"
                        ml="0.5rem"
                        fontSize="0.8rem"
                    >
                        회원가입
                    </Button>
                }
            </InputGroup>
        </div>
    </div>
}