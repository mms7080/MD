import React, { useRef, useState } from 'react';
import { ArrowLeftIcon, ArrowRightIcon } from '@chakra-ui/icons';
import Swiper from '../swiper';

export default ()=>{
    const swiper = useRef(null);
    const [index, indexChanger] = useState(0);
    const per_view = 7;
    let categorys = [
        {name:'카테고리',src:'https://i.namu.wiki/i/xxyTLDbYnN4uGEFNR-VpNVMa-iK5c5-zvzd4VOoBOuMBfzhqx1K8mcToaQ7K17D7OoqypoJolu3uAKURgooBOQ.webp'},
        {name:'카테고리',src:'https://flexible.img.hani.co.kr/flexible/normal/970/647/imgdb/original/2022/0502/20220502503242.jpg'},
        {name:'카테고리',src:'https://flexible.img.hani.co.kr/flexible/normal/970/647/imgdb/original/2023/0501/20230501502252.jpg'},
        {name:'카테고리',src:'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0d/220602_%EB%A5%B4%EC%84%B8%EB%9D%BC%ED%95%8C_%EB%8C%80%EB%A9%B4_%ED%8C%AC%EC%82%AC%EC%9D%B8%ED%9A%8C_%EC%B9%B4%EC%A6%88%ED%95%98%2C_%EA%B9%80%EC%B1%84%EC%9B%90%2C_%EC%82%AC%EC%BF%A0%EB%9D%BC%2C_%ED%97%88%EC%9C%A4%EC%A7%84%2C_%ED%99%8D%EC%9D%80%EC%B1%84_%EB%8B%A8%EC%B2%B4_%EC%BB%B7.jpg/1200px-220602_%EB%A5%B4%EC%84%B8%EB%9D%BC%ED%95%8C_%EB%8C%80%EB%A9%B4_%ED%8C%AC%EC%82%AC%EC%9D%B8%ED%9A%8C_%EC%B9%B4%EC%A6%88%ED%95%98%2C_%EA%B9%80%EC%B1%84%EC%9B%90%2C_%EC%82%AC%EC%BF%A0%EB%9D%BC%2C_%ED%97%88%EC%9C%A4%EC%A7%84%2C_%ED%99%8D%EC%9D%80%EC%B1%84_%EB%8B%A8%EC%B2%B4_%EC%BB%B7.jpg'},
        {name:'카테고리',src:'https://pds.joongang.co.kr/news/component/htmlphoto_mmdata/202205/02/5efc599d-5892-4945-a6c7-bb7ef7575e79.jpg'},
        {name:'카테고리',src:'https://talkimg.imbc.com/TVianUpload/tvian/TViews/image/2023/05/01/5eb56e95-7135-40f9-a989-f014c43c5adb.jpg'},
        {name:'카테고리',src:'https://img.wkorea.com/w/2023/11/style_655ab9a8cdd38-1400x933.jpeg'},
        {name:'카테고리',src:'https://image-cdn.hypb.st/https%3A%2F%2Fkr.hypebeast.com%2Ffiles%2F2023%2F10%2Foverwatch-2-reveals-le-sserafim-new-skin-details-info-01-2023-b.jpg?cbr=1&q=90'},
    ];
    return <div className='relative pt-2 mt-6 ml-16 mr-16'>
        <Swiper
            swiper={swiper}
            slides-per-view={per_view}
            space-between="15"
            speed="500"
            touch-ratio="0"
        >
            {
                categorys.map((v,index)=>
                    <div key={index} className='rounded-full border-gray-200 border h-14 box-content'>
                        <div className='rounded-full overflow-hidden inline-block mt-2 relative left-2'>
                            <img className='h-10 w-10 object-cover' src={v.src} loading="lazy"/>
                        </div>
                        <span className='inline-block relative -top-3 left-6 font-bold text-xl'>
                            {v.name}
                        </span>
                    </div>
                )
            }
        </Swiper>
        {
            index == 0 ?
            undefined :
            <div>
                <div className='z-30 p-4 top-[2.5rem] -translate-y-1/2 absolute w-36 h-16 bg-gradient-to-r from-white from-60% to-transparent'></div>
                <ArrowLeftIcon 
                bg="white"
                color="black"
                w="2.8rem"
                h="2.8rem"
                padding="1rem"
                borderRadius="50%"
                boxShadow="0 0 5px -3px black"
                pos="absolute"
                top="calc(50% + 0.25rem)"
                left="1.7rem"
                transform="translateY(-50%)"
                zIndex="49"
                onClick={()=>{
                    swiper.current.swiper.slidePrev();
                    indexChanger(swiper.current.swiper.activeIndex);
                }}/>
            </div>
        }
        {
            index == (categorys.length - per_view) ?
            undefined :
            <div>
                <div className='z-30 right-0 p-4 top-[2.5rem] -translate-y-1/2 absolute w-36 h-16 bg-gradient-to-l from-white from-60% to-transparent'></div>
                <ArrowRightIcon 
                bg="white"
                color="black"
                w="2.8rem"
                h="2.8rem"
                padding="1rem"
                borderRadius="50%"
                boxShadow="0 0 5px -3px black"
                pos="absolute"
                top="calc(50% + 0.25rem)"
                right="1.7rem"
                transform="translateY(-50%)"
                zIndex="49"
                onClick={()=>{
                    swiper.current.swiper.slideNext();
                    indexChanger(swiper.current.swiper.activeIndex);
                }}/>
            </div>
        }
    </div>
}