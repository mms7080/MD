import React, { useState } from 'react';
import Bannerscroll from './bannerscroll';
import Poliolist from './poliolist';

export default ()=>{
    return <div>
        <Bannerscroll/>
        <div className='font-bold text-2xl mt-16 ml-16 mr-16'>
            국내 최고의 포트폴리오를 발견해보세요.
        </div>
        <Poliolist/>
    </div>
}