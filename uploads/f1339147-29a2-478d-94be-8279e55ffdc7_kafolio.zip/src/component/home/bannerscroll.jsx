import React, { useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeftIcon, ArrowRightIcon } from '@chakra-ui/icons';
import { useInfo } from '../../hook';
import Swiper from '../swiper';

export default ()=>{
    const swiper = useRef(null);
    const navigation = useNavigate();
    let folios = useInfo({method:'post', url:'/requests', def:[], ismine:false, slice:20, random:true});
    return <div className='relative mt-10'>
        <Swiper
            swiper={swiper}
            slides-per-view="3.3"
            centered-slides="true"
            space-between="15"
            speed="500"
            loop="true"
        >
            {
                folios?.slice(0,20)?.map((v,index)=>
                    <div key={index} className='rounded-2xl overflow-hidden h-96'>
                        <img className='object-cover cursor-pointer w-full h-full' src={v.mainsrc} loading="lazy" onClick={()=>navigation(`/folio/${v.link}`)}/>
                    </div>
                )
            }
        </Swiper>
        <ArrowLeftIcon 
        bg="white"
        color="black"
        w="3rem"
        h="3rem"
        padding="1rem"
        borderRadius="50%"
        boxShadow="0 0 5px -3px black"
        pos="absolute"
        top="50%"
        left="1.5rem"
        transform="translateY(-50%)"
        zIndex="49"
        cursor="pointer"
        onClick={()=>{
            swiper.current.swiper.slidePrev();
        }}/>
        <ArrowRightIcon 
        bg="white"
        color="black"
        w="3rem"
        h="3rem"
        padding="1rem"
        borderRadius="50%"
        boxShadow="0 0 5px -3px black"
        pos="absolute"
        top="50%"
        right="1.5rem"
        transform="translateY(-50%)"
        zIndex="49"
        cursor="pointer"
        onClick={()=>{
            swiper.current.swiper.slideNext();
        }}/>
    </div>
}