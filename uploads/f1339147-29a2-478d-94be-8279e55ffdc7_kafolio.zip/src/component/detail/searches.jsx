import React from 'react';
import { Box, Divider } from '@chakra-ui/react';

export default ({selector, selectorChanger, collections, rerender})=>{
    return <Box border="1px" borderColor="lightgray" borderRadius="5px">
        <ol>
            {
                collections.map((v,index)=>
                <li key={index} className='mx-4'>
                    <div className='mx-1 py-2'>
                        <div className='inline-block w-[7%] float-start mt-2'>{v.type.toUpperCase()}</div>
                        <div className='inline-block w-[93%] mt-1'>
                            {
                                v.datas.map((lv,index)=>
                                    <div key={index} 
                                        data-target="align"
                                        className={`cursor-pointer inline-block ${selector[v.type][lv] ? "bg-blue-400 text-white" : "bg-gray-200 text-gray-500"} rounded-full mx-1 px-5 py-[0.35rem] mb-1`}
                                        onClick={()=>{
                                            selectorChanger({
                                                category:v.type,
                                                value:lv
                                            });
                                            rerender();
                                        }}
                                    >
                                        {lv.toUpperCase()}
                                    </div>
                                )
                            }
                        </div>
                    </div>
                    {
                        index != collections.length - 1 ?
                        <Divider/> : undefined
                    }
                </li>
                )
            }
        </ol>
    </Box>
}