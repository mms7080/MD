import React, { useReducer, useState, useEffect } from 'react';
import Searches from './searches';
import Searchfolio from './searchfolio';
import { useInfo } from '../../hook/index';

export default ()=>{
    const [r1,r2] = useState(false);
    const rerender = ()=>r2(!r1);
    const [selector, selectorChanger] = useReducer((state, action)=>{
        state[action.category][action.value] = !state[action.category][action.value];
        return state;
    },{
        "language":{},
        "tools":{}
    });
    const folios = useInfo({method:'post', url:'/requests', def:[], ismine:false});
    const collections = [
        {
            type:"language",
            datas:Array.from(new Set(folios.flatMap(v=>v.language)))
        },
        {
            type:"tools",
            datas:Array.from(new Set(folios.flatMap(v=>v.tools)))
        }
    ];
    return <div className='mx-16 mt-8'>
        <Searches rerender={rerender} selector={selector} selectorChanger={selectorChanger} collections={collections}/>
        <Searchfolio selector={selector} folios={folios}/>
    </div>
}