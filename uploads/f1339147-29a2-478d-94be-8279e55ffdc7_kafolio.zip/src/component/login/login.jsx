import React, { useState } from 'react';
import { FormControl, FormLabel, Input, Button, Divider } from '@chakra-ui/react';
import pkg from 'crypto-js';
const { SHA512 } = pkg;

export default ()=>{
    const [pw, pwChanger] = useState('');
    return <div className='mx-auto w-[40rem] mt-8 border-2 border-gray-200 rounded-md p-6'>
        <form action="/oauth/local" method="post">
            <FormControl isRequired>
                <FormLabel>ID</FormLabel>
                <Input variant="flushed" type="text" name="id"/>
            </FormControl>
            <Input defaultValue={pw} name="pw" hidden/>
            <FormControl isRequired>
                <FormLabel>Password</FormLabel>
                <Input 
                    variant="flushed" 
                    type="password"
                    name="pw_in"
                    onChange={(e)=>{
                        pwChanger(SHA512(e.currentTarget.value).toString());
                    }}
                />
            </FormControl>
            <Button type="submit" mt="1rem" w="100%">
                로그인
            </Button>
        </form>
        {/* <Divider mt="1rem"/>
        <div className='grid grid-cols-3 gap-6 mt-4'>
            <form action="/oauth/naver" method="get" className="cursor-pointer w-16 h-16 relative left-1/2 -translate-x-1/2"><button type="submit"><img src="/static/naver.png" loading="lazy"/></button></form>
            <form action="/oauth/kakao" method="get" className="cursor-pointer w-16 h-16 relative left-1/2 -translate-x-1/2"><button type="submit"><img src="/static/kakao.png" loading="lazy"/></button></form>
            <form action="/oauth/google" method="get" className="cursor-pointer w-16 h-16 relative left-1/2 -translate-x-1/2"><button type="submit"><img src="/static/google.png" loading="lazy"/></button></form>
        </div> */}
    </div>
}