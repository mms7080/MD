import React, { useState } from 'react';

export default ({
        onDragEnter = (e)=>{}, 
        onDragLeave = (e)=>{}, 
        onDragOver = (e)=>{}, 
        onDragDrop = (e)=>{}, 
        onChangeFiles = (e)=>{},
        files, filesChanger, filePreviews, filePreviewsChanger,
        previewType = 'file',
        beforePreview, afterPreview, fileLimit = 1, requireFile = 0,
        children, className, divClassName, text = 'Drag & Drop', name = "file"})=>{
    const removeFile = (index)=>{
        return ()=>{
            filesChanger(files.filter((v,i)=>i!=index));
            filePreviewsChanger(filePreviews.filter((v,i)=>i!=index));
        }
    }
    const readFile = async (files)=>{
        const fileReader = new FileReader();
        let totals = [...filePreviews];
        for(let file of files){
            await new Promise((resolve, reject)=>{
                fileReader.onload = ({target})=>{
                    totals = [...totals, target.result];
                    resolve();
                }
                fileReader.onerror = (e)=>reject(e);
                fileReader.readAsDataURL(file);
            })
        }
        filePreviewsChanger(totals.length > fileLimit ? totals.slice(totals.length - fileLimit) : totals);
    }
    const dragEnter = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        onDragEnter(e);
    }
    const dragOver = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        onDragOver(e);
    }
    const dragLeave = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        onDragLeave(e);
    }
    const dragDrop = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        const selected = Array.from(e.dataTransfer.files);
        const result = [...files, ...selected];
        filesChanger(result.length > fileLimit ? result.slice(result.length - fileLimit) : result);
        if((beforePreview || afterPreview) && previewType == 'img')
            readFile(selected);
        onDragDrop(e);
        onChangeFiles(e);
    }
    const inputFiles = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        const selected = Array.from(e.target.files);
        const result = [...files, ...selected];
        filesChanger(result.length > fileLimit ? result.slice(result.length - fileLimit) : result);
        if((beforePreview || afterPreview) && previewType == 'img')
            readFile(selected);
        onChangeFiles(e);
    }
    return <div className={typeof divClassName == 'function' ? divClassName(files, filePreviews) : divClassName}>
        <input type="file" id={name} name={name} onChange={inputFiles} hidden multiple/>
        { beforePreview ? previewType == 'img' ? filePreviews.map((file,index)=>beforePreview(file,index,removeFile(index))) : files.map((file,index)=>beforePreview(file,index,removeFile(index))) : undefined }
        <label 
            onDragEnter={dragEnter}
            onDragLeave={dragLeave}
            onDragOver={dragOver}
            onDrop={dragDrop}
            htmlFor={name} 
            role='button' 
            className={typeof className == 'function' ? className(files, filePreviews) : className}
        >{typeof text == 'function' ? text(files, filePreviews, removeFile) : text}</label>
        { afterPreview ? previewType == 'img' ? filePreviews.map((file,index)=>afterPreview(file,index, removeFile(index))) : files.map((file,index)=>afterPreview(file,index, removeFile(index))) : undefined }
        {children}
    </div>
}