import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';
import { Button, useDisclosure } from '@chakra-ui/react';
import { ArrowLeftIcon, ArrowRightIcon, CloseIcon, CheckIcon } from '@chakra-ui/icons';
import { useInfo } from '../../hook/index';
import Swiper from '../swiper';
import Modal from '../modal';

function T2S(time){
    if(!time) return "";
    const date = new Date(time);
    return `${date.getFullYear()} / ${date.getMonth() + 1 < 10 ? `0${date.getMonth() + 1}` : date.getMonth() + 1} / ${date.getDate() < 10 ? `0${date.getDate()}` : date.getDate()}`;
}

export default ()=>{
    const [modalImg, modalImgChanger] = useState(0);
    const { isOpen, onClose, onOpen } = useDisclosure();
    const { isOpen : isOpenRequest, onClose : onCloseRequest, onOpen : onOpenRequest } = useDisclosure();
    const params = useParams();
    const navigation = useNavigate();
    const folio = useInfo({url:"/singlerequest", method:"post", id:params?.id});
    return <div className='mx-16 mt-8 mb-8 border-2 border-gray-300 rounded-2xl grid-cols-12 gap-6 py-4 px-7'>
        <Modal 
            onClose={onClose} 
            isOpen={isOpen} 
            size='full'
            closeProps={{
                color:'white',
                zIndex:50
            }}
            bodyProps={{
                bg:"rgba(0,0,0,0.3)"
            }}
            contentProps={{
                bg:"transparent"
            }}
        >
            <div className='w-full h-svh relative'>
                <img src={folio?.boards?.at(modalImg)} className='w-full h-full object-contain'/>
                <Button variant="solid" colorScheme='white' position="absolute" left="0" top="50%" translateY="-50%" onClick={()=>modalImgChanger(modalImg - 1 < 0 ? 0 : modalImg - 1)}>
                    <ArrowLeftIcon/>
                </Button>
                <Button variant="solid" colorScheme='white' position="absolute" right="0" top="50%" translateY="-50%" onClick={()=>modalImgChanger(modalImg + 1 >= folio.boards.length ? folio.boards.length - 1 : modalImg + 1)}>
                    <ArrowRightIcon/>
                </Button>
            </div>
        </Modal>
        <Modal 
            onClose={onCloseRequest} 
            isOpen={isOpenRequest} 
            header={folio.isrequest ? "요청 철회" : "요청 확인"}
            footer={<>
                <Button onClick={()=>{fetch(`/api/isrequest`, {method:'post', body:JSON.stringify({id:params.id})}).then(_=>navigation(0));onCloseRequest();}}>확인</Button>
                <Button onClick={onCloseRequest}>취소</Button>
            </>}
        >
            {
                folio.isrequest ?
                "요청을 수정하기위해 철회하는지 확인하세요." :
                "README에 요청할 URL을 작성했는지 확인하세요. 요청 URL은 *.kafolio.com 구조이며 작성하지 않거나 이미 사용중이면 무작위 URL이 할당됩니다."
            }
        </Modal>
        <div className="col-span-6 inline-block w-1/2">
            Writer : {folio.owner}
        </div>
        <div className='col-span-6 inline-block w-1/2 text-right'>
            {
                folio.altercount < 1 ?
                undefined :
                `AlterDate : ${T2S(folio.alterdate)} - `
            }
            WriteDate : {T2S(folio.writedate)}
        </div>
        <div className='text-6xl text-center mt-4'>
            {folio.name}
        </div>
        <div className='col-span-6 inline-block w-1/2 mt-4'>
            <div className='inline-block w-[10%] float-start mt-2'>LANGUAGE</div>
            <div className='inline-block w-[90%] mt-1'>
                {
                    folio?.language?.map((lv,index)=>
                        <div key={index} 
                            data-target="align"
                            className='inline-block bg-gray-200 text-gray-500 rounded-full mx-1 px-5 py-[0.35rem] mb-1'
                        >
                            {lv.toUpperCase()}
                        </div>
                    )
                }
            </div>
        </div>
        <div className='col-span-6 inline-block w-1/2 mt-4'>
            <div className='inline-block w-[10%] float-start mt-2'>TOOLS</div>
            <div className='inline-block w-[90%] mt-1'>
                {
                    folio?.tools?.map((lv,index)=>
                        <div key={index} 
                            data-target="align"
                            className='inline-block bg-gray-200 text-gray-500 rounded-full mx-1 px-5 py-[0.35rem] mb-1'
                        >
                            {lv.toUpperCase()}
                        </div>
                    )
                }
            </div>
        </div>
        <div className='col-span-12 inline-grid grid-cols-4 gap-6 w-full mt-4'>
            <div className='col-span-2'>Link : <a href={folio.link} target="_blank">{folio.link}</a></div>
            <div className='col-span-2 row-span-6 relative'>
                <img src={folio.icon} className="object-contain w-full h-full absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"/>
            </div>
            <div className='col-span-2'>Request : 
                {
                    folio.isrequest ? 
                    <CheckIcon ml="0.5rem" cursor="pointer" onClick={onOpenRequest} color="green"/> : 
                    <CloseIcon ml="0.5rem" cursor="pointer" onClick={onOpenRequest} color="red"/>
                }
            </div>
            <div className='col-span-2'>Views : <span>{folio.views}</span></div>
            <div className='col-span-2'>Like : <span>{folio.like}</span></div>
            <div className='col-span-2'>Portfolio : <a href={folio.file} download={folio.fileoriginal}>{folio.fileoriginal}</a></div>
            <div className='col-span-2'>README : <a href={folio.readme} download={folio.readmeoriginal}>{folio.readmeoriginal}</a></div>
            <>
                {
                    folio?.teamnames?.map((v,index)=>
                    <>
                        <div>
                            {v}
                        </div>
                        <div className='col-span-3'>
                            {folio.teamroles[index]}
                        </div>
                    </>)
                }
            </>
        </div>
        <div className="mt-6">
            <Swiper
                slides-per-view="6"
                space-between="15"
                speed="500"
            >
                {
                    folio?.boards?.map((v,index)=>
                        <div key={index} className='rounded-2xl overflow-hidden cursor-pointer h-96' onClick={()=>{modalImgChanger(index); onOpen();}}>
                            <img className='w-full h-full object-cover' src={v} loading="lazy"/>
                        </div>
                    )
                }
            </Swiper>
        </div>
        {
            folio.isrequest ? undefined :
            <Button w="100%" mt="2rem" onClick={()=>navigation(`/request/alter/${params?.id}`)} position="sticky" top="4rem" zIndex={500}>수정</Button>
        }
    </div>
}