import React from 'react';
import { Modal, ModalOverlay, ModalContent, ModalHeader, ModalCloseButton, ModalBody, ModalFooter } from '@chakra-ui/react';

export default ({header, footer, children, headerProps, footerProps, bodyProps, overlayProps, contentProps, closeProps, ...props})=>{
    return <Modal {...props}>
        <ModalOverlay {...overlayProps}/>
        <ModalContent {...contentProps}>
            { header ? <ModalHeader {...headerProps}>{header}</ModalHeader> : undefined }
            <ModalCloseButton {...closeProps}/>
            <ModalBody {...bodyProps}>
                {children}
            </ModalBody>
            { footer ? <ModalFooter {...footerProps}>{footer}</ModalFooter> : undefined }
        </ModalContent>
    </Modal>
}