import useInfo from './getinfo';
import useStatic from './static';

export {
    useStatic,
    useInfo
};