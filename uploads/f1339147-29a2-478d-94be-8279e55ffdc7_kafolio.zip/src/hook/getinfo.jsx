import React, {useEffect, useState, useCallback} from 'react';
export default (option)=>{
    let {url, method, def, ...options} = option;
    url = url || '/info';
    method = method || 'get';
    let [data, dataChanger] = useState(def ? def : {});
    const handle = useCallback(async ()=>{
        let query = "";
        if(method == 'get'){
            for(let key in options){ query += `${key}=${options[key]}&`; }
            dataChanger(await fetch(`/api${url}?${query.slice(0, -1)}`, {method:method}).then(v=>v.json()));
        } else {
            dataChanger(await fetch(`/api${url}`, {method:method, body:JSON.stringify(options)}).then(v=>v.json()));
        }
    }, []);
    useEffect(()=>{
        handle();
    }, [handle]);
    return data;
}