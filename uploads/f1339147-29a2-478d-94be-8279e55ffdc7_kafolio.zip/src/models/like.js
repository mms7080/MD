import mongoose from 'mongoose';
export default mongoose.Schema({
    "id":{
        "type":String,
    },
    "folio":{
        "type":String,
    },
});