import mongoose from 'mongoose';
export default mongoose.Schema({
    "sid":{
        "type":String,
    },
    "folio":{
        "type":String,
    },
    "removeview":{
        "type":Date,
        "default":Date.now
    },
});