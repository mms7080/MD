import React from 'react';
import { renderToString } from 'react-dom/server';
import { ChakraProvider } from '@chakra-ui/react';
import { StaticRouter } from 'react-router-dom/server';
import { useStatic } from './hook/index';
import App from './component/app';

export function render(url){
    let html = renderToString(
        <StaticRouter location={url} basename='/app'>
            <ChakraProvider>
                <useStatic.Provider value={{}}>
                    <App/>
                </useStatic.Provider>
            </ChakraProvider>
        </StaticRouter>
    );
    return { html };
}