package com.example.demo.Booking.entity;

// 고객 유형
public enum CustomerCategory {
        ADULT,
        YOUTH,
        SENIOR,
        DISABLED
}
