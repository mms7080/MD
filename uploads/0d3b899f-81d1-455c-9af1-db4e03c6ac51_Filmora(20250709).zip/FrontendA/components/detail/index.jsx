import Reviews from './reviews';
import Filmstill from './filmstill';
import Likepart from './likepart';
import Bottombox from './bottombox';

export {Reviews,Filmstill,Likepart,Bottombox};