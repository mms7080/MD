import React from 'react';
import '../styles/spinner.css'; // CSS 파일을 import

const Spinner = () => {
  return (
    <div className="spinner"></div>
  );
}

export default Spinner;
