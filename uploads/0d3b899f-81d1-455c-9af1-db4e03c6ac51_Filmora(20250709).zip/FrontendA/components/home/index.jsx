import Swipers from './swipers';
import Movies from './movies';
import Bookmark from './bookmark';
import Events from './events';
import Reviews from './reviews';

export {Swipers,Movies,Bookmark,Events,Reviews};