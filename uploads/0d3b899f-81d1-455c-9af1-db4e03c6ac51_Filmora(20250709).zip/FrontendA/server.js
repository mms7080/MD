import { createServer } from 'https';
import next from 'next';
import fs from 'fs';
import dotenv from 'dotenv';
dotenv.config();

const dev = process.env.NODE_ENV !== 'production';
const hostname = process.env.HOSTNAME || 'localhost';
const port = parseInt(process.env.PORT) || 3000;

// Next.js 앱 초기화 - production 최적화
const app = next({ 
  dev, 
  hostname,
  // production 환경에서 최적화 설정
  conf: {
    compress: true,
    poweredByHeader: false,
    generateEtags: true,
  }
});
const handle = app.getRequestHandler();

app.prepare().then(() => {

  // HTTPS 옵션 설정
  const httpsOptions = {};
  
  try {
    if (process.env.KEY && fs.existsSync(process.env.KEY)) {
      httpsOptions.key = fs.readFileSync(process.env.KEY);
    }
    if (process.env.CERT && fs.existsSync(process.env.CERT)) {
      httpsOptions.cert = fs.readFileSync(process.env.CERT);
    }
    if (process.env.CHAIN && fs.existsSync(process.env.CHAIN)) {
      httpsOptions.ca = fs.readFileSync(process.env.CHAIN);
    }
  } catch (error) {
    console.error('SSL 인증서 로드 실패:', error);
    console.log('HTTP 모드로 실행됩니다.');
  }

  // 서버 생성 및 요청 처리
  const server = createServer(httpsOptions, (req, res) => {
    return handle(req, res);
  });
  
  server.listen(port, hostname, (err) => {
    if (err) throw err;
    console.log(`> HTTPS 서버가 https://${hostname}:${port} 에서 실행 중입니다`);
    console.log(`> 환경: ${dev ? 'development' : 'production'}`);
  });
});
