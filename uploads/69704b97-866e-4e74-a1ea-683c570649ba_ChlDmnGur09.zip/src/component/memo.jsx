import React, { useEffect, useRef, useState} from "react";

export default ()=>{    
    const [title,setTitle] = useState('Memo')
    const [inner, setInner] = useState('');
    return <>
    <input className="w-full border-b-2 border-gray-500" placeholder="제목을 입력해주세요" onChange={(e)=>setTitle(e.target.value)}/>
    <textarea className="w-full h-auto min-h-full whitespace-normal focus:[outline: none] border-[0px]" onChange={(e)=>setInner(e.target.value)}/>
    <button className="w-[80px] h-[40px] absolute bottom-[15px] -translate-x-full bg-blue-500 rounded-xl text-white font-semibold" onClick={()=>{
        const blob = new Blob([inner], {type:'text/plain'});
        const url = window.URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = title;
        document.body.appendChild(a);
        
        a.click();

        setTimeout(() => {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }, 100);
    }}>저장</button></>
}