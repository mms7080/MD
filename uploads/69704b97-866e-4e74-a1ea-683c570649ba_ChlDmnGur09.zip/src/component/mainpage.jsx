import React, { useState, useEffect} from "react";
import {Button,Box, Tooltip} from '@chakra-ui/react'
import {CalendarIcon, SearchIcon,CheckIcon,AddIcon,MinusIcon,CloseIcon,RepeatIcon} from '@chakra-ui/icons'

export default ({boxV,boxF,infoType,infoType_F,change,setChange, noneV, noneF, can, canF, whV, whF})=>{
    const [oneV, oneF] = useState(['',0,0]);
    useEffect(()=>{
        oneV[0]=='14' || oneV[0]=='23' || oneV[0]=='32' || oneV[0]=='41' ? (noneF(['','none','none','none']), whF([310,310]), boxF([0,5,5,5]), canF([false,false,false,false])) : undefined;
        oneV[0]=='12' || oneV[0]=='21' ? (noneF(['','none',noneV[2],noneV[3]]), whF([310,150,0,0,whV[4],whV[5],whV[6],whV[7]]), boxF([0,5,boxV[2],boxV[3]]), canF([false,false,can[2],can[3]])) : undefined;
        oneV[0]=='34' || oneV[0]=='43' ? (noneF([noneV[0],noneV[1],'','none']), whF([whV[0],whV[1],whV[2],whV[3],310,150,0,0,]), boxF([boxV[0],boxV[1],0,7]), canF([can[0],can[1],false,false])) : undefined
        oneV[0]=='13' || oneV[0]=='31' ? (noneF(['',noneV[1],'none',noneV[3]]), whF([150,310,whV[2],whV[3],0,0,whV[6],whV[7]]), boxF([0,boxV[1],5,boxV[3]]), canF([false,can[1],false,can[3]])) : undefined;
        oneV[0]=='24' || oneV[0]=='42' ? (noneF([noneV[0],'',noneV[2],'none']), whF([whV[0],whV[1],150,310,whV[4],whV[5],0,0]), boxF([boxV[0],0,boxV[2],6]), canF([can[0],false,can[2],false])) : undefined;
    },[oneV[0]])
    return<div className={`[display:${change ? '' : 'none'}]`}>
            
            <Box w={'324px'} h={'324px'} borderWidth='2px' borderRadius='lg' position={'absolute'} top={'40%'} left={'50%'} transform="translate(-50%,-50%)">
                <Box as="button" display={noneV[0]} w={`${whV[0]}px`} h={`${whV[1]}px`} position={'absolute'} top={'5px'} left={'5px'} bg={boxV[0] % 4 == 1 ? '#22c55e' : boxV[0] % 4 == 2 ? '#ef4444' : boxV[0] % 4 == 3 ? '#3b82f6' : '#E2E8F0'} borderRadius={'lg'} onClick={()=>boxF([(boxV[0]+1) % 4,boxV[1],boxV[2],boxV[3]])}>
                    {boxV[0] % 4 == 1 && noneV[0] != 'none' ? <Tooltip label='여러 정보들을 담고있습니다.'><SearchIcon top={'50%'} left={'50%'} transform={'translate(-50%,-50%)'} position={'absolute'} w={'50px'} h={'50px'}/></Tooltip> 
                    : boxV[0] % 4 == 2 && noneV[0] != 'none' ? <Tooltip label='계산기 시스템을 담고있습니다.'><Box top={'50%'} left={'50%'} transform={'translate(-50%,-50%)'} position={'absolute'}>
                        <AddIcon  w={'25px'} h={'25px'}/>
                        <MinusIcon  w={'25px'} h={'25px'}/>
                        <br/>
                        <CloseIcon  w={'25px'} h={'25px'}/>
                        <Box w={'25px'} h={'25px'} display={'inline-block'}><MinusIcon  w={'25px'} h={'25px'}/><Box w={'5px'} h={'5px'} bg={'black'} borderRadius={'50%'} position={'absolute'} top={'46.5px'} left={'35px'}></Box><Box w={'5px'} h={'5px'} bg={'black'} borderRadius={'50%'} position={'absolute'} top={'30px'} left={'35px'}></Box></Box>
                    </Box></Tooltip>
                    : boxV[0] % 4 == 3 && noneV[0] != 'none' ? <Tooltip label='메모장을 담고있습니다.'><CalendarIcon top={'50%'} left={'50%'} transform={'translate(-50%,-50%)'} position={'absolute'} w={'50px'} h={'50px'}/></Tooltip>
                    : boxV[0] % 4 == 0 && can[0] ? 
                    <Tooltip label='같은 크기의 흰색끼리 합칠 수 있습니다.'><div draggable="true" className="w-full h-full" onDragEnd={(e)=>oneF(['1',e.clientX,e.clientY])} onMouseOver={(e)=>oneV[1] == e.clientX && oneV[2] == e.clientY ? oneF([oneV[0]+'1',0,0]) : oneV[0]}></div></Tooltip>
                    : undefined}
                </Box>
                <Box as="button" display={noneV[1]} w={`${whV[2]}px`} h={`${whV[3]}px`} position={'absolute'} top={'5px'} right={'5px'} bg={boxV[1] % 4 == 1 ? '#22c55e' : boxV[1] % 4 == 2 ? '#ef4444' : boxV[1] % 4 == 3 ? '#3b82f6' : '#E2E8F0'} borderRadius={'lg'} onClick={()=>boxF([boxV[0],(boxV[1]+1) % 4,boxV[2],boxV[3]])}>
                    {boxV[1] % 4 == 1 && noneV[1] != 'none' ? <Tooltip label='여러 정보들을 담고있습니다.'><SearchIcon top={'50%'} left={'50%'} transform={'translate(-50%,-50%)'} position={'absolute'} w={'50px'} h={'50px'}/></Tooltip> 
                    : boxV[1] % 4 == 2 && noneV[1] != 'none' ? <Tooltip label='계산기 시스템을 담고있습니다.'><Box top={'50%'} left={'50%'} transform={'translate(-50%,-50%)'} position={'absolute'}>
                        <AddIcon  w={'25px'} h={'25px'}/>
                        <MinusIcon  w={'25px'} h={'25px'}/>
                        <br/>
                        <CloseIcon  w={'25px'} h={'25px'}/>
                        <Box w={'25px'} h={'25px'} display={'inline-block'}><MinusIcon  w={'25px'} h={'25px'}/><Box w={'5px'} h={'5px'} bg={'black'} borderRadius={'50%'} position={'absolute'} top={'46.5px'} left={'35px'}></Box><Box w={'5px'} h={'5px'} bg={'black'} borderRadius={'50%'} position={'absolute'} top={'30px'} left={'35px'}></Box></Box>
                    </Box></Tooltip>
                    : boxV[1] % 4 == 3 && noneV[1] != 'none' ? <Tooltip label='메모장을 담고있습니다.'><CalendarIcon top={'50%'} left={'50%'} transform={'translate(-50%,-50%)'} position={'absolute'} w={'50px'} h={'50px'}/></Tooltip>
                    : boxV[1] % 4 == 0 && can[1] ? 
                    <Tooltip label='같은 크기의 흰색끼리 합칠 수 있습니다.'><div draggable="true"  className="w-full h-full" onDragEnd={(e)=>oneF(['2',e.clientX,e.clientY])} onMouseOver={(e)=>oneV[1] == e.clientX && oneV[2] == e.clientY ? oneF([oneV[0]+'2',0,0]) : undefined}></div></Tooltip>
                    : undefined}
                </Box>
                <Box as="button" display={noneV[2]} w={`${whV[4]}px`} h={`${whV[5]}px`} position={'absolute'} bottom={'5px'} left={'5px'} bg={boxV[2] % 4 == 1 ? '#22c55e' : boxV[2] % 4 == 2 ? '#ef4444' : boxV[2] % 4 == 3 ? '#3b82f6' : '#E2E8F0'} borderRadius={'lg'} onClick={()=>boxF([boxV[0],boxV[1],(boxV[2]+1) % 4,boxV[3]])}>
                    {boxV[2] % 4 == 1 && noneV[2] != 'none' ? <Tooltip label='여러 정보들을 담고있습니다.'><SearchIcon top={'50%'} left={'50%'} transform={'translate(-50%,-50%)'} position={'absolute'} w={'50px'} h={'50px'}/></Tooltip> 
                    : boxV[2] % 4 == 2 && noneV[2] != 'none' ? <Tooltip label='계산기 시스템을 담고있습니다.'><Box top={'50%'} left={'50%'} transform={'translate(-50%,-50%)'} position={'absolute'}>
                        <AddIcon  w={'25px'} h={'25px'}/>
                        <MinusIcon  w={'25px'} h={'25px'}/>
                        <br/>
                        <CloseIcon  w={'25px'} h={'25px'}/>
                        <Box w={'25px'} h={'25px'} display={'inline-block'}><MinusIcon  w={'25px'} h={'25px'}/><Box w={'5px'} h={'5px'} bg={'black'} borderRadius={'50%'} position={'absolute'} top={'46.5px'} left={'35px'}></Box><Box w={'5px'} h={'5px'} bg={'black'} borderRadius={'50%'} position={'absolute'} top={'30px'} left={'35px'}></Box></Box>
                    </Box></Tooltip>
                    : boxV[2] % 4 == 3 && noneV[2] != 'none' ? <Tooltip label='메모장을 담고있습니다.'><CalendarIcon top={'50%'} left={'50%'} transform={'translate(-50%,-50%)'} position={'absolute'} w={'50px'} h={'50px'}/></Tooltip>
                    : boxV[2] % 4 == 0 && can[2] ? 
                    <Tooltip label='같은 크기의 흰색끼리 합칠 수 있습니다.'><div draggable="true" className="w-full h-full" onDragEnd={(e)=>oneF(['3',e.clientX,e.clientY])} onMouseOver={(e)=>oneV[1] == e.clientX && oneV[2] == e.clientY ? oneF([oneV[0]+'3',0,0]) : undefined}></div></Tooltip>
                    : undefined}
                </Box>
                <Box as="button" display={noneV[3]} w={`${whV[6]}px`} h={`${whV[7]}px`} position={'absolute'} bottom={'5px'} right={'5px'} bg={boxV[3] % 4 == 1 ? '#22c55e' : boxV[3] % 4 == 2 ? '#ef4444' : boxV[3] % 4 == 3 ? '#3b82f6' : '#E2E8F0'} borderRadius={'lg'} onClick={()=>boxF([boxV[0],boxV[1],boxV[2],(boxV[3]+1) % 4])}>
                    {boxV[3] % 4 == 1 && noneV[3] != 'none' ? <Tooltip label='여러 정보들을 담고있습니다.'><SearchIcon top={'50%'} left={'50%'} transform={'translate(-50%,-50%)'} position={'absolute'} w={'50px'} h={'50px'}/></Tooltip> 
                    : boxV[3] % 4 == 2 && noneV[3] != 'none' ? <Tooltip label='계산기 시스템을 담고있습니다.'><Box top={'50%'} left={'50%'} transform={'translate(-50%,-50%)'} position={'absolute'}>
                        <AddIcon  w={'25px'} h={'25px'}/>
                        <MinusIcon  w={'25px'} h={'25px'}/>
                        <br/>
                        <CloseIcon  w={'25px'} h={'25px'}/>
                        <Box w={'25px'} h={'25px'} display={'inline-block'}><MinusIcon  w={'25px'} h={'25px'}/><Box w={'5px'} h={'5px'} bg={'black'} borderRadius={'50%'} position={'absolute'} top={'46.5px'} left={'35px'}></Box><Box w={'5px'} h={'5px'} bg={'black'} borderRadius={'50%'} position={'absolute'} top={'30px'} left={'35px'}></Box></Box>
                    </Box></Tooltip>
                    : boxV[3] % 4 == 3 && noneV[3] != 'none' ? <Tooltip label='메모장을 담고있습니다.'><CalendarIcon top={'50%'} left={'50%'} transform={'translate(-50%,-50%)'} position={'absolute'} w={'50px'} h={'50px'}/></Tooltip>
                    : boxV[3] % 4 == 0 && can[3] ? 
                    <Tooltip label='같은 크기의 흰색끼리 합칠 수 있습니다.'><div draggable="true" className="w-full h-full" onDragEnd={(e)=>oneF(['4',e.clientX,e.clientY])} onMouseOver={(e)=>oneV[1] == e.clientX && oneV[2] == e.clientY ? oneF([oneV[0]+'4',0,0]) : undefined}></div></Tooltip>
                    : undefined}
                </Box>
            </Box>
                <Button top={'65%'} left={'50%'} position={'absolute'} transform="translate(-50%,0)" zIndex={99} onClick={()=>{
                    boxV.map((v, i)=>{
                        v == 1 ? boxV[i] = 'Items Info' : undefined
                        v == 2 ? boxV[i] = 'Calculator' : undefined
                        v == 3 ? boxV[i] = 'Memo' : undefined
                        v == 0 ? boxV[i] = 'ETC' : undefined
                        v == 5 ? boxV[i] = '1' : undefined
                        v == 6 ? boxV[i] = '2' : undefined
                        v == 7 ? boxV[i] = '3' : undefined
                        v == 8 ? boxV[i] = '4' : undefined
                    })
                    infoType_F(boxV)
                    setChange(false)
                    console.log(change);
                }}><CheckIcon/></Button>
                {noneV[0] == 'none' || noneV[1] == 'none' || noneV[2] == 'none' || noneV[3] == 'none' || boxV[0] != '' || boxV[1] != '' || boxV[2] != '' || boxV[3] != '' ? <RepeatIcon position={'absolute'} zIndex={99} w={'40px'} h={'40px'} left={'60%'} top={'20%'} bg={'white'} borderRadius={'full'} borderWidth={'5px'} borderColor={'white'} onClick={()=>{whF([150,150,150,150,150,150,150,150]);noneF(['','','','']);boxF([0,0,0,0]);canF([true,true,true,true])}}/> : undefined} {/* 초기화 하시겠습니까? 버튼 만들삼*/}
            {/*boxV로 */}
            
    </div>
}