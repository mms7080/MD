import React, { useEffect, useRef, useState} from "react";
import Mainpage from "./mainpage";
import Infos from './infos'
import Calculator from "./calculator";
import Memo from './memo'
import {RepeatClockIcon} from '@chakra-ui/icons'
import {Tooltip} from '@chakra-ui/react'

export default ()=>{
    const [infoType, infoType_F] = useState(['','','','']);
    const [change, setChange] = useState(true)
    const [boxV, boxF] = useState([0,0,0,0]);
    const [noneV,noneF] = useState(['','','',''])
    const [can,canF] = useState([true,true,true,true])
    const [whV,whF] = useState([150,150,150,150,150,150,150,150])
    //https://velog.io/@jhyun_k/js-calculator
    //1+2+3
    return <div className="w-[100vw] h-[100vh] bg-[#c1c1b7]">
            <Mainpage boxV={boxV} boxF={boxF} infoType={infoType} infoType_F={infoType_F} change={change} setChange={setChange}
            noneF={noneF} noneV={noneV} can={can} canF={canF} whF={whF} whV={whV}/>
            {console.log(infoType)}
            {/* <GoogleOAuthProvider clientId={'161914586184-gk5f0qf86fgl4vd51mfp4mieb8q4mcg0.apps.googleusercontent.com'}>
                <GoogleLogin
                    onSuccess={credentialResponse => {
                        console.log(credentialResponse);
                    }}
                    onError={() => {
                        console.log('Login Failed');
                    }}
                />
            </GoogleOAuthProvider> */}

            <div onClick={()=>{
                infoType_F(['','','','']);
                boxF([0,0,0,0]);
                setChange(true);
                noneFuseState(['','','','']);
                canF([true,true,true,true]);
                whF([150,150,150,150,150,150,150,150]);
            }}><Tooltip label='첫화면으로 이동'><RepeatClockIcon top={'10px'} left={'10px'} position={'absolute'} display={change?'none':''} boxSize={10} bg={'white'} borderRadius={'50%'} p={'2px'} zIndex={99} /></Tooltip></div>
            {infoType[1] == '1' && infoType[2] == '1' && infoType[3] == '1' && infoType[0] == 'Items Info' || infoType[0] == 'Runes Info'   ?
                <Infos infoType={infoType} infoType_F={infoType_F} 
                    w={'w-[99vw]'} h={'h-[99vh]'}
                    show={'top-[0px] left-[0px]'} rule={0}
                    select1={['Items Info',infoType[1],infoType[2],infoType[3]]}
                    select2={['Runes Info',infoType[1],infoType[2],infoType[3]]}
                /> 
            : 
            infoType[1] == '1' && infoType[0] == 'Items Info' || infoType[0] == 'Runes Info'  ? 
                <Infos infoType={infoType} infoType_F={infoType_F} 
                    w={'w-[99vw]'} h={'h-[49vh]'}   
                    show={'top-[0px] left-[0px]'} rule={0}
                    select1={['Items Info',infoType[1],infoType[2],infoType[3]]}
                    select2={['Runes Info',infoType[1],infoType[2],infoType[3]]}
                /> 
            :
            infoType[2] == '1' && infoType[0] == 'Items Info' || infoType[0] == 'Runes Info' ? 
                <Infos infoType={infoType} infoType_F={infoType_F} 
                    w={'w-[49vw]'} h={'h-[99vh]'}   
                    show={'top-[0px] left-[0px]'} rule={0}
                    select1={['Items Info',infoType[1],infoType[2],infoType[3]]}
                    select2={['Runes Info',infoType[1],infoType[2],infoType[3]]}
                /> 
            : 
            infoType[0] == 'Items Info' || infoType[0] == 'Runes Info'? 
                <Infos infoType={infoType} infoType_F={infoType_F} 
                        w={'w-[49vw]'} h={'h-[49vh]'}   
                        show={'top-[0px] left-[0px]'} rule={0}
                        select1={['Items Info',infoType[1],infoType[2],infoType[3]]}
                        select2={['Runes Info',infoType[1],infoType[2],infoType[3]]}
                /> 
            :undefined
            }
            {infoType[3] == '2' && infoType[1] == 'Items Info' || infoType[1] == 'Runes Info' ?
                <Infos infoType={infoType} infoType_F={infoType_F} 
                    w={'w-[49vw]'} h={'h-[99vh]'}   
                    show={'top-[0px] right-[0px]'} rule={1}
                    select1={[infoType[0],'Items Info',infoType[2],infoType[3]]}
                    select2={[infoType[0],'Runes Info',infoType[2],infoType[3]]}
                />
            :
            infoType[1] == 'Items Info' || infoType[1] == 'Runes Info'?
                <Infos infoType={infoType} infoType_F={infoType_F} 
                    show={'top-[0px] right-[0px]'} rule={1}
                    select1={[infoType[0],'Items Info',infoType[2],infoType[3]]}
                    select2={[infoType[0],'Runes Info',infoType[2],infoType[3]]}
                />
            :undefined}
            {infoType[3] == '3' && infoType[2] == 'Items Info' || infoType[2] == 'Runes Info' ?
                <Infos infoType={infoType} infoType_F={infoType_F} 
                    w={'w-[99vw]'} h={'h-[49vh]'}   
                    show={'bottom-[0px] left-[0px]'} rule={2}
                    select1={[infoType[0],infoType[1],'Items Info',infoType[3]]}
                    select2={[infoType[0],infoType[1],'Runes Info',infoType[3]]}
                />    
            :
            infoType[2] == 'Items Info' || infoType[2] == 'Runes Info'?
                <Infos infoType={infoType} infoType_F={infoType_F} 
                    show={'bottom-[0px] left-[0px]'} rule={2}
                    select1={[infoType[0],infoType[1],'Items Info',infoType[3]]}
                    select2={[infoType[0],infoType[1],'Runes Info',infoType[3]]}
                />    
            :undefined}
            {infoType[3] == 'Items Info' || infoType[3] == 'Runes Info'?
                <Infos infoType={infoType} infoType_F={infoType_F} 
                    show={'bottom-[0px] right-[0px]'} rule={3}
                    select1={[infoType[0],infoType[1],infoType[2],'Items Info']}
                    select2={[infoType[0],infoType[1],infoType[2],'Runes Info']}
                />
            :undefined}

            {infoType[1] == '1' && infoType[2] == '1' && infoType[3] == '1' && infoType[0] == 'Calculator' ?
                <div className={`w-[99vw] h-[99vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg top-[0px] left-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-red-500 w-full">{infoType[0]}</div>
                    </div>
                    <Calculator/>
                </div>
            :
            infoType[1] == '1' && infoType[0] == 'Calculator'  ? 
                <div className={`w-[99vw] h-[49vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg top-[0px] left-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-red-500 w-full">{infoType[0]}</div>
                    </div>
                    <Calculator/>
                </div>
            :
            infoType[2] == '1' && infoType[0] == 'Calculator' ? 
                <div className={`w-[49vw] h-[99vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg top-[0px] left-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-red-500 w-full">{infoType[0]}</div>
                    </div>
                    <Calculator/>
                </div>
            : 
            infoType[0] == 'Calculator'? 
                <div className={`w-[49vw] h-[49vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg  top-[0px] left-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-red-500 w-full">{infoType[0]}</div>
                    </div>
                    <Calculator/>
                </div>
            :undefined
            }
            {infoType[3] == '2' && infoType[1] == 'Calculator' ?
                <div className={`w-[49vw] h-[99vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg absolute top-[0px] right-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-red-500 w-full">{infoType[1]}</div>
                    </div>
                    <Calculator/>
                </div>
            :
            infoType[1] == 'Calculator'?
                
            <div className={`w-[49vw] h-[49vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg absolute top-[0px] right-[0px]`}> 
                <div className=" h-[40px] relative z-10 w-[inherit]">
                    <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-red-500 w-full">{infoType[1]}</div>
                </div>
                <Calculator/>
            </div>
            :undefined}
            {infoType[3] == '3' && infoType[2] == 'Calculator' ?
                
                <div className={`w-[99vw] h-[49vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg absolute bottom-[0px] left-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-red-500 w-full">{infoType[2]}</div>
                    </div>
                    <Calculator/>
                </div>  
            :
            infoType[2] == 'Calculator'?
            <div className={`w-[49vw] h-[49vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg absolute bottom-[0px] left-[0px]`}> 
                <div className=" h-[40px] relative z-10 w-[inherit]">
                    <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-red-500 w-full">{infoType[2]}</div>
                </div>
                <Calculator/>
            </div>  
            :undefined}
            {infoType[3] == 'Calculator'?
                <div className={`w-[49vw] h-[49vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg absolute bottom-[0px] right-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-red-500 w-full">{infoType[3]}</div>
                    </div>
                    <Calculator/>
                </div>
            :undefined}

            {infoType[1] == '1' && infoType[2] == '1' && infoType[3] == '1' && infoType[0] == 'Memo' ?
                <div className={`w-[99vw] h-[99vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg top-[0px] left-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-blue-500 w-full">{infoType[0]}</div>
                    </div>
                    <Memo/>
                </div>
            :
            infoType[1] == '1' && infoType[0] == 'Memo'  ? 
            <div className={`w-[99vw] h-[49vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg top-[0px] left-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-blue-500 w-full">{infoType[0]}</div>
                    </div>
                    <Memo/>
                </div>
            :
            infoType[2] == '1' && infoType[0] == 'Memo' ? 
            <div className={`w-[49vw] h-[99vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg top-[0px] left-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-blue-500 w-full">{infoType[0]}</div>
                    </div>
                    <Memo/>
                </div>
            : 
            infoType[0] == 'Memo'? 
            <div className={`w-[49vw] h-[49vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg absolute top-[0px] left-[0px]`}> 
                <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-blue-500 w-full">{infoType[0]}</div>
                </div>
                <Memo/>
            </div>
            :undefined
            }
            {infoType[3] == '2' && infoType[1] == 'Memo' ?
                <div className={`w-[49vw] h-[99vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg absolute top-[0px] right-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-blue-500 w-full">{infoType[1]}</div>
                    </div>
                    <Memo/>
                </div>
            :
            infoType[1] == 'Memo'?
                
            <div className={`w-[49vw] h-[49vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg absolute top-[0px] right-[0px]`}> 
                <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-blue-500 w-full">{infoType[1]}</div>
                    </div>
                    <Memo/>
            </div>
            :undefined}
            {infoType[3] == '3' && infoType[2] == 'Memo' ?
                
                <div className={`w-[99vw] h-[49vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg absolute bottom-[0px] left-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-blue-500 w-full">{infoType[2]}</div>
                    </div>
                    <Memo/>
                </div>  
            :
            infoType[2] == 'Memo'?
            <div className={`w-[49vw] h-[49vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg absolute bottom-[0px] left-[0px]`}> 
                <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-blue-500 w-full">{infoType[2]}</div>
                    </div>
                    <Memo/>
            </div>  
            :undefined}
            {infoType[3] == 'Memo'?
                <div className={`w-[49vw] h-[49vh] overflow-y-hidden overflow-x-hidden border-2 border-white m-[5px] rounded-lg absolute bottom-[0px] right-[0px]`}> 
                    <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-blue-500 w-full">{infoType[3]}</div>
                    </div>
                    <Memo/>
                </div>
            :undefined}
        </div>}

 
/*
    3. 구글 인증 로그인
    4. 공유, 프로필
    
 */