import React, { useRef, useState} from "react";
import { Tooltip} from '@chakra-ui/react'

export default ()=>{
    const [inner,setInner] = useState()
    const array = useRef([])
    const index = useRef(0)
    const [qustn,setQustn] = useState(0)
    const [qustn2,setQustn2] = useState(0)
    //array.current[] = asdf
    //array.current = []
    return <><div className="w-[95%] mx-[2.5%] border-2 my-[1rem] bg-white rounded-md h-[7.5%] px-[0.6rem] text-xl">{inner}</div>
    <div className="w-[95%] mx-[2.5%] h-[70%] bg-gray-200 rounded-lg grid grid-rows-5 grid-cols-6 gap-[0.5rem] p-[0.3rem] ">
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] + 35
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 35
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><img src="/image/icon/공격력.jpg" className="top-1/3 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto h-[50%]"/><div className="bottom-[0px] absolute left-1/2 -translate-x-1/2 text-[#EC8D34] font-semibold w-full">(35)</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] + 20
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 20
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><img src="/image/icon/주문력.jpg" className="top-1/3 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto h-[50%]"/><div className="bottom-[0px] absolute left-1/2 -translate-x-1/2 text-[#786CFF] font-semibold w-full">(20)</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{///
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current] =  '/'
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">/</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{//*
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/'){
                array.current[index.current] =  '*'
                index.current = index.current + 1
                setInner(array.current.map(v=>v)) //tnwjd
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">*</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{//-
            if(array.current[index.current-1] != '-' ){
                array.current[index.current] =  '-'
                index.current = index.current + 1
                setInner(array.current.map(v=>v)) //음수로 만드는 - 만들기
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">-</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{//+
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current] =  '+'
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">+</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] + 25
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 25
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><img src="/image/icon/공격_속도.jpg" className="top-1/3 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto h-[50%]"/><div className="bottom-[0px] absolute left-1/2 -translate-x-1/2 text-[#ffe384] font-semibold w-full">(25)</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] + 40
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 40
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><img src="/image/icon/치명타_확률.jpg" className="top-1/3 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto h-[50%]"/><div className="bottom-[0px] absolute left-1/2 -translate-x-1/2 text-[#ce1c42] font-semibold w-full">(40)</div></button>
        <button className="w-full h-full rounded-lg bg-white relative " onClick={()=>{//7
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] * 10 + 7
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 7
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">7</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{//8
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] * 10 + 8
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 8
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">8</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{//9
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] * 10 + 9
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 9
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">9</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{
            console.log(qustn2);
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                if(!isNaN(qustn2)){
                    array.current[index.current-1] = array.current[index.current-1] + parseInt(qustn)
                    setInner(array.current.map(v=>v))
                }
                
            }
            else{
                if(!isNaN(qustn2) && qustn2!=0){
                    array.current[index.current] = parseInt(qustn)
                    index.current = index.current + 1
                    setInner(array.current.map(v=>v))
                }
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]"><Tooltip label='숫자만 입력해주세요' ><input className="w-full text-center text-base" placeholder="변수1" onChange={(e)=>setQustn(e.target.value)}/></Tooltip></div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] + 20
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 20
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><img src="/image/icon/방어력.jpg" className="top-1/3 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto h-[50%]"/><div className="bottom-[0px] absolute left-1/2 -translate-x-1/2 text-[#F3BA58] font-semibold w-full">(20)</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] + 18
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 18
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><img src="/image/icon/마법_저항력.jpg" className="top-1/3 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto h-[50%]"/><div className="bottom-[0px] absolute left-1/2 -translate-x-1/2 text-[#0acbe6] font-semibold w-full">(18)</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{//4
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] * 10 + 4
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 4
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">4</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{//5
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] * 10 + 5
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 5
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">5</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{//6
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] * 10 + 6
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 6
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">6</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{
            console.log(qustn2);
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                if(!isNaN(qustn2)){
                    array.current[index.current-1] = array.current[index.current-1] + parseInt(qustn2)
                    setInner(array.current.map(v=>v))
                }
                
            }
            else{
                if(!isNaN(qustn2) && qustn2!=0){
                    array.current[index.current] = parseInt(qustn2)
                    index.current = index.current + 1
                    setInner(array.current.map(v=>v))
                }
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]"><Tooltip label='숫자만 입력해주세요'><input className="w-full text-center text-base" placeholder="변수2" onChange={(e)=>setQustn2(e.target.value)}/></Tooltip></div></button>
        <div className="w-full h-full rounded-lg bg-white relative flex">
            <button className="w-1/2 h-full border-r-2 border-gray-200 active:bg-gray-300" onClick={()=>{
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.' && array.current[index.current-2] != '.'){
                array.current[index.current-1] = array.current[index.current-1] + 2.666
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 2.666
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }}}>
                <img src="/image/icon/체력.jpg" className="top-1/3 left-[25%] -translate-x-1/2 absolute -translate-y-1/2 w-auto h-[50%]"/>
                <div className="top-[100%] left-[25%] -translate-x-1/2 absolute -translate-y-[100%] text-[#209A5E] font-semibold w-auto">(2.6)</div>
            </button>
            <button className="w-1/2 h-full border-l-2 border-gray-200 active:bg-gray-300" onClick={()=>{
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] + 12
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 12
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }}}>
                <img src="/image/icon/기본_체력_재생.jpg" className="top-1/3 right-[25%] translate-x-1/2 absolute -translate-y-1/2 w-auto h-[50%]"/>
                <div className="top-[100%] right-[25%] translate-x-1/2 absolute -translate-y-[100%] text-[#209A5E] font-semibold w-auto">(12)</div>
            </button>
        </div>
        <div className="w-full h-full rounded-lg bg-white relative flex">
            <button className="w-1/2 h-full border-r-2 border-gray-200 active:bg-gray-300" onClick={()=>{
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.' && array.current[index.current-2] != '.'){
                array.current[index.current-1] = array.current[index.current-1] + 1.4
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 1.4
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
            }}>
                <img src="/image/icon/마나.jpg" className="top-1/3 left-[25%] -translate-x-1/2 absolute -translate-y-1/2 w-auto h-[50%]"/>
                <div className="top-[100%] left-[25%] -translate-x-1/2 absolute -translate-y-[100%] text-[#189be7] font-semibold w-auto">(1.4)</div>
            </button>
            <button className="w-1/2 h-full border-l-2 border-gray-200 active:bg-gray-300" onClick={()=>{
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] + 10
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 10
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
            }}>
                <img src="/image/icon/기본_마나_재생.jpg" className="top-1/3 right-[25%] translate-x-1/2 absolute -translate-y-1/2 w-auto h-[50%]"/>
                <div className="top-[100%] right-[25%] translate-x-1/2 absolute -translate-y-[100%] text-[#189be7] font-semibold w-auto">(10)</div>
            </button>
        </div>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{//1 && array.current[index.current-1] != '.' && array.current[index.current-2] != '.'
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] * 10 + 1
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 1
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">1</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{//2
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] * 10 + 2
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 2
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">2</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{//3
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] * 10 + 3
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 3
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">3</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{
            if(index.current > 0 && array.current){
                index.current = index.current-1
                array.current.pop()
                setInner(array.current.map(v=>v));
            }
            
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">&#60;=</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.'&& array.current[index.current-1] != '('){
                array.current[index.current-1] = array.current[index.current-1] + 50
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 50
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><img src="/image/icon/스킬_가속.jpg" className="top-1/3 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto h-[50%]"/><div className="bottom-[0px] absolute left-1/2 -translate-x-1/2 text-[#e6ddc9] font-semibold w-full">(50)</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{
            if(index.current - 1 >= 0 && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.' && array.current[index.current-2] != '.'){
                array.current[index.current-1] = array.current[index.current-1] + 12
                setInner(array.current.map(v=>v))
            }
            else{
                array.current[index.current] = 12
                index.current = index.current + 1
                setInner(array.current.map(v=>v))
            }
        }}><img src="/image/icon/이동_속도.jpg" className="top-1/3 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto h-[50%]"/><div className="bottom-[0px] absolute left-1/2 -translate-x-1/2 text-[#e6ddc9] font-semibold w-full">(12)</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{
            if(array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.' && array.current[index.current-2] != '.' ){
                array.current[index.current] =  '.'
                index.current = index.current + 1
                setInner(array.current.map(v=>v)) 
            }
            console.log(array.current);
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">.</div></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300" onClick={()=>{//0
            if(array.current[index.current-1] != undefined && array.current[index.current-1] != '+' && array.current[index.current-1] != '-' && array.current[index.current-1] != '*' && array.current[index.current-1] != '/' && array.current[index.current-1] != '.' && array.current[index.current-2] != '.'){
                array.current[index.current-1] = array.current[index.current-1] * 10
                setInner(array.current.map(v=>v))
            }
        }}><button className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">0</button></button>
        <button className="w-full h-full rounded-lg bg-white relative active:bg-gray-300 col-span-2" onClick={()=>{
            
            if(array.current.length > 1 && array.current[array.current.length -1] != '+' || array.current[array.current.length -1] != '-' || !array.current[array.current.length -1] != '*' || !array.current[array.current.length -1] != '/'){
                let cal = [];
                let ope = [];
                //
                console.log('asdfasdf');
                for (let i = 0; i < array.current.length; i++) {
                    if(array.current[i] == '.'){
                        console.log(array.current[i + 1]);
                        let a = array.current[i+1]
                        while (a > 1) { 
                            a = a / 10
                        }
                        array.current[i+1] = array.current[i-1]+a
                        array.current[i-1] = null
                        array.current[i] = null
                    }
                } 
                for (let i = 0; i < array.current.length; i++) {
                    if(array.current[i] == '-'){
                        if(array.current[i-1] == '+' || array.current[i-1] == '-' || array.current[i-1] == '*' || array.current[i-1] == '/'){
                            array.current[i+1] = array.current[i+1] * -1
                            array.current[i] = null
                        }
                    }
                }
                array.current.map(v=>v!=null ? cal.push(v) : undefined)
                array.current = []
                array.current.push(...cal)
                cal = []
                for (let j = 0; j < 10; j++) {
                    for (let i = 0; i < index.current; i++) {
                        if(array.current[i] == '*' && array.current[i+1] && !isNaN(array.current[i+1])){
                            let a = array.current[i]
                            array.current[i] = array.current[i+1]
                            array.current[i+1] = a 
                        }
                        if(array.current[i] == '/' && array.current[i+1] && !isNaN(array.current[i+1])){
                            let a = array.current[i]
                            array.current[i] = array.current[i+1]
                            array.current[i+1] = a 
                        }
                        if(array.current[i] == '+' && array.current[i+1] && !isNaN(array.current[i+1])){
                            ope.push(array.current[i])
                            array.current[i] = null
                        }
                        if(array.current[i] == '-' && array.current[i+1] && !isNaN(array.current[i+1])){
                            ope.push(array.current[i])
                            array.current[i] = null
                        }
                    }
                }
                console.log(array.current);
                for(let i = 0; i < ope.length; i++)array.current.push(ope[i])
                array.current.map(v=>v!=null ? cal.push(v) : undefined)
                array.current = []
                array.current.push(...cal)
                while(array.current.length > 1){
                    for(let i = 0; i < array.current.length; i++){
                        if(array.current[i] == '*'){
                            let j = 0;
                            let jj = 0;
                            let left = 0;
                            let right = 0;
                            for(j = i; j > 0;j--){
                                if(!isNaN(array.current[j])){
                                    left = array.current[j]
                                    array.current[j] = null
                                    break
                                }
                            }
                            for(jj = j-1; jj >= 0;jj--){
                                if(!isNaN(array.current[jj])){
                                    right = array.current[jj]
                                    array.current[jj] = null
                                    break
                                }
                            }
                            cal = []
                            array.current[i] = left * right;
                            array.current.map(v=>v!=null ? cal.push(v) : undefined)
                            console.log(cal);
                            array.current = []
                            array.current.push(...cal)
                            break
                        };
                        if(array.current[i] == '/'){
                            let j = 0;
                            let jj = 0;
                            let left = 0;
                            let right = 0;
                            for(j = i; j > 0;j--){
                                if(!isNaN(array.current[j])){
                                    right = array.current[j]
                                    array.current[j] = null
                                    break
                                }
                            }
                            for(jj = j-1; jj >= 0;jj--){
                                if(!isNaN(array.current[jj])){
                                    left = array.current[jj]
                                    array.current[jj] = null
                                    break
                                }
                            }
                            cal = []
                            array.current[i] = left / right;
                            array.current.map(v=>v!=null ? cal.push(v) : undefined)
                            console.log(cal);
                            array.current = []
                            array.current.push(...cal)
                            break
                        };
                        if(array.current[i] == '+'){
                            let j = 0;
                            let jj = 0;
                            let left = 0;
                            let right = 0;
                            for(j = i; j > 0;j--){
                                if(!isNaN(array.current[j])){
                                    left = array.current[j]
                                    array.current[j] = null
                                    break
                                }
                            }
                            for(jj = j-1; jj >= 0;jj--){
                                if(!isNaN(array.current[jj])){
                                    right = array.current[jj]
                                    array.current[jj] = null
                                    break
                                }
                            }
                            cal = []
                            array.current[i] = left + right;
                            array.current.map(v=>v!=null ? cal.push(v) : undefined)
                            console.log(cal);
                            array.current = []
                            array.current.push(...cal)
                            break
                        };
                        if(array.current[i] == '-'){
                            let j = 0;
                            let jj = 0;
                            let left = 0;
                            let right = 0;
                                for(j = i; j > 0;j--){
                                    if(!isNaN(array.current[j])){
                                        left = array.current[j]
                                        array.current[j] = null
                                        break
                                    }
                                }
                                for(jj = j-1; jj >= 0;jj--){
                                    if(!isNaN(array.current[jj])){
                                        right = array.current[jj]
                                        array.current[jj] = null
                                        break
                                    }
                                }
                                cal = []
                                if(left < 0 && right > 0){
                                    array.current[i] = left - right;
                                }
                                else{
                                    array.current[i] = -left + right;
                                }
                                array.current.map(v=>v!=null ? cal.push(v) : undefined)
                                console.log(cal);
                                array.current = []
                                array.current.push(...cal)
                                break
                            }
                        };
                    }
                array.current[0] == 0 ? index.current = 0 :index.current = 1
                if(!isNaN(array.current[0]) && array.current[0] < 0){
                    array.current[1] = array.current[0] * -1
                    array.current[0] = '-';
                    index.current = index.current + 1
                    // if(toString(array.current[1]).includes('.')){
                        let a = `${array.current[1]}`
                        console.log(a);
                        if (a.includes('.')) {
                            array.current[1] = parseInt(a.slice(0,a.indexOf('.')))
                            array.current[2] = '.'
                            array.current[3] = parseInt(a.slice(a.indexOf('.')+1,a.length));
                            index.current = 4
                        }
                    // 1 - 1.5
                }
                
                setInner(array.current);
                console.log(array.current);
            }
            else{
                console.log('asdfasdf'+array.current);console.log((3));
            }
            //-1.2 => -,1,.,2
            //1.123456789 => 1.12346
            //된다면 공유그것도
            //메모장 조금더 보안
            //css 좀 고치기
            
        }}><div className="top-1/2 left-1/2 absolute -translate-x-1/2 -translate-y-1/2 w-auto font-medium text-[1.3rem]">enter</div></button>
    </div></>
}