import React, { useState} from "react";
import {Button,Drawer, DrawerBody, DrawerFooter, DrawerHeader, DrawerOverlay, DrawerContent, DrawerCloseButton, useDisclosure, Menu, MenuButton, MenuList, MenuItem, Checkbox, Stack,
    Radio, RadioGroup} from '@chakra-ui/react'
import {SettingsIcon, ChevronUpIcon} from '@chakra-ui/icons'
import Iteminfo from "./iteminfo";
import Runeinfo from './runeinfo';

export default ({w = 'w-[49vw]',h = 'h-[49vh]',show,rule,infoType,infoType_F, select1, select2})=>{
    const { isOpen, onOpen, onClose } = useDisclosure()

    const [checkedItems, setCheckedItems] = useState([false, false, false, false, false,false, false, false, false])
    const allChecked = checkedItems.every(Boolean)
    const isIndeterminate = checkedItems.some(Boolean) && !allChecked
    const [value, setValue] = useState('1')
    const [value2, setValue2] = useState('2')

 return <div className={`absolute ${w} ${h} ${infoType[rule] == 'Items Info' ? 'overflow-y-auto' : 'overflow-y-hidden'} overflow-x-hidden border-2 border-white m-[5px] rounded-lg ${show}`}> {/*iteminfo, , ,*/}
                <div className=" h-[40px] relative z-10 w-[inherit]">
                        <div className="absolute pl-[10px] text-[25px] text-white font-medium [text-shadow:_0_2px_3px_rgb(0_0_0_/_40%)] bg-green-500 w-full">{infoType[rule]}</div>
                        <SettingsIcon boxSize={8} className="absolute top-2/4 -translate-y-2/4 right-7" onClick={onOpen}/>
                        {infoType[rule] == 'Items Info' ? <Drawer
                            isOpen={isOpen}
                            placement='right'
                            onClose={onClose}
                        >
                            <DrawerOverlay />
                            <DrawerContent>
                                <DrawerCloseButton p={'5px'} top={'4px'} color={"white"}/>
                                <DrawerHeader p={'5px'} bg={"black"} color={"white"} pl={'10px'}>설정</DrawerHeader>
                                <DrawerBody display={'relative'}>
                                    <Checkbox
                                        isChecked={allChecked}
                                        isIndeterminate={isIndeterminate}
                                        onChange={(e) => setCheckedItems([e.target.checked, e.target.checked, e.target.checked, e.target.checked, e.target.checked, e.target.checked])}
                                    >
                                        전체
                                    </Checkbox>
                                    <Stack pl={6} mt={1} spacing={1}>
                                        <Checkbox
                                        isChecked={checkedItems[0]}
                                        onChange={(e) => setCheckedItems([e.target.checked, checkedItems[1], checkedItems[2], checkedItems[3], checkedItems[4], checkedItems[5], checkedItems[6], checkedItems[7], checkedItems[8]])}
                                        >
                                        장화
                                        </Checkbox>
                                        <Checkbox
                                        isChecked={checkedItems[1]}
                                        onChange={(e) => setCheckedItems([checkedItems[0], e.target.checked, checkedItems[2], checkedItems[3], checkedItems[4], checkedItems[5], checkedItems[6], checkedItems[7], checkedItems[8]])}
                                        >
                                        시작
                                        </Checkbox>
                                        <Checkbox
                                        isChecked={checkedItems[2]}
                                        onChange={(e) => setCheckedItems([checkedItems[0], checkedItems[1], e.target.checked, checkedItems[3], checkedItems[4], checkedItems[5], checkedItems[6], checkedItems[7], checkedItems[8]])}
                                        >
                                        기본
                                        </Checkbox>
                                        <Checkbox
                                        isChecked={checkedItems[3]}
                                        onChange={(e) => setCheckedItems([checkedItems[0], checkedItems[1], checkedItems[2], e.target.checked, checkedItems[4], checkedItems[5], checkedItems[6], checkedItems[7], checkedItems[8]])}
                                        >
                                        서사
                                        </Checkbox>
                                        <Checkbox
                                        isChecked={checkedItems[4]}
                                        onChange={(e) => setCheckedItems([checkedItems[0], checkedItems[1], checkedItems[2], checkedItems[3], e.target.checked, checkedItems[5], checkedItems[6], checkedItems[7], checkedItems[8]])}
                                        >
                                        전설
                                        </Checkbox>
                                        <Checkbox
                                        isChecked={checkedItems[5]}
                                        onChange={(e) => setCheckedItems([checkedItems[0], checkedItems[1], checkedItems[2], checkedItems[3], checkedItems[4], e.target.checked, checkedItems[6], checkedItems[7], checkedItems[8]])}
                                        >
                                        소모품
                                        </Checkbox>
                                        <Checkbox
                                        isChecked={checkedItems[6]}
                                        onChange={(e) => setCheckedItems([checkedItems[0], checkedItems[1], checkedItems[2], checkedItems[3], checkedItems[4], checkedItems[5], e.target.checked, checkedItems[7], checkedItems[8]])}
                                        >
                                        여눈
                                        </Checkbox>
                                        <Checkbox
                                        isChecked={checkedItems[7]}
                                        onChange={(e) => setCheckedItems([checkedItems[0], checkedItems[1], checkedItems[2], checkedItems[3], checkedItems[4], checkedItems[5], checkedItems[6], e.target.checked, checkedItems[8]])}
                                        >
                                        오른
                                        </Checkbox>
                                        <Checkbox
                                        isChecked={checkedItems[8]}
                                        onChange={(e) => setCheckedItems([checkedItems[0], checkedItems[1], checkedItems[2], checkedItems[3], checkedItems[4], checkedItems[5], checkedItems[6], checkedItems[7], e.target.checked])}
                                        >
                                        칼바람
                                        </Checkbox>
                                    </Stack>
                                </DrawerBody>
                                <DrawerFooter bg={'black'}>
                                    <Menu>
                                        <MenuButton as={Button} rightIcon={<ChevronUpIcon />} _hover={'none'} _active={'none'} textColor={"white"} w={'100%'} bg={'#22C55E'}>
                                            {infoType[rule]}
                                        </MenuButton>
                                        <MenuList p={'0px'} minW={'272px'} bg={"black"} borderRadius={'5px'} overflow={'hidden'}>
                                            {infoType[rule] == 'Items Info' ? undefined : <MenuItem onClick={()=>infoType_F(select1)} textColor={"white"} bg={'#22C55E'} fontWeight={500} w={'100%'} border={'5px'}>Items Info</MenuItem>}
                                            {infoType[rule] == 'Runes Info' ? undefined : <MenuItem onClick={()=>infoType_F(select2)} textColor={"white"} bg={'#22C55E'} fontWeight={500} w={'100%'} border={'5px'}>Runes Info</MenuItem>}
                                        </MenuList>
                                    </Menu>
                                </DrawerFooter>
                            </DrawerContent>
                        </Drawer>:
                        infoType[rule] == 'Runes Info' ? <Drawer
                            isOpen={isOpen}
                            placement='right'
                            onClose={onClose}
                        >
                            <DrawerOverlay />
                            <DrawerContent>
                                <DrawerCloseButton p={'5px'} top={'4px'} color={"white"}/>
                                <DrawerHeader p={'5px'} bg={"black"} color={"white"} pl={'10px'}>설정</DrawerHeader>
                                <DrawerBody display={'relative'}>
                                <RadioGroup onChange={setValue} value={value}>
                                    <Stack spacing={1}>
                                        <Radio value='1'>정밀</Radio>
                                        <Radio value='2'>지배</Radio>
                                        <Radio value='3'>마법</Radio>
                                        <Radio value='4'>결의</Radio>
                                        <Radio value='5'>영감</Radio>
                                    </Stack>
                                </RadioGroup>
                                <RadioGroup onChange={setValue2} value={value2}>
                                    <Stack pl={6} mt={1} spacing={1}>
                                        {value == '1' ? undefined : <Radio value='1'>정밀(보조룬)</Radio>}
                                        {value == '2' ? undefined : <Radio value='2'>지배(보조룬)</Radio>}
                                        {value == '3' ? undefined : <Radio value='3'>마법(보조룬)</Radio>}
                                        {value == '4' ? undefined : <Radio value='4'>결의(보조룬)</Radio>}
                                        {value == '5' ? undefined : <Radio value='5'>영감(보조룬)</Radio>}
                                    </Stack>
                                    </RadioGroup>
                                </DrawerBody>
                                <DrawerFooter bg={'black'}>
                                    <Menu>
                                        <MenuButton as={Button} rightIcon={<ChevronUpIcon />} _hover={'none'} _active={'none'} textColor={"white"} w={'100%'}bg={'#22C55E'}>
                                            {infoType[rule]}
                                        </MenuButton>
                                        <MenuList p={'0px'} minW={'272px'} bg={"black"} borderRadius={'5px'} overflow={'hidden'}>
                                            {infoType[rule] == 'Items Info' ? undefined : <MenuItem onClick={()=>infoType_F(select1)} textColor={"white"} bg={'#22C55E'} fontWeight={500} w={'100%'} border={'5px'}>Items Info</MenuItem>}
                                            {infoType[rule] == 'Runes Info' ? undefined : <MenuItem onClick={()=>infoType_F(select2)} textColor={"white"} bg={'#22C55E'} fontWeight={500} w={'100%'} border={'5px'}>Runes Info</MenuItem>}
                                        </MenuList>
                                    </Menu>
                                </DrawerFooter>
                            </DrawerContent>
                        </Drawer>:undefined}
                </div>
                {infoType[rule] == 'Items Info' ? <Iteminfo checkedItems={checkedItems} setCheckedItems={setCheckedItems} allChecked={allChecked} isIndeterminate={isIndeterminate}/> : undefined}
                {infoType[rule] == 'Runes Info' ? <Runeinfo value={value} value2={value2}/> : undefined}
        
        </div>  
}