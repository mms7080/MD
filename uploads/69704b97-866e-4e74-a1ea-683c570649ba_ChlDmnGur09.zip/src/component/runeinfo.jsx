import React from "react";
import {
    Popover, PopoverTrigger, PopoverContent, PopoverHeader, PopoverBody, PopoverFooter, PopoverArrow,
    Tooltip,
    Img
  } from '@chakra-ui/react'
import {SettingsIcon, ChevronUpIcon, RepeatIcon} from '@chakra-ui/icons'


function PopoverFunc({img, name, body, imgstyle, textstyle}){
    return <Popover> 
        <PopoverTrigger>
            <div className="flex h-full justify-center text-center relative">
                <img className={`m-auto mt-[5%] ${imgstyle}`} src={`/image/rune/${img}.jpg`}/>
                <div className={`text-[#e6ddc9] text-[15px] font-bold absolute top-[66%] break-all ${textstyle}`}>{name}</div>
            </div>
        </PopoverTrigger>
        <PopoverContent bg={'#061118'} w={'auto'} minW={'200px'} maxW={'300px'} borderColor={'#45432a'} borderWidth={'2px'}>
            <PopoverArrow bg={'#061118'}/>
            <PopoverBody color={'#e6ddc9'}>
                <div className="justify-start flex mb-[5px] ">{name}</div>
                    <div className="text-left flex text-[0.8rem] text-[#a09b8c]"><div dangerouslySetInnerHTML={{ __html: body}}></div>
                </div>
            </PopoverBody>
        </PopoverContent>
    </Popover>
}

function 정밀({type}){
    return <>
            <div className={`bg-[#061118] p-[15px] border-4 border-[#bba96f] h-[100%] w-[100%] z-[0] min-w-[250px] box-border min-h-[300px]`}>
                <div className="relative border-b-2 border-[#bba96f] pt-[37px] pb-[15px] h-[17.5%]">
                    <img className="w-[10%] max-w-[60px] absolute top-[55%] left-1/2 -translate-x-1/2 -translate-y-1/2" src="/image/rune/정밀.jpg"/>
                    <img className="w-[20%] max-w-[110px] left-1/2 absolute top-[55%] -translate-x-1/2 -translate-y-1/2" src="/image/rune/정밀테두리.jpg"/>
                </div>
                <div className={`flex border-b-2 border-[#bba96f] h-[22.5%] ${type == 'sub' ? '[display:none]' : undefined}`}>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='집중공격' name={'집중 공격'} imgstyle={'w-[75%] max-w-[110px]'} body='적 챔피언에게 연속으로 3회 기본 공격을 가하면 레벨에 따라 40 ~ 180의 추가 <passive>적응형 피해</passive> 를 입히고 적의 약점을 노출시킵니다. 약점이 노출된 적은 6초 동안 모든 상대에게서 8%의 추가 피해를 받습니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='치명적_속도' name={'치명적 속도'} imgstyle={'w-[75%] max-w-[110px]'} body='적 챔피언을 기본 공격하면 6초 동안 공격 속도가 [30%~96%] (근접) 또는 [21%~48%] (원거리) 상승합니다. 이 효과는 6회까지 중첩됩니다.<br><br>최대로 중첩되면 공격 속도가 2.5를 초과할 수 있으며 공격 사거리가 50 상승합니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='기민한_발놀림' name={'기민한 발놀림'} imgstyle={'w-[75%] max-w-[110px]'} body='공격 또는 이동 시 충전 중첩이 쌓입니다. 중첩이 100회에 도달하면 충전 상태로 다음 공격을 할 수 있습니다.<br><br>충전 상태로 공격 시 10~130(+추가 공격력의 0.1, +주문력의 0.05)에 해당하는 체력이 회복되며 1초 동안 이동 속도가 20% 증가합니다.<br><br>미니언으로부터 받는 회복 효과는 원거리 챔피언의 경우 10%, 근접 챔피언의 경우 20% 적용됩니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='정복자' name={'정복자'} imgstyle={'w-[75%] max-w-[110px]'} body='적 챔피언에게 기본 공격 또는 스킬로 피해를 입히면 5초 동안 정복자 중첩을 2만큼 얻어 중첩마다 1.8~4의 <passive>적응형 능력치</passive> 를 얻습니다. 최대 12회까지 중첩됩니다. 원거리 챔피언은 기본 공격으로 중첩을 1만 획득할 수 있습니다.<br><br>최대로 중첩되면 챔피언에게 입힌 피해량의 8%만큼 체력을 회복합니다. (원거리 챔피언은 5%)'/>
                    </div>
                </div>
                <div className="flex border-b-2 border-[#bba96f] h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='과다치유' name='과다치유' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='자신에 대한 체력 회복 초과분은 최대 체력의 11%에 해당하는 피해를 흡수하는 보호막으로 전환됩니다.<br><br>보호막 전환율은 자신 또는 아군으로부터 받는 체력 초과분의 20~100%입니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='승전보' name='승전보' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body="챔피언 처치 관여 시 잃은 체력의 5%+최대 체력의 2.5%를 회복하고 20골드를 추가로 획득합니다. <br><br><div style='width:100%; border-bottom-width:1px; border-color:rgb(160, 155, 140);'></div><br><oblique>'가장 위험한 게임을 하는 자만이 진정 승리의 환희를 맛보았다고 말할 수 있다.' -녹서스 검투사</oblique>"/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='침착' name='침착' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='적 챔피언에게 피해를 입히면 4초 동안 초당 마나 재생이 1.5~11 (원거리 챔피언은 78.5%) 증가합니다. 기력 기반 챔피언은 초당 1.5의 기력을 얻습니다.<br><br>처치 관여 시 최대 마나 또는 기력의 15%를 돌려받습니다.'/>
                    </div>
                </div>
                <div className="flex border-b-2 border-[#bba96f] h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='민첩함' name='전설: 민첩함' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='공격 속도가 3% 증가하며 <oblique>전설</oblique>중첩당 1.5%의 공격 속도가 추가로 증가합니다. (최대 전설 중첩 횟수: 10)<br><br>챔피언 처치 관여, 대형 몬스터 처치, 미니언 처치 시마다 <oblique>전설</oblique> 중첩을 얻습니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='강인함' name='전설: 강인함' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='강인함이 5% 증가하며 <oblique>전설</oblique>중첩당 1.5%의 강인함이 추가로 증가합니다. (최대 전설 중첩 횟수: 10)<br><br>챔피언 처치 관여, 대형 몬스터 처치, 미니언 처치 시마다 <oblique>전설</oblique> 중첩을 얻습니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='핏빛_길' name='전설: 핏빛 길' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='<oblique>전설</oblique>중첩당 생명력 흡수가 0.35% 증가합니다. (최대 전설 중첩 횟수: 15) 최대 전설 중첩 시 최대 체력이 85 증가합니다.<br><br>챔피언 처치 관여, 대형 몬스터 처치, 미니언 처치 시마다 <oblique>전설</oblique> 중첩을 얻습니다.'/>
                    </div>
                </div>
                <div className="flex h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='최후의_일격' name='최후의 일격' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='체력이 40% 이하인 적 챔피언에게 주는 피해량이 8% 증가합니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='체력차_극복' name='체력차 극복' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='적 챔피언의 최대 체력이 자신보다 많은 정도에 비례해 해당 챔피언에게 5~15%의 추가 피해를 입힙니다.<br><br>추가 피해량은 적의 최대 체력이 10~100% 더 많을 경우 그에 따라 증가합니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='최후의_저항' name='최후의 저항' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='체력이 60% 이하일 때 적 챔피언 공격 시 5~11%의 추가 피해를 줍니다. 체력이 30%일 때 최대 피해량에 도달합니다.'/>
                    </div>
                </div>
                <div className={`flex border-[#bba96f] h-[7.8333%] border-t-2 ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='<passive>적응형 능력치</passive> +9'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/적응형.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='공격 속도 +10%'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/공격_속도.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='<passive>스킬 가속</passive> +8'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/스킬_가속.jpg"/></Tooltip></div>
                </div>
                <div className={`flex h-[7.8350%] ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='<passive>적응형 능력치</passive> +9'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/적응형.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='<passive>이동 속도</passive> +2%'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/이동_속도.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='체력 +10~180 (레벨에 비례)'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/기본_체력_재생.jpg"/></Tooltip></div>
                </div>
                <div className={`flex h-[7.8333%] ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='체력 +65'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/체력.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='강인함 및 둔화 저항 +10%'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/강인함-둔화저항.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='체력 +10~180 (레벨에 비례)'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/기본_체력_재생.jpg"/></Tooltip></div>
                </div>
            </div>
        </>
}
function 지배({type}){
    return <>
            <div className={`bg-[#061118] p-[15px] border-4 border-[#d54645] h-[100%] w-[100%] z-[0] min-w-[250px] box-border min-h-[300px]`}>
                <div className="relative border-b-2 border-[#d54645] pt-[37px] pb-[15px] h-[17.5%]">
                    <img className="w-[10%] max-w-[60px] absolute top-[55%] left-1/2 -translate-x-1/2 -translate-y-1/2" src="/image/rune/지배.jpg"/>
                    <img className="w-[20%] max-w-[110px] left-1/2 absolute top-[55%] -translate-x-1/2 -translate-y-1/2" src="/image/rune/지배테두리.jpg"/>
                </div>
                <div className={`flex border-b-2 border-[#d54645] h-[22.5%] ${type == 'sub' ? '[display:none]' : undefined}`}>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='감전' name={'감전'} imgstyle={'w-[75%] max-w-[110px] min-w-[70px]'} body="3초 동안 같은 챔피언에게 <bold>개별</bold> 공격 또는 스킬을 3회 적중시키면 추가 <passive>적응형 피해</passive> 를 입힙니다.<br><br>피해량: 30~220 (+추가 공격력의 0.1, +주문력의 0.05)<br><br>재사용 대기시간: 25~20초<br><br><div style='width:100%; border-bottom-width:1px; border-color:rgb(160, 155, 140);'></div><br><oblique>'우리는 그들을 천둥군주라고 부른다. 그들의 번개를 입에 올리는 것은 재앙을 부르는 길이기 때문이다.'</oblique>"/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='포식자' name={'포식자'} imgstyle={'w-[75%] max-w-[110px]'} body="장화에 '포식자' 사용 효과를 부여합니다.<br><br>적 챔피언을 쫓을 때 이동 속도가 1초 동안 25~50%까지 서서히 증가합니다. 이후 챔피언에게 공격 또는 스킬 사용 시 이효과가 종료되며 20~180(+추가 공격력의 0.25) (+주문력의 0.15)의 추가 <passive>적응형 피해</passive> 를 입힙니다.<br><br>재사용 대기시간: 120~60초"/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='어둠의_수확' name={'어둠의 수확'} imgstyle={'w-[75%] max-w-[110px]'} body='체력이 50%보다 낮은 챔피언에게 피해를 입히면 <passive>적응형 피해</passive> 를 추가로 입히고 해당 챔피언의 영혼을 수확해 어둠의 수확 효과의 피해량이 영구적으로 5만큼 증가합니다.<br><br>어둠의 수확 피해량: 20~80 (레벨의 비례) (+영혼당 피해량 5) (+추가 공격력의 0.1) (+주문력의 0.05)<br><br>재사용 대기시간: 45초 (처치 관여 시 1.5초로 초기화)'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='칼날비' name={'칼날비'} imgstyle={'w-[75%] max-w-[110px]'} body='적 챔피언에 대한 3번째 공격까지 공격 속도가 110% 증가합니다.<br><br>3초 안에 다음 공격을 가하지 못하면 효과가 사라집니다.<br><br>재사용 대기시간: 12초<br><br>기본 공격 모션이 취소될 경우 공격 속도 증가 효과가 적용되는 공격 횟수가 1회 늘어납니다.<br>일시적으로 최고 공격 속도 제한을 초과할 수 있습니다.'/>
                    </div>
                </div>
                <div className="flex border-b-2 border-[#d54645] h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='비열한_한방' name='비열한 한 방' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='<bold>이동 또는 행동을 방해받은</bold> 상태의 챔피언에게 피해를 주면 레벨에 따라 10~45의 추가 고정 피해를 입힙니다.<br><br>재사용 대기시간: 4초<br><br>방해 효과 이후 피해를 가할 때 활성화됩니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='피의_맛' name='피의 맛' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body="적 챔피언에게 피해를 입히면 체력을 회복합니다.<br><br>회복량: 16~40 (+추가 공격력의 0.1, +주문력의 0.05) (레벨에 비례)<br><br>재사용 대기시간: 20초"/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='돌발일격' name='돌발 일격' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='돌진, 도약, 점멸, 순간이동을 사용하거나 은신에서 빠져나온 뒤 적 챔피언에게 피해를 주면 5초 동안 9의 물리 관통력과 7의 마법 관통력을 얻습니다.<br><br>재사용 대기시간: 4초'/>
                    </div>
                </div>
                <div className="flex border-b-2 border-[#d54645] h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='좀비_와드' name='좀비 와드' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='적 와드 <passive>파괴 관여</passive> 시 그 자리에 아군 좀비 와드 효과가 생성됩니다.<br><br>좀비 와드가 생성될 때마다 최대 10회까지 중첩되는 <passive>적응형</passive>으로 추가 공격력 1.2 또는 추가 주문력 2의 효과를 얻습니다.<br><br>좀비 와드를 10개 생성하면 10의 적응형 능력치를 부가적으로 획득합니다.<br><br>좀비 와드는 적이 볼 수 있고 120초 동안 유지되며, 설치 가능 와드 수에 영향을 주지 않습니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='유령_포로' name='유령 포로' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='자신이 설치한 와드의 지속 시간이 끝나면 유령 포로 와드가 남아 90초 동안 시야를 밝힙니다. 적 챔피언이 근처에 오면 유령 포로 와드를 몰아낼 수 있습니다.<br><br>유령 포로 와드가 생성되거나 유령 포로 와드가 적 챔피언을 발견할 때마다 최대 10회까지 중첩되는 <passive>적응형</passive>으로 추가 공격력 1.2 또는 추가 주문력 2의 효과를 얻습니다.<br><br>10회 중첩되면 10의 적응형 능력치를 부가적으로 획득합니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='사냥의_증표' name='사냥의 증표' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='챔피언 처치에 관여하면 증표를 얻습니다. 증표 하나당 <passive>적응형</passive>으로 추가 공격력 1.2 또는 추가 주문력 2의 효과를 얻습니다.<br><br>증표 개수가 최대치인 10개에 도달하면 <passive>적응형</passive>으로 추가 공격력 6 또는 추가 주문력 10의 효과를 부가적으로 획득합니다.<br><br>적 챔피언 처치 관여 시마다 증표 1개를 얻습니다.'/>
                    </div>
                </div>
                <div className="flex h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='보물사냥꾼' name='보물 사냥꾼' imgstyle={'w-[45%]  max-w-[80px]'} textstyle={'top-[62.5%]'} body='다음번 <oblique>현상금 사냥꾼</oblique> 중첩을 획득하면 50골드를 추가로 얻습니다. <oblique>현상금 사냥꾼</oblique> 중첩 하나당 골드 획득량이 20골드씩 증가합니다. (최대 130골드)<br><br>각 적 챔피언을 처치하는 데 처음으로 관여할 때마다 <oblique>현상금 사냥꾼</oblique> 중첩을 얻을 수 있습니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='영리한사냥꾼' name='영리한 사냥꾼' imgstyle={'w-[45%]  max-w-[80px]'} textstyle={'top-[62.5%]'} body='<bold>아이템 가속</bold>이 20 + <oblique>현상금 사냥꾼</oblique> 중첩 1회당 6 증가합니다. (장신구 포함).<br><br>각 적 챔피언을 처치하는 데 처음으로 관여할 때마다 <oblique>현상금 사냥꾼</oblique> 중첩을 얻을 수 있습니다.<br><br>아이템 가속은 재사용 대기시간이 있는 모든 아이템에 적용됩니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='끈질긴사냥꾼' name='끈질긴 사냥꾼' imgstyle={'w-[45%]  max-w-[80px]'} textstyle={'top-[62.5%]'} body='전투에서 벗어나 있을 때 이동 속도가 5 상승합니다. <oblique>현상금 사냥꾼</oblique> 중첩 하나당 8씩 추가됩니다.<br><br>각 적 챔피언을 처치하는 데 처음으로 관여할 때마다 <oblique>현상금 사냥꾼</oblique> 중첩을 얻을 수 있습니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='궁극의사냥꾼' name='궁극의 사냥꾼' imgstyle={'w-[45%]  max-w-[80px]'} textstyle={'top-[62.5%]'} body='궁극기의 스킬 가속이 6 + <oblique>현상금 사냥꾼</oblique> 중첩 1회당 5 증가합니다.<br><br>각 적 챔피언을 처치하는 데 처음으로 관여할 때마다 <oblique>현상금 사냥꾼</oblique> 중첩을 얻을 수 있습니다.'/>
                    </div>
                </div>
                <div className={`flex border-[#bba96f] h-[7.8333%] border-t-2 ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='<passive>적응형 능력치</passive> +9'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/적응형.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='공격 속도 +10%'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/공격_속도.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='<passive>스킬 가속</passive> +8'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/스킬_가속.jpg"/></Tooltip></div>
                </div>
                <div className={`flex h-[7.8350%] ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='<passive>적응형 능력치</passive> +9'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/적응형.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='<passive>이동 속도</passive> +2%'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/이동_속도.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='체력 +10~180 (레벨에 비례)'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/기본_체력_재생.jpg"/></Tooltip></div>
                </div>
                <div className={`flex h-[7.8333%] ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='체력 +65'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/체력.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='강인함 및 둔화 저항 +10%'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/강인함-둔화저항.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='체력 +10~180 (레벨에 비례)'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/기본_체력_재생.jpg"/></Tooltip></div>
                </div>
            </div>
        </>
}
function 마법({type}){
    return <>
            <div className={`bg-[#061118] p-[15px] border-4 border-[#7b84f6] h-[100%] w-[100%] z-[0] min-w-[250px] box-border min-h-[300px]`}>
                <div className="relative border-b-2 border-[#7b84f6] pt-[37px] pb-[15px] h-[17.5%]">
                    <img className="w-[10%] max-w-[50px] absolute top-[55%] left-1/2 -translate-x-1/2 -translate-y-1/2" src="/image/rune/마법.jpg"/>
                    <img className="w-[20%] max-w-[110px] left-1/2 absolute top-[55%] -translate-x-1/2 -translate-y-1/2" src="/image/rune/마법테두리.jpg"/>
                </div>
                <div className={`flex border-b-2 border-[#7b84f6] h-[22.5%] ${type == 'sub' ? '[display:none]' : undefined}`}>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='콩콩이' name={'콩콩이 소환'} imgstyle={'w-[50%] max-w-[110px]'} body="적 챔피언을 기본 공격 또는 스킬로 공격하면 콩콩이를 보내 레벨에 따라 10~50 (+주문력의 0.05) (+추가 공격력의 0.1)만큼 피해를 입힙니다.<br><br>아군에게 스킬로 강화 효과 또는 보호막을 적용하면 콩콩이를 보내 레벨에 따라 30~100 (+주문력의 0.05) (+추가 공격력의 0.1)만큼 피해를 흡수하는 보호막을 씌웁니다.<br><br>콩콩이는 자신에게 돌아오기 전까지 다른 대상에게 보낼 수 없습니다."/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='유성' name={'유성'} imgstyle={'w-[50%] max-w-[110px]'} body="챔피언에게 스킬로 피해를 주면 해당 위치에 유성을 불러옵니다. 신비로운 유성이 재사용 대기 중일 경우 남은 재사용 대기시간이 감소합니다.<br><br><passive>적응형 피해</passive> : 레벨에 따라 30~130 (+주문력의 0.05 및 +추가 공격력의 0.1)<br><br>재사용 대기시간: 20~8초<br><br>재사용 대기시간 감소:<br>단일 대상 스킬: 20%<br>광역 스킬: 10%<br>지속 피해 스킬: 5%"/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='난입' name={'난입'} imgstyle={'w-[50%] max-w-[110px]'} body='4초 안에 한 챔피언에게 기본 공격 또는 <bold>개별 스킬</bold> 3회를 적중시키면 레벨에 따라 15~40%의 이동 속도와 75%의 둔화 저항 효과를 얻습니다.<div style="width:100%; border-bottom-width:1px; border-color:rgb(160, 155, 140);"></div>근접 챔피언의 경우 이동 속도가 25~50%까지 증가합니다.<br>div style="width:100%; border-bottom-width:1px; border-color:rgb(160, 155, 140);"></div>지속시간: 3초<br>재사용 대기시간: 30~10초'/>
                    </div>
                </div>
                <div className="flex border-b-2 border-[#7b84f6] h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='무효화_구체' name='무효화 구체' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='마법 피해를 받아 체력이 30% 이하가 될 경우, 4초 동안 레벨에 비례해 35 ~ 110 (+추가 공격력의 0.14) (+주문력의 0.09) 마법 피해를 흡수하는 보호막이 생성됩니다.<br><br>재사용 대기시간: 60초'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='마법_순환_팔지' name='마법_순환_팔지' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body="적 챔피언에게 스킬을 적중하면 최대 마나가 영구적으로 25만큼 증가합니다. (최대 마나량: 250)<br><br>최대 마나량 250에 도달하면 5초마다 잃은 마나의 1%를 회복합니다.<br><br>재사용 대기시간: 15초"/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='빛의_망토' name='빛의 망토' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='소환사 주문 사용 후 2초 동안 이동 속도가 증가하고 유닛을 통과할 수 있습니다.<br><br>증가: 소환사 주문 재사용 대기시간에 따라 이동 속도가 5% ~ 25% 증가합니다. (재사용 대기시간이 길수록 이동 속도가 더 많이 증가합니다.)'/>
                    </div>
                </div>
                <div className="flex border-b-2 border-[#7b84f6] h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='깨달음' name='깨달음' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='다음 레벨이 되면 추가 효과 획득:<br>5레벨: 스킬 가속 +5<br>8레벨: 스킬 가속 +5<br>11레벨: 챔피언 처치 관여 시 기본 스킬의 남은 재사용 대기시간 20% 감소.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='기민함' name='기민함' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='모든 추가 이동 속도 효과가 7% 증가하고 이동 속도를 1% 추가로 얻습니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='절대집중' name='절대 집중' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='체력이 70% 이상일 경우에는 레벨에 따라 <passive>적응형</passive> 으로 추가 공격력 최대 18 또는 추가 주문력 최대 30의 효과를 얻습니다.<br><br>1레벨에 1.8의 공격력 또는 3의 주문력을 얻습니다.'/>
                    </div>
                </div>
                <div className="flex h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='주문_작열' name='주문 작열' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='다음 공격 스킬 적중 시 챔피언에게 불을 붙여 1초 후 레벨에 따라 20~40의 추가 마법 피해를 줍니다.<br><br>재사용 대기시간: 10초'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='물_위를_걷는자' name='물 위를 걷는자' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='강에 있을 때 이동 속도가 10 증가하고 레벨에 비례하여 <passive>적응형</passive>으로 추가 공격력 최대 18 또는 추가 주문력 최대 30의 효과를 얻습니다.<br><br><div style="width:100%; border-bottom-width:1px; border-color:rgb(160, 155, 140);"></div><br><oblique>굽이치는 강물처럼 빠르고 깜짝 놀란 협곡 바위 게처럼 날렵하게 움직이리라.</oblique>'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='폭풍의_결집' name='폭풍의_결집' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='10분마다 <passive>적응형</passive>으로 주문력 또는 공격력을 얻습니다.<br><br>10분: + 주문력 8 또는 공격력 5<br>20분: + 주문력 24 또는 공격력 14<br>30분: + 주문력 48 또는 공격력 29<br>40분: + 주문력 80 또는 공격력 48<br>50분: + 주문력 120 또는 공격력 72<br>60분: + 주문력 168 또는 공격력 101<br>등등…'/>
                    </div>
                </div>
                <div className={`flex border-[#bba96f] h-[7.8333%] border-t-2 ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='<passive>적응형 능력치</passive> +9'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/적응형.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='공격 속도 +10%'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/공격_속도.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='<passive>스킬 가속</passive> +8'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/스킬_가속.jpg"/></Tooltip></div>
                </div>
                <div className={`flex h-[7.8350%] ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='<passive>적응형 능력치</passive> +9'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/적응형.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='<passive>이동 속도</passive> +2%'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/이동_속도.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='체력 +10~180 (레벨에 비례)'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/기본_체력_재생.jpg"/></Tooltip></div>
                </div>
                <div className={`flex h-[7.8333%] ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='체력 +65'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/체력.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='강인함 및 둔화 저항 +10%'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/강인함-둔화저항.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='체력 +10~180 (레벨에 비례)'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/기본_체력_재생.jpg"/></Tooltip></div>
                </div>
            </div>
        </>
}
function 결의({type}){
    return <>
            <div className={`bg-[#061118] p-[15px] border-4 border-[#a6d18c] h-[100%] w-[100%] z-[0] min-w-[250px] box-border min-h-[300px]`}>
                <div className="relative border-b-2 border-[#a6d18c] pt-[37px] pb-[15px] h-[17.5%]">
                    <img className="w-[10%] max-w-[50px] absolute top-[55%] left-1/2 -translate-x-1/2 -translate-y-1/2" src="/image/rune/결의.jpg"/>
                    <img className="w-[20%] max-w-[110px] left-1/2 absolute top-[55%] -translate-x-1/2 -translate-y-1/2" src="/image/rune/결의테두리.jpg"/>
                </div>
                <div className={`flex border-b-2 border-[#a6d18c] h-[22.5%] ${type == 'sub' ? '[display:none]' : undefined}`}>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='착취' name={'착취'} imgstyle={'w-[50%] max-w-[110px]'} body="전투 중 4초마다 챔피언에 대한 기본 공격 시 다음 효과를 얻습니다.<ul><li>자신 최대 체력의 3.5%에 해당하는 추가 마법 피해</li><li>자신 최대 체력의 1.2%+3에 해당하는 체력을 회복</li><li>영구적으로 체력 7 증가</li></ul><br><oblique>원거리 챔피언</oblique>: 피해량, 회복량, 체력 영구 증가량이 40% 감소합니다."/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='여진' name={'여진'} imgstyle={'w-[50%] max-w-[110px]'} body="적을 이동 불가 상태로 만들면 2.5초 동안 35+추가 방어력 및 마법 저항력의 78.5%만큼 방어력과 마법 저항력이 증가하며 폭발이 일어나 근처 적에게 마법 피해를 줍니다.<br><br>피해량: 25~120 (+추가 체력의 8%)<br>재사용 대기시간: 20초<br><br>여진 추가 저항력: 80~150 (레벨에 비례)"/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='수호자' name={'수호자'} imgstyle={'w-[50%] max-w-[110px]'} body='자신으로부터 350유닛 내에 있는 아군이나 자신이 스킬의 대상으로 삼은 아군을 3초 동안 <oblique>보호</oblique>합니다. <oblique>보호</oblique>하는 중 자신과 아군 중 한 명이 <oblique>보호</oblique>의 지속시간 동안 일정량의 피해를 입으면 둘 모두에게 2초 동안 보호막이 생성됩니다.<br><br>재사용 대기시간: 90~40초<br>보호막 흡수량: 45~120+주문력의 12.5%+추가 체력의 8%<br>최종 기준치: 감소 후 피해량 90~250'/>
                    </div>
                </div>
                <div className="flex border-b-2 border-[#a6d18c] h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='철거' name='철거' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='포탑으로부터 600 범위 안에 있을 경우 3초에 걸쳐 포탑에 대한 강력한 공격을 충전합니다. 충전된 공격은 100 (+최대 체력의 35%)에 해당하는 추가 물리 피해를 입힙니다.<br><br>재사용 대기시간: 45초'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='생명의_샘' name='생명의 샘' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body="적 챔피언의 이동을 방해하면 4초 동안 표식을 남깁니다.<br><br>표식이 남겨진 적을 공격하는 아군 챔피언은 2초에 걸쳐 5 + 나의 최대 체력의 0.9%에 해당하는 체력을 회복합니다."/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='보호막_강타' name='보호막 강타' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='보호막이 지속되는 동안 레벨에 따라 1~10의 방어력과 마법 저항력을 얻습니다.<br><br>새로운 보호막을 얻으면 적 챔피언에게 다음 기본 공격 시 5~30 (+추가 체력의 1.5%) (+새로운 보호막 흡수량의 8.5%)에 해당하는 추가 <passive>적응형</passive> 피해를 입힙니다.<br><br>이 효과는 보호막이 사라진 후 최대 2초까지 발동 가능합니다.'/>
                    </div>
                </div>
                <div className="flex border-b-2 border-[#a6d18c] h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='사전_준비' name='사전 준비' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='12분 후 방어력 +8 및 마법 저항력 +8 증가와 동시에 방어력 및 마법 저항력 3% 증가'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='재생의_바람' name='재생의 바람' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='적 챔피언에게 피해를 입으면 10초 동안 잃은 체력의 4% + 3만큼 회복합니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='뼈방패' name='뼈 방패' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='적 챔피언으로부터 피해를 입은 뒤 적이 가하는 3회의 스킬 및 기본 공격으로부터 30~60만큼 피해를 덜 받습니다.<br><br>지속시간: 1.5초<br>재사용 대기시간: 55초'/>
                    </div>
                </div>
                <div className="flex h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='과잉_성장' name='과잉 성장' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='적 챔피언으로부터 피해를 입은 뒤 적이 가하는 3회의 스킬 및 기본 공격으로부터 피해를 덜 받습니다.<br><br>몬스터 또는 적 미니언을 120마리 흡수하면 최대 체력이 추가로 3.5% 증가합니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='소생' name='소생' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='보호막 및 체력 회복 효과가 5% 증가합니다.<br><br>체력이 40% 이하인 대상에게는 자신이 사용하거나 받는 회복과 보호막 효과가 10% 강화됩니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='불굴의_의지' name='불굴의 의지' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='군중 제어 스킬에 영향을 받을 때와 그 이후 2초 동안 방어력과 마법 저항력이 2 ~ 10 (레벨에 비례) 증가합니다.'/>
                    </div>
                </div>
                <div className={`flex border-[#bba96f] h-[7.8333%] border-t-2 ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='<passive>적응형 능력치</passive> +9'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/적응형.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='공격 속도 +10%'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/공격_속도.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='<passive>스킬 가속</passive> +8'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/스킬_가속.jpg"/></Tooltip></div>
                </div>
                <div className={`flex h-[7.8350%] ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='<passive>적응형 능력치</passive> +9'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/적응형.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='<passive>이동 속도</passive> +2%'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/이동_속도.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='체력 +10~180 (레벨에 비례)'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/기본_체력_재생.jpg"/></Tooltip></div>
                </div>
                <div className={`flex h-[7.8333%] ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='체력 +65'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/체력.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='강인함 및 둔화 저항 +10%'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/강인함-둔화저항.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='체력 +10~180 (레벨에 비례)'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/기본_체력_재생.jpg"/></Tooltip></div>
                </div>
            </div>
        </>
}
function 영감({type}){
    return <>
            <div className={`bg-[#061118] p-[15px] border-4 border-[#4cb1c2] h-[100%] w-[100%] z-[0] min-w-[250px] box-border min-h-[300px]`}>
                <div className="relative border-b-2 border-[#4cb1c2] pt-[37px] pb-[15px] h-[17.5%]">
                    <img className="w-[10%] max-w-[50px] absolute top-[55%] left-1/2 -translate-x-1/2 -translate-y-1/2" src="/image/rune/영감.jpg"/>
                    <img className="w-[20%] max-w-[110px] left-1/2 absolute top-[55%] -translate-x-1/2 -translate-y-1/2" src="/image/rune/영감테두리.jpg"/>
                </div>
                <div className={`flex border-b-2 border-[#4cb1c2] h-[22.5%] ${type == 'sub' ? '[display:none]' : undefined}`}>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='빙결' name={'빙결 강화'} imgstyle={'w-[50%] max-w-[110px]'} body="적 챔피언을 이동 불가 상태로 만들면 대상에게서 3줄기의 빙결 광선이 자신과 근처 다른 챔피언을 향해 뻗어 나와 3초(+이동 불가 효과 지속 시간의 100%) 동안 적들을 20%(+회복 및 보호막 효과 10%당 9%)(+주문력 100당 6%)(+추가 공격력 100당 7%) 둔화하고 자신을 제외한 아군에게 입히는 피해를 15% 감소시키는 빙결 영역을 생성합니다.<br><br>재사용 대기시간: 25초"/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='봉인_풀린_주문서' name={'봉인 풀린 주문서'} imgstyle={'w-[50%] max-w-[110px]'} body="장착된 소환사 주문을 한 번만 사용 가능한 새로운 소환사 주문으로 교환합니다. 이전에 쓰지 않은 새로운 소환사 주문으로 교환할 때마다 교환의 재사용 대기시간이 영구적으로 25초씩 감소합니다. (최초 교환의 재사용 대기시간: 5분)<br><br>첫 번째 교환은 6분부터 가능합니다.<br><br>소환사 주문은 전투에서 벗어났을 때에만 교환할 수 있습니다.<br>교환한 소환사 주문을 사용한 후 3번 더 교환해야 다시 첫 번째 소환사 주문을 선택할 수 있습니다.<br>소환사 주문을 2회 교환한 후부터 강타 피해량이 증가합니다."/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='선제공격' name={'선제 공격'} imgstyle={'w-[50%] max-w-[110px]'} body='전투 시작 후 0.25초 이내에 적 챔피언에게 기본 공격이나 스킬로 피해를 입히면 5골드를 획득하고 3초 동안 <bold>선제공격<bold> 효과를 얻어 자신의 기본 공격이나 스킬이 모든 챔피언에게 7%의 추가 피해를 입히며 입힌 추가 피해량의 100%(원거리 챔피언 70%)에 해당하는 골드를 획득합니다.<br><br>재사용 대기시간: 25~15초'/>
                    </div>
                </div>
                <div className="flex border-b-2 border-[#4cb1c2] h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='마법공학_점멸기' name='마법공학 점멸기' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='점멸이 재사용 대기 중일 때 <oblique>마법공학 점멸</oblique>로 대체됩니다.<br><br><oblique>마법공학 점멸</oblique>: 2초간 정신을 집중한 뒤 다른 지점으로 도약합니다.<br><br>재사용 대기시간: 20초. 챔피언과 전투에 돌입할 경우 10초의 재사용 대기시간이 시작됩니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='마법의_신발' name='마법의 신발' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body="게임 시작 후 12분에 약간 신비한 신발 아이템을 얻습니다. 그 전까지는 신발류 아이템을 구매할 수 없습니다. 챔피언 처치에 관여할 때마다 장화 획득 시점이 45초씩 앞당겨집니다.<br><br>약간 신비한 신발 아이템으로 이동 속도가 10 증가합니다."/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='삼중_물약' name='삼중 물약' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='3레벨에 도달하면 탐욕의 영약을 획득합니다.<br>6레벨에 도달하면 힘의 영약을 획득합니다.<br>9레벨에 도달하면 숙련의 영약을 획득합니다.'/>
                    </div>
                </div>
                <div className="flex border-b-2 border-[#4cb1c2] h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='외상' name='외상' imgstyle={'w-[35%] max-w-[80px]'} textstyle={'top-[78.5%]'} body='외상으로 아이템을 구입할 수 있습니다. 외상 한도는 점차 증가합니다. 외상 시 수수료는 50골드입니다.<br>외상 한도: 100 + 분당 8<br>(외상은 2분부터 사용 가능합니다.)'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='미니언_해체분석기' name='미니언 해체분석기' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='게임 시작 시, 공격로 미니언을 즉시 처치하고 흡수하는 미니언 해체분석기 3개를 받습니다. 미니언 해체분석기 아이템은 게임 시작 후 180초 동안 재사용 대기 상태입니다.<br><br>이 아이템으로 미니언을 흡수하면 이후 동일한 종류의 미니언을 대상으로 6%의 추가 피해를 입히며, 동일한 종류의 미니언을 추가 흡수 시마다 3%의 추가 피해를 입힙니다.'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='비스킷_배달' name='비스킷 배달' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='비스킷 배달: 6분까지 2분마다 굳건한 의지의 완전한 비스킷 아이템을 얻습니다.<br><br>비스킷을 사용하면 잃은 체력과 마나의 8%를 회복합니다. 비스킷 하나를 사용하거나 판매하면 최대 마나가 영구적으로 40만큼 늘어납니다.<br><br><oblique>마나 없음</oblique>: 마나가 없는 챔피언은 마나 대신 잃은 체력의 10%를 회복합니다.'/>
                    </div>
                </div>
                <div className="flex h-[20%]">
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='우주적_통찰력' name='우주적 통찰력' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='소환사 주문 가속 +18<br>아이템 가속 +10'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='쾌속_접근' name='쾌속 접근' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='이동 방해 스킬에 맞은 근처의 적 챔피언에게 이동할 때 이동 속도가 7.5% 증가합니다. 적 챔피언에게 이동 방해 스킬을 맞히고 해당 적에게 이동할 때는 이동 속도가 15%까지 증가합니다.<br><br>아군 군중 제어 사용 범위: 1000'/>
                    </div>
                    <div className="w-[100%] text-center">
                        <PopoverFunc img='시간_왜곡_물약' name='시간 왜곡 물약' imgstyle={'w-[35%]  max-w-[80px]'} textstyle={'top-[78.5%]'} body='물약이나 비스킷을 사용하면 체력이나 마나 회복량의 30%를 즉시 회복합니다. 또한 물약이나 비스킷의 효과가 지속되는 동안 이동 속도가 2% 증가합니다.'/>
                    </div>
                </div>
                <div className={`flex border-[#bba96f] h-[7.8333%] border-t-2 ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='<passive>적응형 능력치</passive> +9'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/적응형.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='공격 속도 +10%'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/공격_속도.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='<passive>스킬 가속</passive> +8'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/스킬_가속.jpg"/></Tooltip></div>
                </div>
                <div className={`flex h-[7.8350%] ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='<passive>적응형 능력치</passive> +9'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/적응형.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='<passive>이동 속도</passive> +2%'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/이동_속도.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='체력 +10~180 (레벨에 비례)'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/기본_체력_재생.jpg"/></Tooltip></div>
                </div>
                <div className={`flex h-[7.8333%] ${type == 'sub' ? undefined : '[display:none]'}`}>
                    <div className="w-[100%]"><Tooltip label='체력 +65'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/체력.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='강인함 및 둔화 저항 +10%'><Img m={'auto'} w={'35%'} maxW={'65px'} src="/image/icon/강인함-둔화저항.jpg"/></Tooltip></div>
                    <div className="w-[100%]"><Tooltip label='체력 +10~180 (레벨에 비례)'><Img m={'auto'} p={'10px'} w={'35%'} maxW={'65px'} src="/image/icon/기본_체력_재생.jpg"/></Tooltip></div>
                </div>
            </div>
        </>
}

export default ({value,value2})=>{
       return <div className="flex w-full h-full -translate-y-[40px]">
                    {value == '1' ? <div className="w-[50%] h-full"><정밀/></div>
                    : value == '2' ? <div className="w-[50%] h-full"><지배/></div>
                    : value == '3' ? <div className="w-[50%] h-full"><마법/></div>
                    : value == '4' ? <div className="w-[50%] h-full"><결의/></div>
                    : value == '5' ? <div className="w-[50%] h-full"><영감/></div>
                    :undefined}
                    {value != value2 
                    ? value2 == '1' ? <div className="w-[50%] h-full"><정밀 type='sub'/></div>
                    : value2 == '2' ? <div className="w-[50%] h-full"><지배 type='sub'/></div>
                    : value2 == '3' ? <div className="w-[50%] h-full"><마법 type='sub'/></div>
                    : value2 == '4' ? <div className="w-[50%] h-full"><결의 type='sub'/></div>
                    : value2 == '5' ? <div className="w-[50%] h-full"><영감 type='sub'/></div> : undefined: undefined}
                </div>
}