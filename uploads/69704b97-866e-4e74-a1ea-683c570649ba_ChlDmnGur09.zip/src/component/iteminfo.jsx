import React, { useState, useEffect} from "react";
import axios from 'axios';
import {Text, Image, Button,Popover, PopoverTrigger, PopoverContent, PopoverHeader, PopoverBody, PopoverFooter, PopoverArrow,} from '@chakra-ui/react'
import { RepeatIcon} from '@chakra-ui/icons'
import { Swiper, SwiperSlide } from 'swiper/react';
import {Navigation} from 'swiper/modules'
import 'swiper/css';
import 'swiper/css/navigation';

export default ({checkedItems})=>{
    const [all, all_f] = useState([]);
    const [onoff,setonoff] = useState(true)

    let result = [];
    useEffect(() => {
		const FetchData = async() => {
            const data = await axios.get('https://ddragon.leagueoflegends.com/cdn/14.6.1/data/ko_KR/item.json').then(res=>res.data)
            return data.data
        }	
        FetchData().then(res=>{
            for(let i = 1000; i < 8500; i++) {
                if(res[`${i}`]) {
                    result = [...result, res[`${i}`]]
                }
            }
            return result
        }).then(res=>all_f(res))
    }, []);
    
    {all.map(v=>{
        v.name == '장화' ? v.description = '<maintext><stats>이동 속도 <icon>이동 속도</icon> <value>25</value></stats></maintext>' :
        v.name == '광전사의 군화' ? v.description = '<maintext><stats>공격 속도 <icon>공격 속도</icon> <value>35%</value><br>이동 속도 <icon>이동 속도</icon> <value>45</value></stats></maintext>' :
        v.name == '신속의 장화' ? v.description = '<maintext><stats>이동 속도 <icon>이동 속도</icon> <value>60</value></stats>'
        +'<br><br>이동 속도 둔화 효과가 25% 줄어듭니다.</maintext>' :
        v.name == '마법사의 신발' ? v.description = '<maintext><stats>마법 관통력 <icon>마법 관통력</icon> <value>18</value><br>이동 속도 <icon>이동 속도</icon> <value>45</value></stats></maintext>' :
        v.name == '판금 장화' ? v.description = '<maintext><stats>방어력 <icon>방어력</icon> <value>20</value><br>이동 속도 <icon>이동 속도</icon> <value>45</value></stats>'
        +'<br><br>기본 공격으로 받는 피해량이 12% 감소합니다.</maintext>' :
        v.name == '헤르메스의 발걸음' ? v.description = '<maintext><stats>마법 저항력 <icon>마법 저항력</icon> <value>25</value><br>이동 속도 <icon>이동 속도</icon> <value>45</value><br>강인함 <icon>강인함</icon> <value>30%</value></stats>'
        +'<br><br><rules>강인함이 증가해 <status>기절</status>, <status>둔화</status>, <status>도발</status>, <status>공포</status>, <status>침묵</status>, <status>실명</status>, <status>변이</status> 및 <status>이동 불가</status> 효과의 지속시간이 감소합니다. <status>공중에 뜨거나 제압</status> 당했을 때는 효과가 없습니다.</rules></maintext>' :
        v.name == '기동력의 장화' ? v.description = '<maintext><stats>이동 속도 <icon>이동 속도</icon> <value>25</value></stats>'
        +'<br><br>5초 동안 전투에서 벗어나 있으면 이동 속도가 <icon>이동 속도</icon>115 상승합니다.</maintext>' :
        v.name == '명석함의 아이오니아 장화' ? v.description = '<maintext><stats>스킬 가속 <icon>스킬 가속</icon> <value>15</value><br>이동 속도 <icon>이동 속도</icon> <value>45</value></stats>'
        +'<br><br>소환사 주문 가속이 12 증가합니다.'
        +'<br><br><etc>"CLE 20년 12월 10일 남부 지방의 패권을 두고 벌어진 녹서스와의 재경합에서 아이오니아의 승리를 기념하는 헌정 아이템입니다."</etc></maintext>' :
    
        v.name == '암흑의 인장' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>15</value><br>체력 <icon>체력</icon> <value>50</value></stats>'
        +'<br><br><passive>영광</passive><br>적을 처치하거나 어시스트를 올릴 때 중첩을 획득합니다. 중첩당 <jml>4의 주문력</jml>을 얻습니다. 적 챔피언을 처치할 때마다 중첩 2회, 어시스트를 올릴 때마다 중첩 1회가 쌓입니다. 최대 10회까지 쌓을 수 있으며 사망 시 중첩 5회가 사라집니다.'
        +'<br><br><rules>중첩은 이 아이템과 <passive>메자이의 영혼약탈자</passive>에 모두 적용됩니다.</rules></maintext>' :
        v.name == '여신의 눈물' ? v.description = '<maintext><stats>마나 <icon>마나</icon> <value>240</value></stats>'
        +'<br><br><passive>마나순환</passive><br><ul><li>지속적으로 마나 충전 중첩을 얻습니다. 대상에게 스킬을 적중시키면 중첩을 하나 소모해 <mana>3의 추가 마나</mana>를 얻습니다. 추가 마나 최대치는 <mana>360</mana>입니다.</li><li>미니언에게 기본 공격 시 <ad>5의 물리 피해</ad>를 추가로 입힙니다.</li></ul>'
        +'<br><br><rules>8초마다 새로운 <passive>마나 충전</passive> 중첩을 얻습니다. (최대 4)</rules></maintext>' :
        v.name == '도란의 반지' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>18</value><br>체력 <icon>체력</icon> <value>90</value></stats>'
        +'<br><br><passive>회복</passive><br><ul><li>매초 <mana>1.25의 마나</mana>를 회복합니다. 마나를 회복할 수 없으면 회복량의 45%만큼 체력을 회복합니다.</li><li>미니언에게 기본 공격 시 <ad>5의 물리 피해</ad>를 추가로 입힙니다.</li></ul></maintext>' :
        v.name == '세계 지도집' ? v.description = '<maintext><stats>10초당 골드 <icon>골드</icon> <value>3</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>50%</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <vlaue>50%</vlaue><br>체력 <icon>체력</icon> <value>30</value></stats>'
        +'<br><br><passive>퀘스트</passive><br>이 아이템으로 <num>400</num>골드를 획득하면 <passive>룬 나침반</passive>으로 변합니다. <passive>20</passive>초마다 중첩을 하나씩 얻고 최대 <passive>3</passive>회 까지 중첩됩니다. 주변에 아군 챔피언이 있을 때 중첩을 하나 소모하고 골드를 획득합니다.'
        +'<br><ul><li>스킬 및 기본 공격 으로 챔피언 및 건물에 피해를 입히면 (<icon>근거리</icon><num>22</num> | <icon>원거리</icon><num>20</num>)의 골드를 획득합니다.</li><li>어떤 방법으로든 미니언 처치 시 <num>15</num>골드를 획득하며 가장 가까운 아군 챔피언에게도 처치 골드가 주어집니다.</li></ul>'
        +'<br><br><rules>이 아이템을 보유한 아군이 너무 많은 미니언을 처치하면 미니언 처치 시 획득하는 골드가 감소합니다.</rules>'
        +"<br><br><etc>'찾는 곳에 길이 있나니.</etc></maintext>" :
        v.name == '도란의 검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>10</value><br>체력 <icon>체력</icon> <value>100</value><br>생명력 흡수 <icon>생명력 흡수</icon> <value>3.5%</value></icon></stats></maintext>' :
        v.name == '수확의 낫' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>7</value></stats>'
        +'<br><br><passive>수확</passive><br><ul><li>공격 적중 시 <hb>체력을 3</hb> 회복합니다.</li><li>공격로 미니언 처치 시 추가로 <num>1</num>골드를 얻습니다. (최대 <num>100</num>골드) 한도에 도달하면 <num>350</num>의 추가 골드를 얻습니다.</li></ul></maintext>' :
        v.name == '도란의 방패' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>110</value></stats>'
        +'<br><br><passive>인내의 집중력</passive><br><ul><li>5초마다 <hb>체력을 4</hb> 회복합니다. 챔피언, 대형 또는 에픽 정글 몬스터에게 피해를 입으면 8초 동안 최대 <hb>45의 추가 체력</hb>을 회복합니다. 회복량은 체력이 낮을수록 증가합니다.</li><li>미니언에게 기본 공격 시 <ad>5의 물리 피해</ad>를 추가로 입힙니다.</li></ul>'
        +'<br><br><rules><icon>원거리</icon> 원거리 챔피언이 보유하거나 광역 또는 지속 피해를 입었을 때 기본 회복량의 66%만큼 회복합니다.</rules></maintext>' :
        v.name == '새끼 화염발톱' ? v.description = '<maintext>정글에서 챔피언을 도와주는 <div style="color:#c32b2c; width:auto; display:inline-block">화염발톱</div>을 소환해 <true>(<passive>20 ~ 90<icon>레벨</icon></passive> <ggl>+ 추가 <icon>공격력</icon>10%</ggl> <jml>+ <icon>주문력</icon>12%</jml> <chl>+ 추가 <icon>체력</icon>3%</chl> <bul>+ 추가 <icon>방어력</icon>20%</bul> <ap>+ 추가 <icon>마법 저항력</icon>20%</ap>)의 고정 피해</true>를 입힙니다. 에픽 몬스터 상대 시 최대 <true>(<ggl><icon>공격력</icon>10%</ggl> <jml>+ <icon>주문력</icon>10%</jml> <chl>+ <icon>체력</icon>3%</chl> <bul>+ <icon>방어력</icon>20%</bul> <ap>+ <icon>마법 저항력</icon>20%</ap>)의 고정 피해</true>를 입히고 몬스터 상대 시 초당 <hb>챔피언의 체력을 (<passive>14 ~ 37<icon>레벨</icon>)</passive>씩 회복</hb>시킵니다.'
        +'완전히 성장 시 시간이 지남에 따라 또는 몬스털르 처치하면 <div style="color:#9d1938; width:auto; display:inline-block">잉걸불</div> 중첩을 획득합니다. (최대 100중첩) <div style="color:#9d1938; width:auto; display:inline-block">100 잉걸불</div> 중첩 상태에서 챔피언에게 공격 또는 스킬로 피해를 입히면 2초에 걸쳐 점차 감소하는 30%의 <status>둔화 효과</status>를 적용하고 4초 동안 불태워 <true>최대 체력의 4%에 해당하는 고정 피해</true>를 입힙니다.'
        +'<br><br><ul><li><passive>맛있는 간식:</passive> 동료가 챔피언을 도와주면서 몬스터에게 피해를 입힙니다. <num>40번</num>까지 동료에게 간식을 먹일 수 있습니다. 대형 몬스터를 처치할 때마다 간식을 한 번 먹이며, 보너스 간식이 있으면 두 번 먹입니다. 동료는 간식을 먹은 횟수에 따라 챔피언과 <passive>강타</passive>를 강화하고 새로운 효과를 부여합니다. 보너스 간식은 주기적으로 주어지며, 동료에게 먹이면 추가 골드를 받습니다.</li>'
        +'<br><li><passive>간식 20개:</passive> 동료의 힘으로 <passive>강타</passive>가 업그레이드되어 <true>900의 피해</true>를 입힙니다. 적 챔피언에게 강타를 사용하면 피해량이 감소하고 대상을 <status>둔화</status>시킵니다.</li>'
        +'<br><li><passive>간식 40개: 동료가 성체가 되어 고유한 추가 효과를 부여합니다. 강타</passive>가 한 번 더 업그레이드되어, 주변 몬스터에게 <passive>1200</passive>의 피해를 입힙니다.</li></ul>'
        +'<br>몬스터를 처치하면 100 잉거불 중처을 얻습니다.'
        +'<br><br>대형 및 에픽 몬스터는 간식 1개를 줍니다<br><br>대형 몬스터를 처치할 때마다 80의 추가 경험치를 얻습니다. 대형 몬스터를 처음으로 처치하면 150의 추가 경험치를 얻습니다.</maintext>' :
        v.name == '새끼 바람돌이' ? v.description = '<maintext>정글에서 챔피언을 도와주는 <div style="color:#38a8e8; width:auto; display:inline-block">바람돌이</div>을 소환해 <true>(<passive>20 ~ 90<icon>레벨</icon></passive> <ggl>+ 추가 <icon>공격력</icon>10%</ggl> <jml>+ <icon>주문력</icon>12%</jml> <chl>+ 추가 <icon>체력</icon>3%</chl> <bul>+ 추가 <icon>방어력</icon>20%</bul> <ap>+ 추가 <icon>마법 저항력</icon>20%</ap>)의 고정 피해</true>를 입힙니다. 에픽 몬스터 상대 시 최대 <true>(<ggl><icon>공격력</icon>10%</ggl> <jml>+ <icon>주문력</icon>10%</jml> <chl>+ <icon>체력</icon>3%</chl> <bul>+ <icon>방어력</icon>20%</bul> <ap>+ <icon>마법 저항력</icon>20%</ap>)의 고정 피해</true>를 입히고 몬스터 상대 시 초당 <hb>챔피언의 체력을 (<passive>14 ~ 37<icon>레벨</icon>)</passive>씩 회복</hb>시킵니다.'
        +'완전히 성장 시 수풀에 들어가면 <speed>이동 속도가 30% 증가</speed>하고 2초에 걸쳐 원래대로 돌아오며 대형 몬스터를 처치하면 <speed>45%</speed>증가합니다.'
        +'<br><br><ul><li><passive>맛있는 간식:</passive> 동료가 챔피언을 도와주면서 몬스터에게 피해를 입힙니다. <num>40번</num>까지 동료에게 간식을 먹일 수 있습니다. 대형 몬스터를 처치할 때마다 간식을 한 번 먹이며, 보너스 간식이 있으면 두 번 먹입니다. 동료는 간식을 먹은 횟수에 따라 챔피언과 <passive>강타</passive>를 강화하고 새로운 효과를 부여합니다. 보너스 간식은 주기적으로 주어지며, 동료에게 먹이면 추가 골드를 받습니다.</li>'
        +'<br><li><passive>간식 20개:</passive> 동료의 힘으로 <passive>강타</passive>가 업그레이드되어 <true>900의 피해</true>를 입힙니다. 적 챔피언에게 강타를 사용하면 피해량이 감소하고 대상을 <status>둔화</status>시킵니다.</li>'
        +'<br><li><passive>간식 40개: 동료가 성체가 되어 고유한 추가 효과를 부여합니다. 강타</passive>가 한 번 더 업그레이드되어, 주변 몬스터에게 <passive>1200</passive>의 피해를 입힙니다.</li></ul>'
        +'<br>대형 및 에픽 몬스터는 간식 1개를 줍니다<br><br>대형 몬스터를 처치할 때마다 80의 추가 경험치를 얻습니다. 대형 몬스터를 처음으로 처치하면 150의 추가 경험치를 얻습니다.</maintext>' :
        v.name == '새끼 이끼쿵쿵이' ? v.description = '<maintext>정글에서 챔피언을 도와주는 <div style="color:#1ca735; width:auto; display:inline-block">이끼쿵쿵이</div>을 소환해 <true>(<passive>20 ~ 90<icon>레벨</icon></passive> <ggl>+ 추가 <icon>공격력</icon>10%</ggl> <jml>+ <icon>주문력</icon>12%</jml> <chl>+ 추가 <icon>체력</icon>3%</chl> <bul>+ 추가 <icon>방어력</icon>20%</bul> <ap>+ 추가 <icon>마법 저항력</icon>20%</ap>)의 고정 피해</true>를 입힙니다. 에픽 몬스터 상대 시 최대 <true>(<ggl><icon>공격력</icon>10%</ggl> <jml>+ <icon>주문력</icon>10%</jml> <chl>+ <icon>체력</icon>3%</chl> <bul>+ <icon>방어력</icon>20%</bul> <ap>+ <icon>마법 저항력</icon>20%</ap>)의 고정 피해</true>를 입히고 몬스터 상대 시 초당 <hb>챔피언의 체력을 (<passive>14 ~ 37<icon>레벨</icon>)</passive>씩 회복</hb>시킵니다.'
        +'완전히 성장 시 캠프 안의 몬스터를 처치하면 <bhm>(<passive>180 ~ 300</passive><icon>레벨</icon>)의 피해를 흡수하는 영구적인 보호막</bhm>을 획득홥니다. 보호막은 전투에서 벗어나고 10초 후에 재생됩니다.'+'<br><br><ul><li><passive>맛있는 간식:</passive> 동료가 챔피언을 도와주면서 몬스터에게 피해를 입힙니다. <num>40번</num>까지 동료에게 간식을 먹일 수 있습니다. 대형 몬스터를 처치할 때마다 간식을 한 번 먹이며, 보너스 간식이 있으면 두 번 먹입니다. 동료는 간식을 먹은 횟수에 따라 챔피언과 <passive>강타</passive>를 강화하고 새로운 효과를 부여합니다. 보너스 간식은 주기적으로 주어지며, 동료에게 먹이면 추가 골드를 받습니다.</li>'
        +'<br><li><passive>간식 20개:</passive> 동료의 힘으로 <passive>강타</passive>가 업그레이드되어 <true>900의 피해</true>를 입힙니다. 적 챔피언에게 강타를 사용하면 피해량이 감소하고 대상을 <status>둔화</status>시킵니다.</li>'
        +'<br><li><passive>간식 40개: 동료가 성체가 되어 고유한 추가 효과를 부여합니다. 강타</passive>가 한 번 더 업그레이드되어, 주변 몬스터에게 <passive>1200</passive>의 피해를 입힙니다.</li></ul>'
        +'<br>대형 및 에픽 몬스터는 간식 1개를 줍니다<br><br>대형 몬스터를 처치할 때마다 80의 추가 경험치를 얻습니다. 대형 몬스터를 처음으로 처치하면 150의 추가 경험치를 얻습니다.</maintext>' :
        
        v.name == '빛나는 티끌' ? v.description = '<maintext><stats>스킬 가속 <icon>스킬 가속</icon> <value>5</value></stats></maintext>' :
        v.name == '요정의 부적' ? v.description = '<maintext><stats>기본 마나 재생 <icon>기본 마나 재생</icon> <value>25%</value></stats></maintext>' : 
        v.name == '단검' ? v.description = '<maintext><stats>공격 속도 <icon>공격 속도</icon> <value>12%</value></stats></maintext>' :
        v.name == '천 갑옷' ? v.description = '<maintext><stats>방어력 <icon>방어력</icon> <value>15</value></stats></maintext>' :
        v.name == '원기 회복의 구슬' ? v.description = '<maintext><stats>기본 체력 재생 <icon>기본 체력 재생</icon> <value>25%</value></stats></maintext>' :
        v.name == '사파이어 수정' ? v.description = '<maintext><stats>마나 <icon>마나</icon> <value>250</value></stats></maintext>' :
        v.name == '롱소드' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>10</value></stats></maintext>' :
        v.name == '증폭의 고서' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>20</value></stats></maintext>' :
        v.name == '루비 수정' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>150</value></stats></maintext>' :
        v.name == '마법무효화의 망토' ? v.description = '<maintext><stats>마법 저항력 <icon>마법 저항력</icon> <value>25</value></stats></maintext>' :
        v.name == '민첩성의 망토' ? v.description = '<maintext><stats>치명타 확률 <icon>치명타 확률</icon> <value>15%</value></stats></maintext>' :
        v.name == '방출의 마법봉' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>45</value></stats></maintext>' :
        v.name == '곡괭이' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>25</value></stats></maintext>' :
        v.name == '쓸데없이 큰 지팡이' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>70</value></stats></maintext>' :
        v.name == 'B.F. 대검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>40</value></stats></maintext>' :

        v.name == '처형인의 대검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>15</value></stats>'
        +'<br><br><passive>고통스러운 상처</passive><br>챔피언에게 물리 피해를 입히면 3초 동안 <keyword>40% 고통스러운 상처</keyword>를 남깁니다.</maintext>' :
        v.name == '흡혈의 낫' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>15</value><br>생명력 흡수 <icon>생명력 흡수</icon> <value>7%</value></stats></maintext>' :
        v.name == '광휘의 검' ? v.description = '<maintext><stats>스킬 가속 <icon>스킬 가속</icon> <value>10</value></stats>'
        +'<br><br><passive>주문 검</passive>'
        +'<br>스킬을 사용하고 나면 다음 기본 공격 시 <ad>(<ggl>기본 <icon>공격력</icon>100%</ggl>)의 물리 피해</ad>(<passive>적중 시 </passive><icon>적중 시</icon>)를 추가로 입힙니다.</maintext>' :
        v.name == '콜필드의 전투 망치' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>20</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value></stats></maintext>' :
        v.name == '탐식의 망치' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>15</value><br>체력 <icon>체력</icon> <value>200</value></stats></maintext>' :
        v.name == '땅굴 채굴기' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>15</value><br>체력 <icon>체력</icon> <value>250</value></stats>'
        +'<br><br><etc>모든 도구는 누가 쥐는지에 따라 무기가 될 수 있습니다.</etc></maintext>' :
        v.name == '티아맷' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>20</value></stats>'
        +'<br><br><passive>쪼개기</passive><br>기본 공격 시 대상 주변에 있는 적들에게 <ad>(<ggl><icon>근거리</icon><icon>공격력</icon>40%</ggl> | <ggl><icon>원거리</icon><icon>공격력</icon>20%</ggl>)의 물리 피해</ad>를 입힙니다.'
        +'<br><br><active>활성화</active> (10초)'
        +'<br><active>초승달</active><br>주변 적에게 <ad>(<ggl></icon><icon>공격력</icon>75%</ggl>)의 물리 피해</ad>를 입힙니다.'
        +'<br><br><rules>구조물에는 <passive>쪼개기</passive>가 발동되지 않습니다.<br>아이템 성능은 <icon>근거리</icon> 근접 챔피언과 <icon>원거리</icon> 원거리 챔피언에게 각각 다르게 적용됩니다.</rules></maintext>' :
        v.name == '강철 인장' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>15</value><br>방어력 <icon>방어력</icon> <value>30</value></stats>'
        +'<br><br><etc>"계속 모으다 보면 이름이 이건지 저건지 헷갈리더군." - 사미라</etc></maintext>' :
        v.name == '주문포식자' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>25</value><br>마법 저항력 <icon>마법 저항력</icon> <value>35</value></stats>'
        +'<br><br><passive>생명선</passive> <icon>쿨다운</icon> (90초)'
        +'<br>체력이 30% 밑으로 떨어질 만큼 마법 피해를 입으면 2.5초 동안 <ap>(<passive><icon>근거리</icon>110 ~ 280<icon>레벨</icon></passive> | <passive><icon>원거리</icon>83 ~ 210<icon>레벨</icon></passive>)의 마법 피해를 흡수하는 보호막</ap>을 얻습니다.</maintext>' :
        v.name == '곡궁' ? v.description = '<maintext><stats>공격 속도 <icon>공격 속도</icon> <value>15%</value></stats>'
        +'<br><br><passive>독침</passive><br>기본 공격 시 <ap>15의 마법 피해</ap>(<passive>적중 시</passive> <icon>적중 시</icon>)를 입힙니다.</maintext>' :
        v.name == '키르히아이스의 파편' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>15</value></stats>'
        +'<br><br><passive>충격</passive><br><keyword>충전 상태로 공격</keyword> 시 <ap>50의 마법 피해</ap>를 추가로 입힙니다.</maintext>' :
        v.name == '열정의 검' ? v.description = '<maintext><stats>공격 속도 <icon>공격 속도</icon> <value>15%</value><br>치명타 확률 <icon>치명타 확률</icon> <value>15%</value><br>이동 속도 <icon>이동 속도</icon> <value>5%</value></stats></maintext>' :
        v.name == '온기가 필요한 자의 도끼' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>15</value><br>공격 속도 <icon>공격 속도</icon> <value>25%</value></stats></maintext>' :
        v.name == '절정의 화살' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>30</value><br>공격 속도 <icon>공격 속도</icon> <value>15%</value></stats>'
        +'<br><br><passive>정확성</passive><br>미니언과 몬스터에게 기본 공격 시 <ad>20의 물리 피해</ad>를 추가로 입힙니다.</maintext>' :
        v.name == '수은 장식띠' ? v.description = '<maintext><stats>마법 저항력 <icon>마법 저항력</icon> <value>30</value></stats>'
        +'<br><br><active>활성화</active> (90초)'
        +'<br><active>수은</active><br>모든 군중 제어 효과(<keyword>공중에 뜸</keyword> 제외)를 제거합니다.</maintext>' :
        v.name == '최후의 속삭임' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>20</value><br>방어구 관통력 <icon>방어구 관통력</icon> <value>18%</value></stats></maintext>' :
        v.name == '꽁지깃' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>20</value><br>이동 속도 <icon>이동 속도</icon> <value>4%</value></stats></maintext>' :
        v.name == '톱날 단검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>20</value></stats>'
        +'<br><br><passive>도려내기</passive><br><mrgtl>물리 관통력이 10</mrgtl> 증가합니다.</maintext>' :
        v.name == '야수화' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>25</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value><br>물리 관통력 <icon>물리 관통력</icon> <value>5</value></stats></maintext>' :
        v.name == '망각의 구' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>30</value></stats>'
        +'<br><br><passive>고통스러운 상처</passive><br>챔피언에게 마법  피해를 입히면 3초 동안 <keyword>40% 고통스러운 상처</keyword>를 남깁니다.</maintext>' :
        v.name == '에테르 환영' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>30</value><br>이동 속도 <icon>이동 속도</icon> <value>5%</value></stats></maintext>' :
        v.name == '악마의 마법서' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>25</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value></stats></maintext>' :
        v.name == '마법공학 교류 발전기' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>45</value></stats>'
        +'<br><br><passive>자극</passive> <icon>쿨다운</icon> (40초)<br>챔피언에게 피해를 입히면 <ap>65의 마법 피해</ap>를 추가로 입힙니다.</maintext>' :
        v.name == '역병의 보석' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>25</value><br>마법 관통력 <icon>마법 관통력</icon> <value>13%</value></stats></maintext>' :
        v.name == '사라진 양피지' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>30</value><br>마나 <icon>마나</icon> <value>300</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value>'
        +'<br><br><passive>깨우치기</passive><br>레벨 업하면 3초 동안 <mana>최대 마나의 20%</mana>를 회복합니다.</stats></maintext>' :
        v.name == '억겁의 카탈리스트' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>350</value><br>마나 <icon>마나</icon> <value>300</value><br></stats>'
        +'<br><br><passive>영원</passive><br>챔피언에게 피해를 받으면 감소 전 피해량의 7%에 해당하는 <mana>마나</mana>를 회복합니다. 스킬 사용 시 사용한 <mana>마나</mana>의 25%에 해당하는 체력을 회복합니다. 스킬 사용 1회당 초당 최대 <hb>20의 체력을 회복</hb>합니다.</maintext>' :
        v.name == '기괴한 가면' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>30</value><br>체력 <icon>체력</icon> <value>200</value></stats>'
        +'<br><br><passive>광기</passive><br>적 챔피언과 전투 중 매초 2%의 추가 피해를 입힙니다. (최대 6%)</maintext>' :
        v.name == '추적자의 팔목 보호대' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>45</value><br>방어력 <icon>방어력</icon> <value>25</value></stats>'
        +'<br><br><active><icon>사용 시</icon> 활성화</active>'
        +'<br><active>시간 정지</active> (한번만 사용 가능)<br>2.50초 동안 <keyword>경직</keyword> 상태가 됩니다.</maintext>' :
        v.name == '신록의 장벽' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>40</value><br>마법 저항력 <icon>마법 저항력</icon> <value>30</value></stats>'
        +'<br><br><passive>무효화</passive> <icon>쿨다운</icon> (60초)<br>적의 다음 스킬을 막아 주는 주문 방어막을 생성합니다.</maintext>' :
        v.name == '점화석' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>200</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value></stats></maintext>' :
        v.name == '쇠사슬 조끼' ? v.description = '<maintext><stats>방어력 <icon>방어력</icon> <value>40</value></stats></maintext>' :
        v.name == '덤불 조끼' ? v.description = '<maintext><stats>방어력 <icon>방어력</icon> <value>30</value></stats>'
        +'<br><br><passive>가시</passive><br>기본 공격에 맞으면 공격한 적에게 <ap>6의 마법 피해</ap>를 입히고, 대상이 챔피언일 경우 3초 동안 <keyword>40%의 고통스러운 상처</keyword>를 남깁니다.</maintext>' :
        v.name == '수정 팔 보호구' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>200</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>100%</value></stats></maintext>' :
        v.name == '비상의 월갑' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>150</value><br>이동 속도 <icon>이동 속도</icon> <value>5%</value></stats></maintext>' :
        v.name == '얼음 방패' ? v.description = '<maintext><stats>방어력 <icon>방어력</icon> <value>20</value><br>마나 <icon>마나</icon> <value>250</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value></stats></maintext>' :
        v.name == '음전자 망토' ? v.description = '<maintext><stats>마법 저항력 <icon>마법 저항력</icon> <value>50</value></stats></maintext>' :
        v.name == '거인의 허리띠' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>350</value></stats></maintext>' :
        v.name == '파수꾼의 갑옷' ? v.description = '<maintext><stats>방어력 <icon>방어력</icon> <value>40</value></stats>'
        +'<br><br><passive>견고</passive><br>기본 공격으로 받는 피해량이 최대 (<passive>5</passive> <chl>+ <icon>체력</icon>0.35%</chl>) 감소합니다. 이 수치는 피해량의 20%를 넘을 수 없습니다.</maintext>' :
        v.name == '바미의 불씨' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>300</value></stats>'
        +'<br><br><passive>불사르기</passive><br>피해를 받거나 입히면 주변 적들에게 3초 동안 매초 <ap>(<passive>13</passive> <chl>+ 추가 <icon>체력</icon>0.5%</chl>)의 마법 피해</ap>를 입힙니다. (미니언 대상 25%, 정글 몬스터 대상 25% 증가)</maintext>' :
        v.name == '망령의 두건' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>200</value><br>마법 저항력 <icon>마법 저항력</icon> <value>25</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>100%</value></stats></maintext>' :
        v.name == '금지된 우상' ? v.description = '<maintext><stats>기본 마나 재생 <icon>기본 마나 재생</icon> <value>50%</value><br>체력 회복 및 보호막 <icon>체력 회복 및 보호막</icon> <value>8%</value></stats></maintext>' :
        v.name == '밴들유리 거울' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>20</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>75%</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value></stats></maintext>' :
        v.name == '감시하는 와드석' ? v.description = '<maintext><rules><num>서폿터 퀘스트</num>를 완료한 후에만 구매할 수 있습니다.</rules><br><br><stats>체력 <icon>체력</icon> <value>150</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value><br>방어력 <icon>방어력</icon> <value>10</value><br>마법 저항력 <icon>마법 저항력</icon> <value>15</value></stats>'
        +'<br><br><passive>신비로운 상자</passive><br>이 아이템은 구매한 제어와드를 3개까지 저장할 수 있습니다.</maintext>' :

        v.name == '마법사의 최후'  ? v.description = '<maintext><stats>공격 속도 <icon>공격 속도</icon> <value>55%</value><br>마법 저항력 <icon>마법 저항력</icon> <value>50</value><br>강인함 <icon>강인함</icon> <value>20%</value></stats>'
        +'<br><br><passive>난투</passive><br>기본 공격 시 <ap>(<passive>(15 ~ 80<icon>레벨</icon>)</passive></ap>(<passive>적중 시</passive> <icon>적중 시</icon>)를 입힙니다.</maintext>' :
        v.name == '월식' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>70</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value></stats>'
        +'<br><br><passive>늘 떠오르는 달</passive> <icon>쿨다운</icon> (6초)<br>2초 내에 한 챔피언에게 별개의 기본 공격이나 스킬로 2회 공격하면 <ad>최대 체력의 (<icon>근거리</icon>8% | <icon>원거리</icon>4%)에 해당하는 추가 물리 피해</ad>를 입히고 2초 동안 <ap>(<icon>근거리</icon><passive>160</passive> <ggl>+ 추가 <icon>공격력</icon>40%</ggl> | <icon>원거리</icon><passive>80</passive> <ggl>+ 추가 <icon>공격력</icon>20%</ggl>)의 피해를 흡수하는 보호막</ap>을 얻습니다.'
        +'<br><br><rules>아이템 성능은 <icon>근거리</icon> 근접 챔피언과 <icon>원거리</icon> 원거리 챔피언에게 각각 다르게 적용됩니다.</rules></maintext>' :
        v.name == '맬모셔스의 아귀' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>65</value><br>마법 저항력 <icon>마법 저항력</icon> <value>50</value></stats>'
        +'<br><br><passive>생명선</passive> <icon>쿨다운</icon> (90초)<br>체력이 30% 밑으로 떨어질 만큼 마법 피해를 입으면 2.5초 동안 <ap>(<icon>근거리</icon><passive>200</passive> <ggl>+ 추가 <icon>공격력</icon>225%</ggl> | <icon>원거리</icon><passive>150</passive> <ggl>+ 추가 <icon>공격력</icon>168.75%</ggl>)의 마법 피해를 흡수하는 보호막</ap>을 얻습니다. <passive>생명선</passive> 효과가 발동하면 전투가 끝날 때까지 <hh>생명력 흡수 12%</hh>를 얻습니다.</maintext>' :
        v.name == '화공 펑크 사슬검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br>체력 <icon>체력</icon> <value>250</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>광란의 뿔</passive><br>적 챔피언에게 물리 피해를 입히면 3초 동안 <keyword>40%의 고통스러운 상처</keyword>를 남깁니다.</maintext>' :
        v.name == '마나무네' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>35</value><br>마나 <icon>마나</icon> <value>500</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>경탄</passive><br><ggl>(<mana><icon>마나</icon>2.5%</mana>)의 추가 공격력</ggl>을 얻습니다.<br><br><passive>마나순환</passive><br>대상에게 스킬 또는 기본 공격을 적중시키면 중첩을 하나 소모해 <mana>3의 추가 마나</mana>를 얻습니다. 챔피언 대상으로는 두 배로 적용됩니다. 추가 마나가 최대치인 <mana>360</mana>에 도달하면 <passive>무라마나</passive>로 변합니다.'
        +'<br><br><rules>8초마다 새로운 <passive>마나 충전</passive> 중첩을 얻습니다. (최대 4)</rules></maintext>' :
        v.name == '실험적 마공학판' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br>공격 속도 <icon>공격 속도</icon> <value>25%</value><br>체력 <icon>체력</icon> <value>300</value></stats>'
        +'<br><br><passive>마공학 충전</passive><br>궁극기의 스킬 가속이 30 증가합니다.'
        +'<br><br><passive>폭주</passive> <icon>쿨다운</icon> (30초)<br>궁극기를 사용한 후 8초 동안 <ggsd>30% 공격 속도</ggsd>와 <speed>15%의 이동 속도</speed>를 얻습니다.'
        +'<br><br><etc>군중 제어는 성가신 일이 되기도 하죠.</etc></maintext>' :
        v.name == '선체파괴자' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>65</value><br>체력 <icon>체력</icon> <value>350</value><br>이동 속도 <icon>이동 속도</icon> <value>5%</value></stats>'
        +'<br><br><passive>선장</passive><br>챔피언과 에픽 몬스터에게 다섯 번째 기본 공격을 가할 때마다 <ad>(<icon>근거리</icon><ggl>기본 <icon>공격력</icon>140%</ggl> <chl>+ <icon>체력</icon>3.5%</icoin></chl> | <icon>원거리</icon><ggl>기본 <icon>공격력</icon>70%</ggl> <chl>+ <icon>체력</icon>3.5%</icoin></chl>)의 추가 물리 피해</ad>를 입힙니다. 대상이 구조물일 경우 <ad>(<icon>근거리</icon><ggl>기본 <icon>공격력</icon> 400%</ggl> <chl>+ <icon>체력</icon>7%</chl> | <icon>원거리</icon><ggl>기본 <icon>공격력</icon> 200%</ggl> <chl>+ <icon>체력</icon>7%</chl>)까지 증가합니다.</ad>'
        +'<br><br><passive>승선 부대</passive><br>주변 공성 미니언고 슈퍼 미니언이 (<icon>근거리</icon><passive>20 ~ 135<icon>레벨</icon></passive> | <icon>원거리</icon><passive>10 ~ 68<icon>레벨</icon></passive>)의 <bul>방어력</bul> 및 <ap>마법 저항력</ap>을 얻습니다.</maintext>' :
        v.name == '칠흑의 양날 도끼' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br>체력 <icon>체력</icon> <value>400</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>깎아내기</passive><br>챔피언에게 <ad>물리 피해</ad>를 가하면 6초 동안 <bul>방어력을 5% 감소</bul>시키는 중첩을 1회 적용합니다. (최대 <bul>방어력 25% 감소</bul>)'
        +'<br><br><passive>열정</passive><br><ad>물리 피해</ad>를 입히면 2초 동안 <speed>20의 이동 속도</speed>를 얻습니다.</maintext>' :
        v.name == '스테락의 도전' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>400</value><br>강인함 <icon>강인함</icon> <value>20%</value></stats>'
        +'<br><br><passive>잡아채는 발톱</passive><br><ggl>기본 <icon>공격력</icon>50%의 추가 공격력</ggl>을 얻습니다.'
        +'<br><br><passive>생명선</passive> <icon>쿨다운</icon> (60초)<br>체력이 30% 밑으로 떨어질 만큼 피해를 입으면 <ap><chl>추가 <icon>체력</icon>80%</chl>의 피해를 흡수하는 보호막</ap>을 얻습니다. 보호막 피해 흡수량은 4.5초에 걸쳐 점차 감소합니다.</maintext>' :
        v.name == '쇼진의 창' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br>체력 <icon>체력</icon> <value>300</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>드래곤의 힘</passive><br>일반 스킬의 스킬 가속이 15 증가합니다.'
        +'<br><br><passive>집중된 의지</passive><br>6초 동안 스킬 적중 시 중첩을 얻으며, 최대 4회까지 중첩됩니다. 중첩당 스킬 피해량이 (<icon>근거리</icon><passive>3%</passive> | <icon>원거리</icon><passive>2%</passive>) 증가합니다.</maintext>' :
        v.name == '갈라진 하늘' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>45</value><br>체력 <icon>체력</icon> <value>450</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>라이트실드 타격</passive> 대상별: <icon>쿨다운</icon> (6초)'
        +'<br>챔피언에게 처음 기본 공격을 가할 때 치명타로 적용되고 잃은 체력의 <hb>(<icon>근거리</icon><ggl>기본 <icon>공격력 </icon>140%</ggl> | <icon>원거리</icon><ggl>기본 <icon>공격력 </icon>70%</ggl>)에 해당하는 체력을 회복</hb>합니다.</maintext>' :
        v.name == '몰락한 왕의 검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>40</value><br>공격 속도 <icon>공격 속도</icon> <value>25</value><br>생명력 흡수 <icon>생명력 흡수</icon> <value>8%</value></stats>'
        +'<br><br><passive>안개의 검</passive><br>기본 공격 시 <ad>적 현재 체력에 따라 (<icon>근거리</icon><passive>12%</passive> | <icon>원거리</icon><passive>9%</passive>)의 물리 피해</ad>(<passive>적중 시</passive> <icon>적중 시</icon>)를 입힙니다.'
        +'<br><br><passive>할퀴는 그림자</passive> <icon>쿨다운</icon> (15초)<br>챔피언에게 첫 기본 공격 시 1초 동안 (<icon>근거리</icon><passive>30%</passive> | <icon>원거리</icon><passive>15%</passive>) <status>둔화</status>시킵니다.'
        +'<br><br><rules><passive>안개의 검</passive>은 미니언 및 정글 몬스터에게 최대 60의 피해를 입힙니다.<br>아이템 성능은 <icon>근거리</icon> 근접 챔피언과 <icon>원거리</icon> 원거리 챔피언에게 각각 다르게 적용됩니다.</rules></maintext>' :
        v.name == '죽음의 무도' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value><br>방어력 <icon>방어력</icon> <value>40</value></stats>'
        +'<br><br><passive>고통 무시</passive><br>자신이 받은 피해의 (<icon>근거리</icon><passive>30%</passive> | <icon>원거리</icon><passive>10%</passive>)만큼을 3초에 걸쳐서 입습니다.'
        +'<br><br><passive>반항</passive><br>자신이 피해를 입힌 챔피언이 3초 안에 죽으면 <passive>고통 무시</passive>의 지속 피해 효과가 사라지고 2초에 걸쳐 <hb><ggl>추가 <icon>공격력</icon>50%</ggl>의 체력을 회복</hb>합니다.'
        +'<br><br><rules>아이템 성능은 <icon>근거리</icon> 근접 챔피언과 <icon>원거리</icon> 원거리 챔피언에게 각각 다르게 적용됩니다.</rules></maintext>' :
        v.name == '수호 천사' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br>방어력 <icon>방어력</icon> <value>45</value></stats>'
        +'<br><br><passive>환생</passive> <icon>쿨다운</icon> (300초)<br>치명적인 피해를 입으면 4초 동안 <keyword>경직</keyword>에 걸린 다음 <hb>기본 체력의 50%</hb>, <mana>최대 마나의 100%</mana>를 회복합니다.</maintext>' :
        v.name == '굶주린 히드라' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>70</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value><br>생명력 흡수 <icon>생명력 흡수</icon> <value>12%</value></stats>'
        +'<br><br><passive>쪼개기</passive><br>기본 공격 시 대상 주변에 있는 적들에게 <ad>(<ggl><icon>근거리</icon><icon>공격력</icon>40%</ggl> | <ggl><icon>원거리</icon><icon>공격력</icon>20%</ggl>)의 물리 피해</ad>를 입힙니다.'
        +'<br><br><active>활성화</active> (10초)'
        +'<br><active>굶주린 초승달</active><br>주변 적에게 <ggl><icon>공격력</icon>100%</ggl><ad>의 물리 피해</ad>를 입히고 150%의 생명력 흡수를 적용합니다.'
        +'<br><br><rules><passive>쪼개기</passive>에는 생명력 흡수 효과가 적용됩니다.<br>구조물에는 <passive>쪼개기</passive>가 발동되지 않습니다.<br>아이템 성능은 <icon>근거리</icon> 근접 챔피언과 <icon>원거리</icon> 원거리 챔피언에게 각각 다르게 적용됩니다.</rules></maintext>' :
        v.name == '거대한 히드라' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>50</value><br>체력 <icon>체력</icon> <value>550</value></stats>'
        +'<br><br><passive>쪼개기</passive><br>기본 공격 시 <ad>(<icon>근거리</icon><chl><icon>체력</icon>1.5%</chl> | <icon>원거리</icon><chl><icon>체력</icon>0.75%</chl>)의 물리 피해</ad>(<passive>적중 시</passive> <icon>적중 시</icon>)를 추가로 입히고 대상 뒤에 적들에게 <ad>(<icon>근거리</icon><chl><icon>체력</icon>3%</chl> | <icon>원거리</icon><chl><icon>체력</icon>1.5%</chl>)의 물리 피해</ad>를 입힙니다.'
        +'<br><br><active>활성화</active> (10초)'
        +'<br><active>거대한 초승달</active><br>다음 기본 공격 시 <passive>쪼개기</passive>가 대상에게 <ad>(<icon>근거리</icon><chl><icon>체력</icon>4%</chl> | <icon>원거리</icon><chl><icon>체력</icon>2%</chl>)의 추가 물리 피해</ad>를 입히고 충격파 범위에 <ad>(<icon>근거리</icon><chl><icon>체력</icon>9%</chl> | <icon>원거리</icon><chl><icon>체력</icon>4.5%</chl>)의 추가 물리 피해</ad>를 입힙니다.'
        +'<br><br><rules><passive>적중 시</passive> <icon>적중 시</icon>의 피해는 구조물에도 적용됩니다.<br>구조물에는 <passive>쪼개기</passive>의 충격파 발동되지 않습니다.<br>아이템 성능은 <icon>근거리</icon> 근접 챔피언과 <icon>원거리</icon> 원거리 챔피언에게 각각 다르게 적용됩니다.</rules></maintext>' :
        v.name == '발걸음 분쇄기' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>50</value><br>공격 속도 <icon>공격 속도</icon> <value>30%</value><br>체력 <icon>체력</icon> <value>450</value></stats>'
        +'<br><br><passive>쪼개기</passive><br>기본 공격 시 대상 주변에 있는 적들에게 <ad>(<ggl><icon>근거리</icon><icon>공격력</icon>40%</ggl> | <ggl><icon>원거리</icon><icon>공격력</icon>20%</ggl>)의 물리 피해</ad>를 입힙니다.'
        +'<br><br><passive>담금질</passive><br><ad>물리 피해</ad>를 입히면 2초 동안 <speed>20의 이동 속도</speed>를 얻습니다.'
        +'<br><br><active>활성화</active> (15초)'
        +'<br><active>파괴의 충격파</active><br><ggl><ad><icon>공격력</icon>80%</ggl>의 물리 피해</ad>를 입히고 주변 적들을 35% <status>둔화</status>시키면 적중당한 챔피언 하나당 <speed>35%의 추가 이동 속도</speed>를 얻습니다. 추가 이동 속도는 3초에 걸쳐 점차 감소합니다. 스킬을 시전하는 동안 이동할 수 있습니다.'
        +'<br><br><rules>구조물에는 <passive>쪼개기</passive>가 발동되지 않습니다.<br>아이템 성능은 <icon>근거리</icon> 근접 챔피언과 <icon>원거리</icon> 원거리 챔피언에게 각각 다르게 적용됩니다.</rules></maintext>' :
        v.name == '삼위일체' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>45</value><br>공격 속도 <icon>공격 속도</icon> <value>33%</value><br>체력 <icon>체력</icon> <value>300</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>주문 검</passive><br>스킬을 사용하고 나면 다음 기본 공격 시 <ad><ggl>기본 <icon>공격력</icon>200%</ggl>의 물리 피해</ad>를 추가로 입힙니다.'
        +'<br><br><passive>가속</passive><br>유닛에게 기본 공격을 가하면 2초 동안 <speed>이동 속도가 20</speed> 상승합니다.</maintext>' :
        v.name == '스태틱의 단검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>50</value><br>공격 속도 <icon>공격 속도</icon> <value>30%</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value></stats>'
        +'<br><br><passive>전기충격</passive><br><keyword>충전 상태로 기본 공격</keyword> 시 연쇄 번개를 발사하여 최대 <passive>6</passive>명의 대상에게 <ap>90의 마법 피해</ap>를 입힙니다.'
        +'<br><br><rules>미니언이 150의 마법 피해를 입습니다.</rules></maintext>' :
        v.name == '루난의 허리케인' ? v.description = '<maintext><icon>원거리</icon> <div style="color:#f04e40; width:auto; display:inline-block;">원거리 챔피언 전용입니다.</div><br><br><stats>공격 속도 <icon>공격 속도</icon> <value>40%</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value><br>이동 속도 <icon>이동 속도</icon> <value>7%</value></stats>'
        +'<br><br><passive>쪼기</passive><br>기본 공격 시 <ap>30의 마법 피해</ap>(<passive>적중 시</passive> <icon>적중 시</icon>)를 입힙니다.'
        +'<br><br><passive>바람의 분노</passive><br>기본 공격 시 대상 주변 최대 2명의 적에게 작은 탄환을 발사하여, 각각 <ggl><icon>공격력</icon>40%</ggl><ad>의 물리 피해</ad>를 입힙니다. 이 탄환에는 치명타 및 적중 시 효과가 적용됩니다.</maintext>' :
        v.name == '유령 무희' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>20</value><br>공격 속도 <icon>공격 속도</icon> <value>30%</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value><br>이동 속도 <icon>이동 속도</icon> <value>10%</value></stats>'
        +'<br><br><passive>망령의 왈츠</passive><br>기본 공격 시 3초 동안 <keyword>유체화</keyword> 상태가 되기 <ggsd>7%의 공격 속도</ggsd> 증가 중첩을 얻습니다. 최대 5회까지 중첩됩니다. (최대 <ggsd>35%의 공격 속도</ggsd>)</maintext>' :
        v.name == '구인수의 격노검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>35</value><br>주문력 <icon>주문력</icon> <value>35</value><br>공격 속도 <icon>공격 속도</icon> <value>25%</value></stats>'
        +'<br><br><passive>분노</passive><br>기본 공격 시 <ap>30의 마법 피해</ap>(<passive>적중 시</passive> <icon>적중 시</icon>)를 입힙니다.'
        +'<br><br><passive>들끓는 일격</passive><br>기본 공격 시 <ggsd>공격 속도가 8%</ggsd> 증가합니다. 해당 효과는 4번까지 중첩되어 최대 <ggsd>공격 속도가 32%</ggsd>까지 증가합니다. 최대 중첩 시 세 번째 기본 공격을 가할 때마다 <passive>적중 시</passive> <icon>적중 시</icon> 효과를 두 번씩 적용합니다.</maintext>' :
        v.name == '징수의 총' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value><br>물리 관통력 <icon>물리 관통력</icon> <value>16</value></stats>'
        +'<br><br><passive>죽음</passive><br>체력이 5% 미만인 챔피언에게 피해를 입힐 경우 처형합니다.'
        +'<br><br><passive>세금</passive><br>챔피언 처치 시 추가로 <gold>25골드</gold>를 얻습니다.</maintext>' :
        v.name == '크라켄 학살자' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>40</value><br>공격 속도 <icon>공격 속도</icon> <value>35%</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value></stats>'
        +'<br><br><passive>벼락</passive><br>세 번째 기본 공격마다 <ad>(<passive>140 ~ 310<icon>레벨</icon></passive>)의 물리 피해</ad>(<passive>적중 시</passive> <icon>적중 시</icon>)를 입힙니다. 6초 안에 같은 대상을 맞히면 피해량 50% 증가하며 최대 100%(<passive>280 ~ 620<icon>레벨</icon>)까지 증가합니다.</passive>)</maintext>' :
        v.name == '고속 연사포' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>30</value><br>공격 속도 <icon>공격 속도</icon> <value>20%</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value><br>이동 속도 <icon>이동 속도</icon> <value>7%</value></stats>'
        +'<br><br><passive>저격수</passive><br><keyword>충전 상태로 기본 공격</keyword> 시 <ap>60의 추가 마법 피해</ap>를 입히고 공겨 사거리가 35% 증가합니다.'
        +'<br><br><rules>사거리는 최대 150유닛 거리까지만 증가할 수 있습니다.</rules></maintext>' :
        v.name == '정수 약탈자' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>60</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>주문 검</passive><br>스킬을 사용하고 나면 다음 기본 공격 시 <ad>(<ggl>기본 <icon>공격력</icon>140% + 추가 <icon>공격력</icon>20%</ggl>)의 물리 피해</ad>(<passive>적중 시</passive> <icon>적중 시</icon>)를 추가로 입히고 <mana>마나를 (<ggl>기본 <icon>공격력</icon>56% + 추가 <icon>공격력</icon>8%</ggl>)</mana> 회복합니다.</maintext>' :
        v.name == '불멸의 철갑궁' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>50</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value><br>생명력 흡수 <icon>생명력 흡수</icon> <value>12%</value></stats>'
        +'<br><br><passive>생명선</passive> <icon>쿨다운</icon> (90초)'
        +'<br>체력이 30% 밑으로 떨어질 만큼 피해를 입으면 3초 동안 <ap>(<passive>320 ~ 530<icon>레벨</icon></passive>)의 피해를 흡수하는 보호막</ap>을 얻습니다.</maintext>' :
        v.name == '헤르메스의 시미터' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>40</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value><br>마법 저항력 <icon>마법 저항력</icon> <value>50</value></stats>'
        +'<br><br><active>활성화</active> (90초)'
        +'<br><active>수은</active><br>모든 군중 제어 효과(<keyword>공중의 뜸</keyword> 제외)를 제거하고 1.5초 동안 <speed>50%의 이동 속도</speed>를 얻습니다.</maintext>' :
        v.name == '필멸자의 운명' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>40</value><br>방어구 관통력 <icon>물리 관통력</icon> <value>35%</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value></stats>'
        +'<br><br>적 챔피언에게  피해를 입히면 3초 동안 <keyword>40%의 고통스러운 상처</keyword>를 남깁니다.</maintext>' :
        v.name == '도미닉 경의 인사' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>40</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value><br>방어구 관통력 <icon>물리 관통력</icon> <value>35%</value></stats>'
        +'<br><br><passive>거인 학살자</passive><br>자신보다 최대 체력이 높은 적 챔피언에게 최대 15%의 추가 피해를 입힙니다.'
        +'<br><br><rules>체력 차이가 2000 이상일 때 추가 피해량이 최대가 됩니다.</rules></maintext>' :
        v.name == '경계' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>40</value><br>공격 속도 <icon>공격 속도</icon> <value>30%</value></stats>'
        +'<br><br><passive>그림자</passive><br>기본 공격 시 <ap>30의 마법 피해</ap>(<passive>적중 시</passive> <icon>적중 시</icon>)를 입힙니다.'
        +'<br><br><passive>빛과 어둠</passive><br>챔피언에게 기본 공격 시 <num>빛</num>과 <num>어둠</num> 적중 효과를 번갈아 가며 적용합니다.'
        +'<ul><li><num>빛</num> 기본 공격 시 5초 동안 <bul>방어력</bul>과 <ap>마법 저항력</ap>이 (<passive>6 ~ 8<icon>레벨</icon></passive>) 증가합니다. (최대 (<passive>18 ~ 24<icon>레벨</icon></passive>))</li><li><num>어둠</num> 기본 공격 시 5초 동안 10% <bul>방어구 관통력</bul>과 <ap>마법 관통력</ap>을 얻습니다. (최대 30%)</li></ul></maintext>' :
        v.name == '폭풍갈퀴' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>60</value><br>공격 속도 <icon>공격 속도</icon> <value>15%</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value></stats>'
        +'<br><br><passive>번개</passive><br><keyword>충전 상태로 기본 공격</keyword> 시 <ap>100의 추가 마법 피해</ap>를 입히고 1.5초 동안 <speed>이동 속도가 45% </speed>증가합니다.</maintext>' :
        v.name == '무한의 대검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>65</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value><br>치명타 피해량 <icon>치명타 피해량</icon> <value>50%</value></stats></maintext>' :
        v.name == '나보리 신속검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>65</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>깨달음</passive><br>기본 공격 시 기본 스킬의 남은 재사용 대기시간이 <passive>12%</passive> 감소합니다.'
        +'<br><br><passive>비영구</passive><br>치명타 확률에 따라 스킬 피해량이 최대 (<passive><icon>치명타 확률</icon>20%</passive>)까지 상승합니다.</maintext>' :
        v.name == '피바라기' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br></stats>치명타 확률 <icon>치명타 확률</icon> <value>20%</value><br>생명력 흡수 <icon>생명력 흡수</icon> <value>18%</value>'
        +'<br><br><passive>탐식</passive><br>체력이 70% 이상일 경우 공격력이 <ggl>(<passive>10 ~ 40<icon>레벨</icon></passive>)</ggl> 증가합니다.</maintext>' :
        v.name == '독사의 송곳니' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br>물리 관통력 <icon>물리 관통력</icon> <value>15</value></stats>'
        +'<br><br><passive>보호막 파괴자</passive><br>적 챔피언에게 피해를 입히면 3초 동안 받는 보호막의 효과를 (<icon>근거리</icon>50% | <icon>원거리</icon>35%) 감소시킵니다. 보호막 파괴자에 영향을 받지 않은 적에게 피해를 입히면 보호막을 (<icon>근거리</icon>50% | <icon>원거리</icon>35%) 감소시킵니다.'
        +'<br><br><rules>마법 피해만 막는 보호막은 감소시키지 않습니다</rules></maintext>' :
        v.name == '그림자 검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>50</value><br>물리 관통력 <icon>물리 관통력</icon> <value>15</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>얌전</passive> <icon>쿨다운</icon> (50초)<br>적 와드에 발각되면 8초간 암전을 일으켜 근터의 투명한 덫과 와드를 드러내고, 추가로 와드를 무력화시킵니다.<br>와드를 기본 공격 하면 (<icon>근거리</icon>3 | <icon>원거리</icon>2)의 피해를 입힙니다.</maintext>' :
        v.name == '요우무의 유령검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>60</value><br>물리 관통력 <icon>물리 관통력</icon> <value>18</value></stats>'
        +'<br><br><passive>출몰</passive><br>전투에서 벗어나 있을 떄 <speed>이동 속도가 (<icon>근거리</icon>40 | <icon>원거리</icon>20)</speed> 상승합니다.'
        +'<br><br><active>활성화</active> (45초)'
        +'<br><active>망령의 발걸음</active><br>6초 동안 <speed>이동 속도가 (<icon>근거리</icon>20% | <icon>원거리</icon>15%)</speed> 상승하고 <keyword>유체화</keyword> 상태가 됩니다.</maintext>' :
        v.name == '기회' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br>물리 관통력 <icon>물리 관통력</icon> <value>18</value><br>이동 속도 <icon>이동 속도</icon> <value>5%</value></stats>'
        +'<br><br><passive>준비</passive><br>8초 동안 챔피언과 전투를 벌이지 않으면 <mrgtl>물리 관통력이 (<passive>5 ~ 10<icon>레벨</icon></passive>)</mrgtl> 증가합니다. 이 물리 관통력 증가 효과는 챔피언에게 피해를 입힐 경우 3초 후에 사라집니다.'
        +'<br><br><passive>탈출</passive><br>피해를 입힌 챔피언이 3초 안에 죽으면 1.5초 동안 <speed>이동 속도가 150 증가했다가 점차 감소</speed>합니다.'
        +'<br><br><etc>때로는 직접 만들어야 할 때로 있죠...</etc></maintext>' :
        v.name == '밤의 끝자락' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>50</value><br>물리 관통력 <icon>물리 관통력</icon> <value>15</value><br>체력 <icon>체력</icon> <value>250</value></stats>'
        +'<br><br><passive>무효화</passive> <icon>쿨다운</icon> (40초)<br>적의 다음 스킬을 막아 주는 주문 방어막을 생성합니다.'
        +'<br><br><rules>챔피언에게 피해를 입으면 아이템 재사용 대기시간이 초기화됩니다.</rules></maintext>' :
        v.name == '벼락폭풍검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br>물리 관통력 <icon>물리 관통력</icon> <value>18</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>전류 자극</passive><br>돌진 및 은신이 <keyword>충전 상태</keyword> 중첩을 75% 더 빨리 쌓이게 합니다.'
        +'<br><br><passive>창공</passive><br><keyword>충전 상태로 기본 공격</keyword> 시 적에게 <ad>100의 추가 물리 피해</ad>를 입히고, 0.75초 동안 (<icon>근거리</icon>99% | <icon>원거리</icon>20%) <status>둔화</status>시킵니다.</maintext>' :
        v.name == '오만' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>60</value><br>물리 관통력 <icon>물리 관통력</icon> <value>18</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>명성</passive><br>자신이 피해를 입힌 챔피언이 3초 안에 죽으면 90초 동안 <ggl>15+처치한 챔피언 하나당 2의 공격력</ggl>이 증가합니다.'
        +'<br><br><etc>처치한 챔피언:(이곳엔 처치한 챔피언 수가 표시됩니다)</etc></maintext>' :
        v.name == '원칙의 원형낫' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br>물리 관통력 <icon>물리 관통력</icon> <value>18</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value></stats>'
        +'<br><br><passive>흐름</passive><br>피해를 입힌 챔피언이 3초 내에 처치되면 궁극기 총 재사용 대기시간의 (<passive>10</passive> <mrgtl>+<icon>물리 관통력</icon>30%</mrgtl>)%를 돌려받습니다.</maintext>' :
        v.name == '불경한 히드라' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>60</value><br>물리 관통력 <icon>물리 관통력</icon> <value>18</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>쪼개기</passive><br>기본 공격 시 대상 주변에 있는 적들에게 <ad>(<ggl><icon>근거리</icon><icon>공격력</icon>50%</ggl> | <ggl><icon>원거리</icon><icon>공격력</icon>25%</ggl>)의 물리 피해</ad>를 입힙니다.'
        +'<br><br><active>활성화</active> (10초)<br>'
        +'<active>이단의 가르기</active><br>주변 적들에게 <ggl><icon>공격력</icon>100%</ggl><ad>의 물리피해</ad>를 입힙니다. 체력이 50% 이하인 적에게는 <ggl><icon>공격력</icon>130%</ggl><ad>의 물리 피해</ad>를 입힙니다.'
        +'<br><br><rules>구조물에는 <passive>쪼개기</passive>가 발동되지 않습니다.<br>아이템 성능은 <icon>근거리</icon> 근접 챔피언과 <icon>원거리</icon> 원거리 챔피언에게 각각 다르게 적용됩니다.</rules>'
        +'<br><br><etc>심연에는 제물이 필요합니다.</etc></maintext>' :
        v.name == '세릴다의 원한' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>45</value><br>물리 관통력 <icon>물리 관통력</icon> <value>15</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>적개심</passive><br>(<passive>20%</passive> <mrgtl>+ <icon>물리 관통력</icon>0.11%</mrgtl>)의 방어구 관통력을 얻습니다.'
        +'<br><br><passive>매서운 추위</passive><br>스킬로 체력이 50% 이하인 적에게 피해를 입히면 1초 동안 30% <status>둔화</status>시킵니다.</maintext>' :
        v.name == '메자이의 영혼약탈자' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>20</value><br>체력 <icon>체력</icon> <value>100</value></stats>'
        +'<br><br><passive>영광</passive>'
        +'<br><ul><li>적을 처치하거나 어시스트를 올릴 때 중첩을 획득합니다. 중첩당 <jml>5의 주문력</jml>을 얻습니다. 적 챔피언을 처치할 때마다 중첩 4회, 어시스트를 올릴 때마다 중첩 2회가 쌓입니다. 최대 25회까지 쌓을 수 있으며 사망 시 중첩 10회가 사라집니다.</li><li>10중첩 이상일 때 <speed>이동 속도가 10%</speed>  상승합니다.</li></ul>'
        +'<br><br><rules>획득한 <passive>영광</passive> 중첩은 이 아이템과 <passive>암흑의 인장</passive>에 모두 적용됩니다.</rules></maintext>' :
        v.name == '모렐로노미콘' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>90</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>고통스러운 상처</passive><br>적 챔피언에게 마법 피해를 입히면 3초 동안 <keyword>40%의 고통스러운 상처</keyword>를 남깁니다.</maintext>' :
        v.name == '마법공학 로켓 벨트' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>70</value><br>체력 <icon>체력</icon> <value>300</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><active>활성화</active> (40초)'
        +'<br><active>초음속</active><br>지정 방향으로 돌진하며 부채꼴 모양으로 <ap>(<passive>100</passive> <jml>+ <icon>주문력</icon>10%</jml>)의 마법 피해</ap>를 입히는 마법 탄환을 발사합니다.'
        +'<br><br><rules>초음속 돌진으로 지형을 통과할 수 없습니다.</rules></maintext>' :
        v.name == '영겁의 지팡이' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>50</value><br>체력 <icon>체력</icon> <value>400</value><br>마나 <icon>마나</icon> <value>400</value></stats>'
        +'<br><br><passive>불멸의 시간</passive><br>60초마다 <chl>체력 20</chl>, <mana>마나 20</mana>, <jml>주문력 4</jml>씩 상승합니다. 최대 10회까지 중첩됩니다. 최대 중첩에 도달하면 레벨이 오릅니다.'
        +'<br><br><passive>영원</passive><br>챔피언에게 피해를 받으면 감소 전 피해량의 7%의 해당하는 <mana>마나</mana>를 회복합니다. 스킬 사용 시 사용한 <mana>마나</mana>의 25%에 해당하는 체력을 회복합니다. 스킬 사용 1회당 초당 최대 <chl>20의 체력</chl>을 회복합니다.</maintext>' :
        v.name == '라일라이의 수정홀' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>75</value><br>체력 <icon>체력</icon> <value>400</value></stats>'
        +'<br><br><passive>서리</passive><br>스킬로 적에게 피해를 입히면 1초 동안 30% <status>둔화</status>시킵니다.</maintext>' :
        v.name == '지평선의 초점' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>90</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>초강력 사격</passive><br>600 거리 이상에서 스킬로 챔피언에게 피해를 입히면 6초 동안 대상의 <keyword>위치를 드러냅니다. 위치가 드러난</keyword> 적에게 초강력 사격으로 입히는 피해량이 10% 증가합니다.'
        +'<br><br><passive>집중</passive> <icon>쿨다운</icon> (30초)<br><passive>초강력 사격</passive> 발동 시 3초 동안 대상으로부터 1400의 사거리 내에 있는 다른 모든 적 챔피언의 <keyword>위치를 드러냅니다</keyword>.'
        +'<br><br><rules>소환물이나 덫은 이 효과를 발동시키지 않습니다. 범위 지정 스킬은 처음에만 이 효과를 발동시키고, 거리는 사용 시 위치 기준으로 계산됩니다.'
        +'<br><br><passive>집중</passive>으로 위치가 드러난 대상에게 <passive>초강력 사격</passive>의 피해량이 증폭됩니다.</rules></maintext>' :
        v.name == '악의' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>80</value><br>마나 <icon>마나</icon> <value>600</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value></stats>'
        +'<br><br><passive>경멸</passive><br>궁극기의 스킬 가속이 20 증가합니다.'
        +'<br><br><passive>증오 안개</passive><br>궁극기로 챔피언에게 피해를 입히면 대상 발밑의 지면을 불태워 <ap>(<passive>60</passive> <jml>+ <icon>주문력</icon>5%</jml>)의 마법 피해</ap>를 입히고 <ap>마법 저항력을 10</ap> 감소시킵니다.'
        +'<br><br><rules>입힌 피해량에 따라 반경이 늘어납니다. (최대 반경 550)<br>기본 공격으로 피해를 입히면 증오안개가 발동하지 않습니다.</rules></maintext>' : 
        v.name == '무덤꽃' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>70</value><br>마법 관통력 <icon>마법 관통력</icon> <value>30%</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value>'
        +'<br><br><passive>죽음에서 피어난 생명</passive> <icon>사용 시</icon> (60초)<br>적 챔피언에게 피해를 입히고 3초 내로 처치에 관여할 때마다, 해당 챔피언 위치에 치유의 힘을 폭발시켜 아군의 체력을 <hb>(<passive>50</passive> <jml>+ <icon>주문력</icon>50%</jml>)</hb>만큼 회복시킵니다.'
        +'<br><br><etc>죽음에서 생명으로.</etc></maintext>' :
        v.name == '폭풍 쇄도' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>95</value><br>마법 관통력 <icon>마법 관통력</icon> <value>10</value><br>이동 속도 <icon>이동 속도</icon> <value>8%</value></stats>'
        +'<br><br><passive>폭풍 약탈자</passive> <icon>쿨다운</icon> (30초)<br>2.5초 내로 챔피언 최대 체력의 35%에 해당하는 피해를 입히면 <passive>질풍</passive>을 적용하고 2초 동안 <speed>이동 속도가 25%</speed> 증가합니다.'
        +'<br><br><passive>질풀</passive><br>2초 후에 대상을 가격하여 <ap>(<icon>근거리</icon><passive>140</passive> <jml>+ <icon>주문력</icon>20%</jml> | <icon>원거리</icon><passive>105</passive> <jml>+ <icon>주문력</icon>15%</jml>)의 마법 피해</ap>를 입힙니다. 가격 전에 대상이 사망할 경우 즉시 폭발해 넓은 범위에 피해를 입히고 <gold>30골드</gold>를 획득합니다.</maintext>' :
        v.name == '루덴의 동반자' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>95</value><br>마나 <icon>마나</icon> <value>600</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value></stats>'
        +'<br><br><passive>장전</passive><br>3초마다 <ap>사격 충전</ap> 중첩을 얻습니다. 최대 6회까지 중첩됩니다.'
        +'<br><br><passive>발사</passive><br>스킬로 적에게 피해를 입히면 모든 사격 충전 중첩을 소모하여, 소모한 충전 하나당 대상과 주면 다른 대상 한 명 에게 <ap>(<passive>45</passive> <jml>+ <icon>주문력</icon>4%</jml>)의 추가 마법 피해</ap>를 입힙니다. 사거리 안에 다른 대상이 없을 경우 첫 번째 대상에게 남은 사격 충전 중첩만큼 35%의 피해를 반복해서 입힙니다.'
        +'<br><br><etc>"마법사의 가장 좋은 친구! 오늘 구매하세요!" - 필트오버 상인 (사망한 것으로 추정)</etc></maintext>' :
        v.name == '대천사의 지팡이' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>80</value><br>마나 <icon>마나</icon> <value>600</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value></stats>'
        +'<br><br><passive>경탄</passive><br><mana>추가 마나의 1%</mana>만큼 <jml>주문력</jml>을 얻습니다.'
        +'<br><br><passive>마나순환</passive><br>지속적으로 마나 충전 중첩을 얻습니다. 대상에게 스킬을 적중시키면 중첩을 하나 소모해 <mana>5의 추가 마나</mana>를 얻습니다. 챔피언 대상으로는 두 배로 적용되며, 최대 <mana>360의 마나</mana>를 얻을 수 있습니다. 추가 마나가 최대치에 도달하면 <passive>대천사의 포옹</passive>으로 변합니다.'
        +'<br><br><rules>8초마다 새로운 <passive>마나 충전</passive> 중첩을 얻습니다. (최대 5)</rules></maintext>' :
        v.name == '내셔의 이빨' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>90</value><br>공격 속도 <icon>공격 속도</icon> <value>50%</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>이케시아의 이빨</passive><br>기본 공격 시 <ap><jml><icon>주문력</icon> 35%</jml>의 마법 피해</ap>(<passive>적중 시</passive> <icon>적중 시</icon>)를 입힙니다. </maintext>' :
        v.name == '리안드리의 고통' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>90</value><br>체력 <icon>체력</icon> <value>300</value></stats>'
        +'<br><br><passive>고통</passive><br>스킬로 피해를 입히면 3초 동안 적을 불태워 매초 <ap>최대 체력의 2%에 해당하는 마법 피해</ap>를 입힙니다.'
        +'<br><br><passive>고난</passive><br>적 챔피언과 전투 중 매초 2%의 추가 피해를 입힙니다. (최대 6%)</maintext>' :
        v.name == '우주의 추진력' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>80</value><br>체력 <icon>체력</icon> <value>250</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value><br>이동 속도 <icon>이동 속도</icon> <value>5%</value></stats>'
        +'<br><br><passive>마법의 춤</passive><br>적 챔피언에게 스킬 피해를 입히면 2초 동안 <speed>이동 속도가 (<passive>25 ~ 60<icon>레벨</icon></passive>) 증가합니다.</speed></maintext>' :
        v.name == '균열 생성기' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>80</value><br>체력 <icon>체력</icon> <value>350</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>공허의 부패</passive><br>적 챔피언과 전투 중 매초 2%의 추가 피해(최대 10%)를 입힙니다. 피해량이 최대가 되면 <hh>(<icon>근거리</icon>10% | <icon>원거리</icon>6%)의 모든 피해 흡혈</hh>을 얻습니다.'
        +'<br><br><passive>공허의 마력</passive><br><chl>추가 체력</chl>의 2%만큼 <jml>주문력</jml>을 얻습니다.</maintext>' :
        v.name == '공허의 지팡이' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>80</value><br>마법 관통력 <icon>마법 관통력</icon> <value>40%</value></stats></maintext>' :
        v.name == '밴시의 장막' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>120</value><br>마법 저항력 <icon>마법 저항력</icon> <value>50</value></stats>'
        +'<br><br><passive>무효화</passive> <icon>쿨다운</icon> (30초)<br>적의 다음 스킬을 막아 주는 주문 방어막을 생성합니다.'
        +'<br><br><rules>챔피언에게 피해를 입으면 아이템 재사용 대기시간이 초기화 됩니다.</rules></maintext>' :
        v.name == '리치베인' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>100</value><br>이동 속도 <icon>이동 속도</icon> <value>8%</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>주문검</passive><br>스킬을 사용하고 나면 다음 기본 공격 시 <ap>(<ggl>기본 <icon>공격력</icon>75%</ggl> <jml>+ <icon>주문력</icon>45%</jml>)의 마법 피해</ap>(<passive>적중 시</passive> <icon>적중 시</icon>)를 추가로 입힙니다.'
        +'<br><br><rules>주문 검을 사용 가능할 때 50%의 공격 속도를 얻습니다.</rules></maintext>' :
        v.name == '그림자불꽃' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>120</value><br>마법 관통력 <icon>마법 관통력</icon> <value>12</value></stats>'
        +'<br><br><passive>잿덩이꽃</passive><br>체력이  35% 이하인 적에게 <ap>마법 피해</ap>와 <true>고정 피해</true>가 치명타로 적용되어 20%의 추가 피해를 입힙니다. 지속 피해 및 소환물 경우 30%의 추가 피해를 입힙니다.'
        +'<br><br><rules>치명타 피해량 관련 능력치는 <passive>잿덩이꽃</passive>의 추가 피해량에만 영향을 줍니다.</rules></maintext>' :
        v.name == '존야의 모래시계' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>120</value><br>방어력 <icon>방어력</icon> <value>50</value></stats>'
        +'<br><br><active>활성화</active> (120초)'
        +'<br><active>시간 정지</active><br>2.5초 동안 <keyword>경직</keyword> 상태가 됩니다.</maintext>' :
        v.name == '라바돈의 죽음모자' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>140</value></stats>'
        +'<br><br><passive>신비한 작품</passive><br>총 <jml>주문력이 35%</jml> 증가합니다.</maintext>' :
        v.name == '지크의 융합' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>200</value><br>마나 <icon>마나</icon> <value>250</value><br>방어력 <icon>방어력</icon> <value>30</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>서리불꽃 폭풍</passive> <icon>쿨다운</icon> (45초)<br>궁극기 사용 시 주변에 5초 동안 폭풍을 소환합니다. 폭풍은 적 챔피언에게 매초 <ap>50의 마법 피해</ap>를 입히고 30% <status>둔화</status>시킵니다.</maintext>' :
        v.name == '얼어붙은 심장' ? v.description = '<maintext><stats>방어력 <icon>방어력</icon> <value>65</value><br>마나 <icon>마나</icon> <value>400</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>혹한의 포옹</passive><br>주변 적의 <ggsd>공격 속도</ggsd>를 20%만큼 감소시킵니다.'
        +'<br><br><passive>견고</passive><br>기본 공격으로 받는 피해량이 최대 (<passive>5</passive> <chl>+ <icon>체력</icon>0.35%</chl>) 감소합니다. 이 수치는 피해량의 20%를 넘을 수 없습니다.</maintext>' :
        v.name == '혹한의 손길' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>400</value><br>마나 <icon>마나</icon> <value>500</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>경탄</passive><br><mana><icon>마나</icon>8%</mana><chl>만큼 체력</chl>을 추가로 얻습니다.'
        +'<br><br><passive>마나순환</passive><br>대상에게 스킬 또는 기본 공격을 적중시키면 중첩을 하나 소모해 <mana>3의 추가 마나</mana>를 얻습니다. 챔피언 대상으로는 두 배로 적용됩니다. 추가 마나가 최대치인 <mana>360</mana>에 도달하면 <passive>종말의 겨울</passive>로 변합니다.'
        +'<br><br><rules>8초마다 새로운 <passive>마나 충전</passive> 중첩을 얻습니다. (최대 4)</rules></maintext>' :
        v.name == '심연의 가면' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>300</value><br>마법 저항력 <icon>마법 저항력</icon> <value>60</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value></stats>'
        +'<br><br><passive>파괴</passive><br>주변 적 챔피언들의 <ap>마법 저항력을 (<passive>5</passive> <chl>+ 추가 체력의 1.2%</chl>)</ap> 감소시킵니다.(최대 25) 영향을 받는 적 하나당 <ap>9의 마법 저항력</ap>을 얻습니다.'
        +'<br><br><rules>챔피언은 한 번에 한 명의 적에게만 영향을 받습니다. (가장 강한 효과 우선)</rules></maintext>' :
        v.name == '증오의 사슬' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>650</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>피의 복수</passive><br>시간이 지남에 따라 <passive>피의 복수</passive> 중첩을 얻으며, 60초 후에 최대 중첩(30)에 도달합니다. <passive>피의 복수</passive> 중첩당 <passive>숙적</passive>으로부터 받는 피해량이 1% 감소합니다. (최대 30%)'
        +'<br><br><passive>복수</passive><br>최대 중첩 시 근처에 있는 <passive>숙적</passive>의 강인함이 20% 감소합니다.'
        +'<br><br><active>활성화</active> (90초)'
        +'<br><active>맹세</active><br><passive>숙적</passive>을 선택하세요.'
        +'<br><br><rules>전장 전체에 사용할 수 있습니다.<br>새로운 대상을 지정하면 <passive>피의 복수</passive>가 초기화됩니다.<br>챔피언과 전투 중일 때는 15초 동안 사용할 수 없습니다.</rules>'
        +'<br><br><etc>"그녀는 그자를 파멸시키는 데 자신의 삶을 바치겠다고 맹세했다..."</etc></maintext>' :
        v.name == '얼어붙은 건틀릿' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>300</value><br>방어력 <icon>방어력</icon> <value>50</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>주문 검</passive><br>스킬을 사용하고 나면 다음 기본 공격 시 추가로 <ggl>기본 <icon>공격력</icon>100%</ggl><ad>의 물리 피해</ad>를 입힙니다. 또한 (<icon>근거리</icon><passive>15%</passive> <chl>+ <icon>체력</icon>0.004%</chl> | <icon>원거리</icon><passive>7.5%</passive> <chl>+ <icon>체력</icon>0.002%</chl>) <status>둔화</status>시키는 서리 영역을 2초 동안 생성합니다.</maintext>' :
        v.name == '가시 갑옷' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>350</value><br>방어력 <icon>방어력</icon> <value>50</value></stats>'
        +'<br><br><passive>가시</passive><br>기본 공격에 맞으면 공격한 적에게 <ap>(<passive>10</passive> <bul>+ 추가 <icon>방어력</icon>25%</bul>)</ap>를 입히고, 대상이 챔피언일 경우 3초 동안 <keyword>40%의 고통스러운 상처</keyword>를 남깁니다.</maintext>' :
        v.name == '란두인의 예언' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>400</value><br>방어력 <icon>방어력</icon> <value>55</value></stats>'
        +'<br><br><passive>견고</passive><br>기본 공격으로 받는 피해량이 최대 (<passive>5</passive> <chl>+ <icon>체력</icon>0.35%</chl>) 감소합니다. 이 수치는 피해량의 20%를 넘을 수 없습니다.'
        +'<br><br><passive>저항</passive><br>치명타로 받는 피해량이 30% 감소합니다.'
        +'<br><br><active>활성화</active> (60초)'
        +'<br><active>억제</active><br>주변 적들에게 2초 동안 55%의 <status>둔화</status> 효과를 적용합니다.</maintext>' :
        v.name == '태양불꽃 방패' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>500</value><br>방어력 <icon>방어력</icon> <value>50</value></stats>'
        +'<br><br><passive>불사르기</passive><br>피해를 받거나 입히면 주변 적들에게 3초 동안 초당 <ap>(<passive>15</passive> <chl>+ 추가 <icon>체력</icon>1.75%</chl>)의 마법 피해</ap>를 입힙니다. (미니언 대상 25%) 챔피언이나 에픽 정글 몬스터에게 이 효과로 피해를 입히면 중첩이 1회 쌓여 다음 <passive>불사르기</passive> 피해량이 5초 동안 10% 증가합니다. (최대 6회 중첩)</maintext>' :
        v.name == '끝없는 절망' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>400</value><br>방어력 <icon>방어력</icon> <value>55</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value></stats>'
        +'<br><br><passive>고뇌</passive><br>챔피언과 전투 중일 때 7초마다 주변 적 챔피언에게 <ap>(<chl>추가 <icon>체력</icon>3%</chl> <passive>+30 ~ 50<icon>레벨</icon></passive>)의 마법 피해</ap>를 입히고 피해량의 250%만큼 체력을 회복합니다.</maintext>' :
        v.name == '대자연의 힘' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>400</value><br>마법 저항력 <icon>마법 저항력</icon> <value>55</value><br>이동 속도 <icon>이동 속도</icon> <value>5%</value></stats>'
        +'<br><br><passive>굳건함</passive><br>챔피언에게 <ap>마법 피해</ap>를 받으면 중첩을 얻습니다. 최대 8회까지 중첩됩니다. <passive>굳건함</passive>이 8회 중첩되면 <ap>70의 마법 저항력</ap> 및 <speed>10%의 추가 이동 속도</speed>를 얻습니다.'
        +'<br><br><rules><status>이동 불가</status> 효과를 받으면 추가 중첩을 2회 얻습니다.<br><passive>굳건함</passive> 중첩이 7초 후에 사라집니다.</rules></maintext>' :
        v.name == '공허한 광휘' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>600</value><br>마법 저항력 <icon>마법 저항력</icon> <value>40</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>100%</value></stats>'
        +'<br><br><passive>불사르기</passive><br>피해를 받거나 입히면 주변 적들에게 3초 동안 초당 <ap>(<passive>10</passive> <chl>+ 추가 <icon>체력</icon>1.75%</chl>)의 마법 피해</ap>를 입힙니다. (미니언 대상 25% 증가)'
        +'<br><br><passive>황폐</passive><br>적을 처치하면 주변에 <ap>(<passive>20</passive> <chl>+ 추가 <icon>체력</icon>3.5%</chl>)의 마법 피해</ap>를 입힙니다.'
        +'<br><br><etc>재창조된 이케시아의 유물입니다.</etc></maintext>' :
        v.name == '정령의 형상' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>450</value><br>마법 저항력 <icon>마법 저항력</icon> <value>60</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>100%</value></stats>'
        +'<br><br><passive>무한한 활력</passive><br>자신이 받는 모든 체력 회복 및 보호막 효과각 25% 증가합니다.</maintext>' :
        v.name == '케이닉 루컨' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>400</value><br>마법 저항력 <icon>마법 저항력</icon> <value>80</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>150%</value></stats>'
        +'<br><br><passive>마법사의 파멸</passive><br>15초 동안 <ap>마법 피해</ap>를 받지 않으면 <chl><icon>체력</icon>18%</chl><ap>의 마법 피해를 흡수하는 보호막</ap>을 얻습니다.'
        +'<br><br><etc>"운명은 간계와 땀, 강철로 빛어지지, 마법은 더 이상 이 원칙을 깰 수 없어."</etc></maintext>' :
        v.name == '망자의 갑옷' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>300</value><br>방어력 <icon>방어력</icon> <value>45</value><br>이동 속도 <icon>이동 속도</icon> <value>5%</value></stats>'
        +'<br><br><passive>침몰시키는 자</passive><br>이동 시 최대 <speed>40의 추가 이동 속도</speed>를 얻습니다. 다음 기본 공격 시 최대 <ad>(<ggl>기본 <icon>공격력</icon>100%</ggl> <passive>+40</passive>)의 물리 피해</ad>를 입히고 추가 이동 속도를 잃습니다.'
        +'<br><br><passive>굴하지 않는 자</passive><br>이동 속도 둔화 효과가 25% 줄어듭니다.'
        +'<br><br><etc>"내 갑옷을 뺏을 방도는 하나뿐이다..."- 무명씨</etc></maintext>' :
        v.name == '강철심장' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>900</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>200%</value></stats>'
        +'<br><br><passive>거인의 흡수</passive> 대상별: <icon>쿨다운</icon> (30초)<br>700의 사거리 내에 있는 챔피언을 상대로 3초 동안 강력한 공격을 충전합니다. 충전된 공격을 대상에 <ad>(<passive>80</passive> <chl>+ 아이템 체력의 12%</chl>)에 해당하는 추가 물리 피해</ad>를 입히고 그 피해의 12%만큼 <chl>영구 최대 체력</chl>을 부여합니다.'
        +'<br><br><passive>거인</passive><br><chl>최대 체력 1000</chl>당 크기가 3% 증가합니다. (최대 30%)</maintext>' :
        v.name == '워모그의 갑옷' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>750</value><br>이동 속도 <icon>이동 속도</icon> <value>5%</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>200%</value></stats>'
        +'<br><br><passive>워모그의 심장</passive><br>추가 체력이 1300 이상일 때, 6초 동안 피해를 입지 않으면 초당 <hb><chl><icon>체력</icon>3%</chl>의 체력</hb>을 회복하고 <speed>이동 속도가 10%</speed> 증가합니다. (챔피언이 아닌 대상에게는 3초)</maintext>' :
        v.name == '해신 작쇼' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>300</value><br>방어력 <icon>방어력</icon> <value>50</value><br>마법 저항력 <icon>마법 저항력</icon> <value>50</value></stats>'
        +'<br><br><passive>공허 태생의 저항력</passive><br>챔피언과 5초 이상 전투를 벌이면 강화되어 전투가 끝날 때까지 추가 <bul>방어력</bul> 및 <ap>마법 저항력</ap>이 30% 증가합니다.'
        +'<br><br><etc>"그는 많은 이름으로 불렸지. 갑각 투구. 두 번째 피부. 살아 있는 무덤..."</etc></maintext>' :
        v.name == '자자크의 세계가시' ? v.description = '<maintext><rules><num>서폿터 퀘스트</num>를 완료한 후에만 구매할 수 있습니다.</rules><br><br><stats>10초당 골드 <icon>골드</icon> <value>5</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>75%</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <vlaue>75%</vlaue><br>체력 <icon>체력</icon> <value>200</value></stats>'
        +'<br><br><passive>공허 폭팔</passive> <icon>쿨다운</icon> (<passive>8 ~ 6<icon>레벨</icon></passive>)<br>챔피언에게 스킬로 피해를 입히면 폭팔이 일어나 대상과 주변 적들에게 <ap>(<passive>20</passive> <jml>+ <icon>주문력</icon>20%</jml>)+최대 체력의 4%에 해당하는 마법 피해</ap>를 입힙니다.'
        +'<br><br><icon>사용 시</icon> <active>활성화</active><br><active>와드</active><br>시야를 밝히는 <keyword>투명</keyword> 와드를 설치합니다. 투명 와드는 4개 보유할 수 있으며 상점 방문 시 다시 채워집니다.'
        +'<br><br><rules>이 아이템을 보유한 아군이 너무 많은 미니언을 처치하면 미니언 처치 시 획득하는 골드가 감소합니다.</rules>'
        +'<br><br><etc>아주 용감하거나 어리석은 자만이 공허를 적을 돌립니다. 다행이 자자크는 둘 모두에 해당됐죠.</etc></maintext>' :
        v.name == '피의 노래' ? v.description = '<maintext><rules><num>서폿터 퀘스트</num>를 완료한 후에만 구매할 수 있습니다.</rules><br><br><stats>10초당 골드 <icon>골드</icon> <value>5</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>75%</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <vlaue>75%</vlaue><br>체력 <icon>체력</icon> <value>200</value></stats>'
        +'<br><br><passive>주문 검</passive><br>스킬을 사용하고 나면 다음 기본 공격 시 <ggl>기본 <icon>공격력</icon>150%</ggl><ad>의 물리 피해</ad>(<passive>적중 시</passive> <icon>적중 시</icon>)를 추가로 입힙니다. 대상이 챔피언일 경우 6초 동안 받는 피해량을 <icon>근거리</icon> 근접 챔피언의 경우 10%, <icon>원거리</icon> 원거리 챔피언의 경우 5% 증가시킵니다.'
        +'<br><br><icon>사용 시</icon> <active>활성화</active><br><active>와드</active><br>시야를 밝히는 <keyword>투명</keyword> 와드를 설치합니다. 투명 와드는 4개 보유할 수 있으며 상점 방문 시 다시 채워집니다.'
        +'<br><br><rules>이 아이템을 보유한 아군이 너무 많은 미니언을 처치하면 미니언 처치 시 획득하는 골드가 감소합니다.</rules>'
        +'<br><br><etc>"아, 관중의 함성... 그리고 모래의 묻는 피."</etc></maintext>' :
        v.name == '태양의 썰매' ? v.description = '<maintext><rules><num>서폿터 퀘스트</num>를 완료한 후에만 구매할 수 있습니다.</rules><br><br><stats>10초당 골드 <icon>골드</icon> <value>5</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>75%</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <vlaue>75%</vlaue><br>체력 <icon>체력</icon> <value>200</value></stats>'
        +'<br><br><passive>썰매 질주</passive> <icon>쿨다운</icon> (30초)<br>아군 근처에서 적 챔피언을 <status>둔화</status> 또는 <status>이동 불가</status> 상태로 만들면 <hb>(<passive>50 ~ 230<icon>레벨</icon></passive>)의 체력</hb>을 회복하고 자신과 체력이 가장 낮은 주변 아군이 2.5초 동안 <speed>이동 속도가 20% 증가했다가 점차 감고</speed>합니다.'
        +'<br><br><icon>사용 시</icon> <active>활성화</active><br><active>와드</active><br>시야를 밝히는 <keyword>투명</keyword> 와드를 설치합니다. 투명 와드는 4개 보유할 수 있으며 상점 방문 시 다시 채워집니다.'
        +'<br><br><rules>이 아이템을 보유한 아군이 너무 많은 미니언을 처치하면 미니언 처치 시 획득하는 골드가 감소합니다.</rules>'
        +'<br><br><etc>"뭐 해, 썰매 타러 가자!"</etc></maintext>' :
        v.name == '꿈 생성기' ? v.description = '<maintext><rules><num>서폿터 퀘스트</num>를 완료한 후에만 구매할 수 있습니다.</rules><br><br><stats>10초당 골드 <icon>골드</icon> <value>5</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>75%</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <vlaue>75%</vlaue><br>체력 <icon>체력</icon> <value>200</value></stats>'
        +'<br><br><passive>꿈 생성기</passive> <icon>쿨다운</icon> (8초)<br>다른 아군에게 체력을 회복시키거나 보호막을 씌우면 꿈방울을 불어 대상을 3초 동안 강화합니다. 해당 아군이 받는 다음 피해가 (<passive>75 ~ 225<icon>레벨</icon></passive>) 감소하고 가하는 다음 공격이 <ap>(<passive>50 ~ 170<icon>레벨</icon></passive>)의 마법 피해</ap>를 추가로 입힙니다.'
        +'<br><br><icon>사용 시</icon> <active>활성화</active><br><active>와드</active><br>시야를 밝히는 <keyword>투명</keyword> 와드를 설치합니다. 투명 와드는 4개 보유할 수 있으며 상점 방문 시 다시 채워집니다.'
        +'<br><br><rules>이 아이템을 보유한 아군이 너무 많은 미니언을 처치하면 미니언 처치 시 획득하는 골드가 감소합니다.</rules>'
        +'<br><br><etc>잠자리에 함께할 밴들 시티의 친구입니다.</etc></maintext>' :
        v.name == '천상의 이의' ? v.description = '<maintext><stats>10초당 골드 <icon>골드</icon> <value>5</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>75%</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <vlaue>75%</vlaue><br>체력 <icon>체력</icon> <value>200</value></stats>'
        +'<br><br><passive>산의 축복</passive> <icon>쿨다운</icon> (18초)<br>챔피언에게 피해를 받은 후 <num>2</num>초 동안 챔피언으로부터 받는 피해가 <icon>근거리</icon> 근접 챔피언의 경우 <num>35%</num>, <icon>원거리</icon> 챔피언의 경우 <num>25%</num> 감소합니다. 효과가 끝나면 2초 동안 주변 적을 60% <status>둔화</status>시킵니다.'
        +'<br><br><icon>사용 시</icon> <active>활성화</active><br><active>와드</active><br>시야를 밝히는 <keyword>투명</keyword> 와드를 설치합니다. 투명 와드는 4개 보유할 수 있으며 상점 방문 시 다시 채워집니다.'
        +'<br><br><rules>이 아이템을 보유한 아군이 너무 많은 미니언을 처치하면 미니언 처치 시 획득하는 골드가 감소합니다.<br>챔피언에게 피해를 입으면 아이템 재사용 대기시간이 초기화 됩니다.</rules>'
        +'<br><br><etc>감히 산을 오를 용기 있는 자를 위한 것입니다.</etc></maintext>' :
        v.name == '슈렐리아의 군가' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>55</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value><br>이동 속도 <icon>이동 속도</icon> <value>8%</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>125%</value></stats>'
        +'<br><br><active>활성화</active> (75초)'
        +'<br><active>고무적인 연설</active><br>주변 아군의 <speed>이동 속도를 4초 동안 30%</speed> 상승시킵니다.</maintext>' :
        v.name == '헬리아의 메아리' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>40</value><br>체력 <icon>체력</icon> <value>200</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>125%</value></stats>'
        +'<br><br><passive>영혼 흡수</passive><br>챔피언에게 피해르 입히면 <passive>영혼 파편</passive>을 최대 3개 까지 얻습니다. 아군을 상대로 체력을 회복시키거나 보호막을 씌우면 모든 <passive>영혼 파편</passive>을 소모하여 <hb>체력을 40</hb> 회복하고 가장 가까운 적 챔피언에게 파편 하나당 <ap>45의 마법 피해</ap>를 입힙니다.'
        +"<br><br><etc>'가만히 귀를 기울이면 비명 너머로 부산한 도시의 소리가 여전히 들려옵니다.'</etc></maintext>" :
        v.name == '월석 재생기' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>30</value><br>체력 <icon>체력</icon> <value>250</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>125%</value></stats>'
        +'<br><br><passive>별빛 은총</passive><br>아군을 상대로 체력을 회복시키거나 보호막을 씌우면 (자신을 제외하고) 가장 가까이 있는 아군 챔피언에게 연쇄 효과가 적용되며 기존 수치의 <hb>40%</hb>만큼 체력을 회복시키거나 <ap>45%</ap>만큼 피해를 흡수하는 보호막을 부여합니다.'
        +'<br><br><rules>근처에 아군이 없으면 같은 대상을 상대로 기존 수치에 <hb>30%</hb>만큼 회복시키거나 <ap>35%</ap>만큼 피해를 흡수하는 보호막을 부여합니다.</rules></maintext>' :
        v.name == '기사의 맹세' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>300</value><br>방어력 <icon>방어력</icon> <value>45</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>희생</passive><br><passive>보호</passive> 중인 아군 근처에 있으면 해당 아군이 입는 피해량의 10%를 대신 입고 해당 아군이 챔피언에게 입히는 피해량의 10%만큼 체력을 <hb>회복</hb>합니다. 해당 아군의 체력이 30% 아래라면 피해량 감소 효과가 <passive>20%</passive>로 증가합니다.'
        +'<br><br><active>활성화</active> (60초)<br><active>맹세</active><br><passive>보호</passive>할 아군을 대상을 지정합니다.</maintext>' :
        v.name == '강철의 솔라리 펜던트' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>200</value><br>방어력 <icon>방어력</icon> <value>30</value><br>마법 저항력 <icon>마법 저항력</icon> <value>30</value><br>스킬 가속 <icon>스킬 가속</icon> <value>10</value></stats>'
        +'<br><br><active>활성화</active> (90초)<br><active>헌신</active><br>주변 아군들에게 <ap>200~360(<passive>아군 <icon>레벨</icon></passive>)의 피해르 흡수하는 보호막</ap>을 부여합니다. 보호막 피해 흡수량은 2.5초에 걸쳐 점차 감소합니다.'
        +'<br><br><rules>레벨 비례 효과는 아군의 레벨에 따라 상승합니다.<br>20초 안에 <active>헌신</active> 보호막을 연속을 사용하면 25%의 효과만 적용됩니다.</rules></maintext>' :
        v.name == '제국의 명령' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>60</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>125%</value></stats>'
        +'<br><br><passive>합동 공격</passive> 대상별: <icon>쿨다운</icon> (9초)<br>적 챔피언을 <keyword>둔화</keyword> 또는 <keyword>이동 불가</keyword> 상태로 만들면 5초 동안 표식을 남깁니다. 아군 챔피언이 대상에게 피해를 입히면 표식이 폭팔하며 <ap>현재 체력의 12%에 해당하는 마법 피해</ap>를 입히고 2초 동안 자신과 아군의 <speed>이동 속도가 25%</speed> 상승합니다.</maintext>' :
        v.name == '불타는 향로' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>50</value><br>체력 회복 및 보호막 <icon>체력 회복 및 보호막</icon> <value>8%</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>125%</value><br>이동 속도 <icon>이동 속도</icon> <value>8%</value></stats>'
        +'<br><br><passive>축성</passive><br>아군을 치유하거나 보호막을 씌워주면 6초 동안 자신과 대상 아군의 공격 속도가 <ggsd>25%</ggsd> 상승하고 공격 시 <ap>20의 마법 피해</ap>(<passive>적중 시</passive> <icon>적중 시</icon>)를 입힙니다.</maintext>' :
        v.name == '흐르는 물의 지팡이' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>40</value><br>체력 회복 및 보호막 <icon>체력 회복 및 보호막</icon> <value>8%</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>125%</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>급류</passive><br>아군의 체력을 회복시키거나 보호막을 씌우면 4초 동안 자신과 대상의 <jml>주문력이 30</jml>, <speed>이동 속도가 10%</speed> 증가합니다.</maintext>' :
        v.name == '구원' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>200</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>100%</value><br>체력 회복 및 보호막 <icon>체력 회복 및 보호막</icon> <value>15%</value></stats>'
        +'<br><br><active>활성화</active> (90초)<br><active>중재</active><br>위치를 지정합니다. 2.5초 후 대상 범위 안에 있는 아군 챔피언의 <hb>체력을 200~400(<passive>아군  <icon>레벨</icon></passive>)</hb>만큼 회복 시키고 적 챔피언에게 <true>최대 체력의 10%의 해당하는 고정 피해</true>를 입힙니다.'
        +'<br><br><rules>죽은 상태로도 사용할 수 있습니다.<br><active>중재</active>를 대상에게 연속으로 적용하면 효과가 50% 감소합니다.<br>레벨 비례 효과는 아군의 레벨에 따라 상승합니다.</rules></maintext>' :
        v.name == '미카엘의 축복' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>250</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>100%</value><br>체력 회복 및 보호막 <icon>체력 회복 및 보호막</icon> <value>12%</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><active>활성화</active> (120초)<br><active>정화</active><br>아군 챔피언에게 걸린 모든 군중 제어 효과(<keyword>공중에 뜸</keyword> 및 <keyword>제압</keyword> 제외)를 제거하고 <hb>체력을 100~250(<passive>아군 <icon>레벨</icon></passive>) 회복합니다.</hb>' :
        v.name == '경계의 와드석' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>250</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value><br>방어력 <icon>방어력</icon> <value>25</value><br>마법 저항력 <icon>마법 저항력</icon> <value>25</value></stats>'
        +'<br><br><passive>신비로운 상자</passive><br>이 아이템은 구매한 제어 와드를 3개까지 저장할 수 있습니다.'
        +'<br><br><passive>주시</passive><br>투명 와드 및 제어 와드 설치 개수가 1 증가합니다</maintext>' :
        v.name == '개척자' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>200</value><br>방어력 <icon>방어력</icon> <value>40</value><br>이동 속도 <icon>이동 속도</icon> <value>5%</value></stats>'
        +'<br><br><passive>진두지휘</passive><br>이동 시 <speed>20의 추가 이동 속도</speed>를 얻습니다. 최대 이동 속도일 때 아군 챔피언의 <speed>이동 속도를 자신 이동 속도의 15%</speed>만큼 증가시키는 자취를 남깁니다. 다음 기본 공격 시 추가 <speed>이동 속도</speed>를 잃으며, 추가로 <icon>근거리</icon> 근접 챔피언의 경우 대상을 1초 동안 50% <status>둔화</status>시킵니다.'
        +'<br><br><etc>자신의 길을 스스로 개척하세요.</etc></maintext>' :
        v.name == '새벽심장' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>40</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>150%</value></stats>'
        +'<br><br><passive>태초의 빛</passive><br><mana>기본 마나 재생 100%당</mana> <hb>체력 회복 및 보호막 효과가 3%</hb>, <jml>주문력이 5</jml> 증가합니다.'
        +'<br><br><passive>광휘</passive><br>소환사 주문 가속이 18 증가합니다.'
        +'<br><br><etc>이 세상의 모든 힘은 별에서 왔다고 합니다.</etc></maintext>' :

        v.name == '체력 물약' ? v.description = '<maintext><active>사용시 - 소모:</active> 15초에 걸쳐 <hb>120의 체력</hb>을 회복합니다.<br><br><rules>최대로 보유할 수 있는 체력 물약 수는 5개입니다.</rules></maintext>' :
        v.name == '충전형 물약' ? v.description = '<maintext><active>사용 시 - 소모:</active> 충전량을 1회 소모해 12초 동안 <hb>100의 체력</hb>을 회복합니다. 충전량은  최대 2회이며 상점 방문 시 다시 채워집니다.</maintext>' :
        v.name == '부패 물약' ? v.description = '<maintext><active>사용 시 - 소모:</active> 충전량을 1회 소모해 12초 동안 <hb>100의 체력</hb>과 <mana>75의 마나</mana>를 회복합니다. 회복하는 동안 적 챔피언에게 기본 공격 및 스킬 사용 시 적을 불태워 3초 동안 <ap>15(마나를 회복할 수 없을 때에는 20)의 마법 피해</ap>를 입힙니다. 충전량은 최대 3회이며 상점 방문 시 다시 채워집니다.'
        +'<br><br><rules>광역 또는 지속 피해로 발동된 부패 피해는 피해량이 50%로 감소됩니다.</rules></maintext>' :
        v.name == '투명 와드' ? v.description = '<maintext><active><icon>사용 시</icon> 사용 시 - 장신구:</active> 아군 모두에게 <passive>90~120</passive>초 동안 주변 지역을 밝혀 주는 <keyword>투명</keyword> 와드 하나를 지면에 설치합니다. 투명 와드는 최대 2개까지 보유할 수 있으며 <passive>210~120초 마다 하나씩 생성됩니다.</passive></maintext>' :
        v.name == '예언자의 렌즈' ? v.description = '<maintext><active><icon>사용 시</icon> 사용 시 - 장신구:</active> 6초 동안 <passive>600~750</passive>의 반경에서 근처를 수색해 적 유닛이 숨어 있으면 경고를 보내며 주변의 투명한 덫을 드러냅니다. 또한 적의 투명 와드를 드러내고 잠시 무력화시킵니다. 탐지 드론을 최대 2개까지 보유하며 <passive>160~100</passive>초마다 하나씩 새 드론을 생성할 수 있습니다.</maintext>' :
        v.name == '망원형 개조' ? v.description = '<maintext><rules>구매하려면 9레벨이어야 합니다.</rules><br><br><active><icon>사용 시</icon> 사용 시 - 장신구:</active> 먼 곳에 누구나 볼 수 있고 쉽게 파괴 가능한 와드를 설치해 지형과 수풀의 시야를 확보합니다. 설치하고 처음으로 적 챔피언을 발견하면 2초 동안 더 넓은 범위의 시야를 밝힌 후 파괴됩니다. 아군이 소환사 주문이나 스킬의 대상으로 지정할 수 없으며. <passive>198~99</passive>초마다 생성됩니다</maintext>' :
        v.name == '제어 와드' ? v.description = '<maintext><active><icon>사용 시</icon> 사용 시 - 장신구:</active> 주변 지역을 드러내 주는 강력한 제어 와드를 설치합니다. 근처의 <keyword>투명</keyword>한 덫과 <keyword>위장</keyword> 중인 적을 드러내고 적의 투명 와드를 감지해 무력화합니다.'
        +'<br><br><rules>최대 2개의 제어 와드를 소지할 수 있습니다. 제어 와드로 다른 제어 와드를 무력화시킬 수 없습니다.</rules></maintext>' :
        v.name == '마법의 영약' ? v.description = '<maintext><rules>구매하려면 9레벨이어야 합니다.</rules><br><br><active>사용 시 - 소모:</active> 3분 동안 <jml>주문력이 50</jml>, <mana>마나 재생력이 15%</mana>증가합니다. 활성화된 동안 챔피언이나 포탑에 피해를 입히면 <true>25의 추가 고정 피해</true>를 입힙니다. (5초)'
        +'<br><br><rules>마법의 영약 고정 피해 효과는 포탑을 공격할 때 재사용 대기시간이 없습니다. 다른 종류의 영약을 마시면 기존 영약의 효과가 사라집니다.</rules></maintext>' :
        v.name == '분노의 영약' ? v.description = '<maintext><rules>구매하려면 9레벨이어야 합니다.</rules><br><br><active>사용 시 - 소모:</active> 3분 동안 <ggl>공격력이 30</ggl>, 챔피언 대상 <hh>물리 피해 흡혈이 12%</hh>증가합니다.'
        +'<br><br><rules>다른 종류의 영약을 마시면 기존 영약의 효과가 사라집니다.</rules></maintext>' :
        v.name == '강철의 영약' ? v.description = '<maintext><rules>구매하려면 9레벨이어야 합니다.</rules><br><br><active>사용 시 - 소모:</active> 3분 동안 <chl>체력이 300</chl>, 강인함이 25% 증가하고, 챔피언이 거대해집니다. 이 효과가 활성화된 동안 이동하면 길이 생겨 그 위의 아군 챔피언들은 <speed>이동 속도가 15%</speed> 상승합니다.'
        +'<br><br><rules>다른 종류의 영약을 마시면 기존 영약의 효과가 사라집니다.</rules></maintext>' :

        v.name == '무라마나' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>35</value><br>마나 <icon>마나</icon> <value>860</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>경탄</passive><br><ggl>(<mana><icon>마나</icon>2.5%</mana>)의 추가 공격력</ggl>을 얻습니다.'
        +'<br><br><passive>충격</passive><br>챔피언에게 기본 공격 시 <mana><icon>마나</icon>1.5%</mana><ad>의 물리피해</ad>(<passive>적중 시</passive> <icon>적중 시</icon>)를 추가로 입힙니다. 스킬로 침피언에게 피해를 입히면 <ad>(<icon>근거리</icon><mana><icon>마나</icon>3.5%</mana> <ggl>+<icon>공격력</icon>6%</ggl> | <icon>원거리</icon><mana><icon>마나</icon>2.7%</mana> <ggl>+<icon>공격력</icon>6%</ggl>)의 물리 피해</ad>를 추가로 입힙니다.</maintext>' :
        v.name == '대천사의 포옹' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>80</value><br>마나 <icon>마나</icon> <value>1000</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value></stats>'
        +'<br><br><passive>경탄</passive><br><mana>추가 마나의 2%</mana>만큼 <jml>주문력</jml>을 얻습니다.'
        +'<br><br><passive>생명선</passive> <icon>쿨다운</icon> (90초)<br>체력이 30% 밑으로 떨어질 만큼 피해를 입으면 3초 동안 <ap>250+현재 마나의 20%에 해당하는 피해를 흡수하는 보호막</ap>을 얻습니다.</maintext>' :
        v.name == '종말의 겨울' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>400</value><br>마나 <icon>마나</icon> <value>860</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats>'
        +'<br><br><passive>경탄</passive><br><mana><icon>마나</icon>8%</mana><chl>만큼 체력</chl>을 추가로 얻습니다.'
        +'<br><br><passive>불변</passive> <icon>쿨다운</icon> (8초)<br>적 챔피언을 <status>이동 불가</status> 또는 <status>둔화</status> (<icon>근거리</icon> 근접 챔피언 전용) 상태로 만들면 3초 동안 <mana>(<passive>100 ~ 180<icon>레벨</icon></passive>)+현재 마나의 4.5%</mana>에 해당하는 피해를 흡수하는 보호막을 얻습니다. 근처에 적이 둘 이상 있으면 보호막의 피해 흡수량이 <passive>80%</passive> 증가합니다.</maintext>' :
        
        v.name == '업그레이드 비행팩' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>95</value><br>체력 <icon>체력</icon> <value>450</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><active>활성화</active> (40초)'
        +'<br><active>초음속</active><br>지정 방향으로 돌진하며 부채꼴 모양으로 <ap>(<passive>100</passive> <jml>+ <icon>주문력</icon>10%</jml>)의 마법 피해</ap>를 입히는 마법 탄환을 발사합니다.'
        +'<br><br><rules>초음속 돌진으로 지형을 통과할 수 없습니다.</rules>'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '선풍검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>70</value><br>물리 관통력 <icon>물리 관통력</icon> <value>27</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>전류 자극</passive><br>돌진 및 은신이 <keyword>충전 상태</keyword> 중첩을 75% 더 빨리 쌓이게 합니다.'
        +'<br><br><passive>창공</passive><br><keyword>충전 상태로 기본 공격</keyword> 시 적에게 <ad>100의 추가 물리 피해</ad>를 입히고, 0.75초 동안 (<icon>근거리</icon>99% | <icon>원거리</icon>20%) <status>둔화</status>시킵니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '확실성' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>70</value><br>물리 관통력 <icon>물리 관통력</icon> <value>27</value><br>이동 속도 <icon>이동 속도</icon> <value>8%</value></stats>'
        +'<br><br><passive>준비</passive><br>8초 동안 챔피언과 전투를 벌이지 않으면 <mrgtl>물리 관통력이 (<passive>5 ~ 10<icon>레벨</icon></passive>)</mrgtl> 증가합니다. 이 물리 관통력 증가 효과는 챔피언에게 피해를 입힐 경우 3초 후에 사라집니다.'
        +'<br><br><passive>탈출</passive><br>피해를 입힌 챔피언이 3초 안에 죽으면 1.5초 동안 <speed>이동 속도가 150 증가했다가 점차 감소</speed>합니다.'
        +'<br><br><etc>때로는 직접 만들어야 할 때로 있죠...</etc>'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '요우무의 각성' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>75</value><br>물리 관통력 <icon>물리 관통력</icon> <value>26</value></stats>'
        +'<br><br><passive>출몰</passive><br>전투에서 벗어나 있을 떄 <speed>이동 속도가 (<icon>근거리</icon>40 | <icon>원거리</icon>20)</speed> 상승합니다.'
        +'<br><br><active>활성화</active> (45초)'
        +'<br><active>망령의 발걸음</active><br>6초 동안 <speed>이동 속도가 (<icon>근거리</icon>20% | <icon>원거리</icon>15%)</speed> 상승하고 <keyword>유체화</keyword> 상태가 됩니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '영혼의 평정' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>75</value><br>물리 관통력 <icon>물리 관통력</icon> <value>27</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>명성</passive><br>자신이 피해를 입힌 챔피언이 3초 안에 죽으면 90초 동안 <ggl>15+처치한 챔피언 하나당 2의 공격력</ggl>이 증가합니다.'
        +'<br><br><etc>처치한 챔피언:(이곳엔 처치한 챔피언 수가 표시됩니다)</etc>'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '리안드리의 슬픔' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>110</value><br>체력 <icon>체력</icon> <value>550</value></stats>'
        +'<br><br><passive>고통</passive><br>스킬로 피해를 입히면 3초 동안 적을 불태워 매초 <ap>최대 체력의 2%에 해당하는 마법 피해</ap>를 입힙니다.'
        +'<br><br><passive>고난</passive><br>적 챔피언과 전투 중 매초 2%의 추가 피해를 입힙니다. (최대 6%)'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '레비아탄' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>1150</value><br>기본 체력 재생 <icon>기본 체력 재생</icon> <value>300%</value></stats>'
        +'<br><br><passive>거인의 흡수</passive> 대상별: <icon>쿨다운</icon> (30초)<br>700의 사거리 내에 있는 챔피언을 상대로 3초 동안 강력한 공격을 충전합니다. 충전된 공격을 대상에 <ad>(<passive>80</passive> <chl>+ 아이템 체력의 12%</chl>)에 해당하는 추가 물리 피해</ad>를 입히고 그 피해의 12%만큼 <chl>영구 최대 체력</chl>을 부여합니다.'
        +'<br><br><passive>거인</passive><br><chl>최대 체력 1000</chl>당 크기가 3% 증가합니다. (최대 30%)'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '들끓는 슬픔' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>35</value><br>주문력 <icon>주문력</icon> <value>35</value><br>공격 속도 <icon>공격 속도</icon> <value>25%</value></stats>'
        +'<br><br><passive>분노</passive><br>기본 공격 시 <ap>30의 마법 피해</ap>(<passive>적중 시</passive> <icon>적중 시</icon>)를 입힙니다.'
        +'<br><br><passive>들끓는 일격</passive><br>기본 공격 시 <ggsd>공격 속도가 8%</ggsd> 증가합니다. 해당 효과는 4번까지 중첩되어 최대 <ggsd>공격 속도가 32%</ggsd>까지 증가합니다. 최대 중첩 시 세 번째 기본 공격을 가할 때마다 <passive>적중 시</passive> <icon>적중 시</icon> 효과를 두 번씩 적용합니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        //터보 추진기 직접 오른으로 찾아야함 ㅅㅂ
        v.name == '흑요석 양날 도끼' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>65</value><br>체력 <icon>체력</icon> <value>600</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value></stats>'
        +'<br><br><passive>깎아내기</passive><br>챔피언에게 <ad>물리 피해</ad>를 가하면 6초 동안 <bul>방어력을 5% 감소</bul>시키는 중첩을 1회 적용합니다. (최대 <bul>방어력 25% 감소</bul>)'
        +'<br><br><passive>열정</passive><br><ad>물리 피해</ad>를 입히면 2초 동안 <speed>20의 이동 속도</speed>를 얻습니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '쓰러진 용의 제물' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>60</value><br>공격 속도 <icon>공격 속도</icon> <value>45%</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value></stats>'
        +'<br><br><passive>벼락</passive><br>세 번째 기본 공격마다 <ad>(<passive>140 ~ 310<icon>레벨</icon></passive>)의 물리 피해</ad>(<passive>적중 시</passive> <icon>적중 시</icon>)를 입힙니다. 6초 안에 같은 대상을 맞히면 피해량 50% 증가하며 최대 100%(<passive>280 ~ 620<icon>레벨</icon>)까지 증가합니다.</passive>)'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '남작의 선물' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>120</value><br>공격 속도 <icon>공격 속도</icon> <value>60%</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>이케시아의 이빨</passive><br>기본 공격 시 <ap><jml><icon>주문력</icon> 35%</jml>의 마법 피해</ap>(<passive>적중 시</passive> <icon>적중 시</icon>)를 입힙니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '이케시아의 저주' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>90</value><br>체력 <icon>체력</icon> <value>450</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>공허의 부패</passive><br>적 챔피언과 전투 중 매초 2%의 추가 피해(최대 10%)를 입힙니다. 피해량이 최대가 되면 <hh>(<icon>근거리</icon>10% | <icon>원거리</icon>6%)의 모든 피해 흡혈</hh>을 얻습니다.'
        +'<br><br><passive>공허의 마력</passive><br><chl>추가 체력</chl>의 2%만큼 <jml>주문력</jml>을 얻습니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '쇼진의 결의' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>65</value><br>체력 <icon>체력</icon> <value>500</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value></stats>'
        +'<br><br><passive>드래곤의 힘</passive><br>일반 스킬의 스킬 가속이 15 증가합니다.'
        +'<br><br><passive>집중된 의지</passive><br>6초 동안 스킬 적중 시 중첩을 얻으며, 최대 4회까지 중첩됩니다. 중첩당 스킬 피해량이 (<icon>근거리</icon><passive>3%</passive> | <icon>원거리</icon><passive>2%</passive>) 증가합니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '천상의 몰락' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>60</value><br>체력 <icon>체력</icon> <value>600</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>라이트실드 타격</passive> 대상별: <icon>쿨다운</icon> (6초)'
        +'<br>챔피언에게 처음 기본 공격을 가할 때 치명타로 적용되고 잃은 체력의 <hb>(<icon>근거리</icon><ggl>기본 <icon>공격력 </icon>140%</ggl> | <icon>원거리</icon><ggl>기본 <icon>공격력 </icon>70%</ggl>)에 해당하는 체력을 회복</hb>합니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '폭풍의 눈' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>80</value><br>공격 속도 <icon>공격 속도</icon> <value>25%</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value></stats>'
        +'<br><br><passive>번개</passive><br><keyword>충전 상태로 기본 공격</keyword> 시 <ap>100의 추가 마법 피해</ap>를 입히고 1.5초 동안 <speed>이동 속도가 45% </speed>증가합니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '무언의 기생갑' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>550</value><br>방어력 <icon>방어력</icon> <value>60</value><br>마법 저항력 <icon>마법 저항력</icon> <value>60</value></stats>'
        +'<br><br><passive>공허 태생의 저항력</passive><br>챔피언과 5초 이상 전투를 벌이면 강화되어 전투가 끝날 때까지 추가 <bul>방어력</bul> 및 <ap>마법 저항력</ap>이 30% 증가합니다.'
        +'<br><br><etc>"그는 많은 이름으로 불렸지. 갑각 투구. 두 번째 피부. 살아 있는 무덤..."</etc>'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '몽상파쇄자' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>60</value><br>공격 속도 <icon>공격 속도</icon> <value>40%</value><br>체력 <icon>체력</icon> <value>600</value></stats>'
        +'<br><br><passive>쪼개기</passive><br>기본 공격 시 대상 주변에 있는 적들에게 <ad>(<ggl><icon>근거리</icon><icon>공격력</icon>40%</ggl> | <ggl><icon>원거리</icon><icon>공격력</icon>20%</ggl>)의 물리 피해</ad>를 입힙니다.'
        +'<br><br><passive>담금질</passive><br><ad>물리 피해</ad>를 입히면 2초 동안 <speed>20의 이동 속도</speed>를 얻습니다.'
        +'<br><br><active>활성화</active> (15초)'
        +'<br><active>파괴의 충격파</active><br><ggl><ad><icon>공격력</icon>80%</ggl>의 물리 피해</ad>를 입히고 주변 적들을 35% <status>둔화</status>시키면 적중당한 챔피언 하나당 <speed>35%의 추가 이동 속도</speed>를 얻습니다. 추가 이동 속도는 3초에 걸쳐 점차 감소합니다. 스킬을 시전하는 동안 이동할 수 있습니다.'
        +'<br><br><rules>구조물에는 <passive>쪼개기</passive>가 발동되지 않습니다.<br>아이템 성능은 <icon>근거리</icon> 근접 챔피언과 <icon>원거리</icon> 원거리 챔피언에게 각각 다르게 적용됩니다.</rules>'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '궁극의 검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>95</value><br>치명타 확률 <icon>치명타 확률</icon> <value>20%</value><br>치명타 피해량 <icon>치명타 피해량</icon> <value>50%</value></stats>'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '무한한 삼위일체' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>55</value><br>공격 속도 <icon>공격 속도</icon> <value>43%</value><br>체력 <icon>체력</icon> <value>400</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value></stats>'
        +'<br><br><passive>주문 검</passive><br>스킬을 사용하고 나면 다음 기본 공격 시 <ad><ggl>기본 <icon>공격력</icon>200%</ggl>의 물리 피해</ad>를 추가로 입힙니다.'
        +'<br><br><passive>가속</passive><br>유닛에게 기본 공격을 가하면 2초 동안 <speed>이동 속도가 20</speed> 상승합니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '라바돈의 죽음왕관' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>190</value></stats>'
        +'<br><br><passive>신비한 작품</passive><br>총 <jml>주문력이 35%</jml> 증가합니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '터.보.추.진.기' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>65</value><br>공격 속도 <icon>공격 속도</icon> <value>35%</value><br>체력 <icon>체력</icon> <value>450</value></stats>'
        +'<br><br><passive>마공학 충전</passive><br>궁극기의 스킬 가속이 30 증가합니다.'
        +'<br><br><passive>폭주</passive> <icon>쿨다운</icon> (30초)<br>궁극기를 사용한 후 8초 동안 <ggsd>30% 공격 속도</ggsd>와 <speed>15%의 이동 속도</speed>를 얻습니다.'
        +'<br><br><etc>군중 제어는 성가신 일이 되기도 하죠.</etc>'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '무한 융합' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>70</value><br>체력 <icon>체력</icon> <value>500</value><br>마나 <icon>마나</icon> <value>550</value></stats>'
        +'<br><br><passive>불멸의 시간</passive><br>60초마다 <chl>체력 20</chl>, <mana>마나 20</mana>, <jml>주문력 4</jml>씩 상승합니다. 최대 10회까지 중첩됩니다. 최대 중첩에 도달하면 레벨이 오릅니다.'
        +'<br><br><passive>영원</passive><br>챔피언에게 피해를 받으면 감소 전 피해량의 7%의 해당하는 <mana>마나</mana>를 회복합니다. 스킬 사용 시 사용한 <mana>마나</mana>의 25%에 해당하는 체력을 회복합니다. 스킬 사용 1회당 초당 최대 <chl>20의 체력</chl>을 회복합니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '다수의 원한' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>110</value><br>마나 <icon>마나</icon> <value>800</value><br>스킬 가속 <icon>스킬 가속</icon> <value>30</value></stats>'
        +'<br><br><passive>경멸</passive><br>궁극기의 스킬 가속이 20 증가합니다.'
        +'<br><br><passive>증오 안개</passive><br>궁극기로 챔피언에게 피해를 입히면 대상 발밑의 지면을 불태워 <ap>(<passive>60</passive> <jml>+ <icon>주문력</icon>5%</jml>)의 마법 피해</ap>를 입히고 <ap>마법 저항력을 10</ap> 감소시킵니다.'
        +'<br><br><rules>입힌 피해량에 따라 반경이 늘어납니다. (최대 반경 550)<br>기본 공격으로 피해를 입히면 증오안개가 발동하지 않습니다.</rules>'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '무기의 위력' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>115</value><br>마나 <icon>마나</icon> <value>950</value><br>스킬 가속 <icon>스킬 가속</icon> <value>30</value></stats>'
        +'<br><br><passive>장전</passive><br>3초마다 <ap>사격 충전</ap> 중첩을 얻습니다. 최대 6회까지 중첩됩니다.'
        +'<br><br><passive>발사</passive><br>스킬로 적에게 피해를 입히면 모든 사격 충전 중첩을 소모하여, 소모한 충전 하나당 대상과 주면 다른 대상 한 명 에게 <ap>(<passive>45</passive> <jml>+ <icon>주문력</icon>4%</jml>)의 추가 마법 피해</ap>를 입힙니다. 사거리 안에 다른 대상이 없을 경우 첫 번째 대상에게 남은 사격 충전 중첩만큼 35%의 피해를 반복해서 입힙니다.'
        +'<br><br><etc>"마법사의 가장 좋은 친구! 오늘 구매하세요!" - 필트오버 상인 (사망한 것으로 추정)</etc>'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '얼어붙은 주먹' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>400</value><br>방어력 <icon>방어력</icon> <value>60</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value></stats>'
        +'<br><br><passive>주문 검</passive><br>스킬을 사용하고 나면 다음 기본 공격 시 추가로 <ggl>기본 <icon>공격력</icon>100%</ggl><ad>의 물리 피해</ad>를 입힙니다. 또한 (<icon>근거리</icon><passive>15%</passive> <chl>+ <icon>체력</icon>0.004%</chl> | <icon>원거리</icon><passive>7.5%</passive> <chl>+ <icon>체력</icon>0.002%</chl>) <status>둔화</status>시키는 서리 영역을 2초 동안 생성합니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '떠도는 희망' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>600</value><br>방어력 <icon>방어력</icon> <value>65</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><passive>고뇌</passive><br>챔피언과 전투 중일 때 7초마다 주변 적 챔피언에게 <ap>(<chl>추가 <icon>체력</icon>3%</chl> <passive>+30 ~ 50<icon>레벨</icon></passive>)의 마법 피해</ap>를 입히고 피해량의 250%만큼 체력을 회복합니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '슈렐리아의 진홍곡' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>70</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value><br>이동 속도 <icon>이동 속도</icon> <value>10%</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>200%</value></stats>'
        +'<br><br><active>활성화</active> (75초)'
        +'<br><active>고무적인 연설</active><br>주변 아군의 <speed>이동 속도를 4초 동안 30%</speed> 상승시킵니다.'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '비명을 지르는 도시의 외침' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>60</value><br>체력 <icon>체력</icon> <value>300</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>175%</value></stats>'
        +'<br><br><passive>영혼 흡수</passive><br>챔피언에게 피해르 입히면 <passive>영혼 파편</passive>을 최대 3개 까지 얻습니다. 아군을 상대로 체력을 회복시키거나 보호막을 씌우면 모든 <passive>영혼 파편</passive>을 소모하여 <hb>체력을 40</hb> 회복하고 가장 가까운 적 챔피언에게 파편 하나당 <ap>45의 마법 피해</ap>를 입힙니다.'
        +"<br><br><etc>'가만히 귀를 기울이면 비명 너머로 부산한 도시의 소리가 여전히 들려옵니다.'</etc>"
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '성운 투척기' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>50</value><br>체력 <icon>체력</icon> <value>300</value><br>스킬 가속 <icon>스킬 가속</icon> <value>25</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>200%</value></stats>'
        +'<br><br><passive>별빛 은총</passive><br>아군을 상대로 체력을 회복시키거나 보호막을 씌우면 (자신을 제외하고) 가장 가까이 있는 아군 챔피언에게 연쇄 효과가 적용되며 기존 수치의 <hb>40%</hb>만큼 체력을 회복시키거나 <ap>45%</ap>만큼 피해를 흡수하는 보호막을 부여합니다.'
        +'<br><br><rules>근처에 아군이 없으면 같은 대상을 상대로 기존 수치에 <hb>30%</hb>만큼 회복시키거나 <ap>35%</ap>만큼 피해를 흡수하는 보호막을 부여합니다.</rules>'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '황금 새벽의 유물함' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>350</value><br>방어력 <icon>방어력</icon> <value>40</value><br>마법 저항력 <icon>마법 저항력</icon> <value>40</value><br>스킬 가속 <icon>스킬 가속</icon> <value>20</value></stats>'
        +'<br><br><active>활성화</active> (90초)<br><active>헌신</active><br>주변 아군들에게 <ap>200~360(<passive>아군 <icon>레벨</icon></passive>)의 피해르 흡수하는 보호막</ap>을 부여합니다. 보호막 피해 흡수량은 2.5초에 걸쳐 점차 감소합니다.'
        +'<br><br><rules>레벨 비례 효과는 아군의 레벨에 따라 상승합니다.<br>20초 안에 <active>헌신</active> 보호막을 연속을 사용하면 25%의 효과만 적용됩니다.</rules>'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :
        v.name == '해오름' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>60</value><br>스킬 가속 <icon>스킬 가속</icon> <value>30</value><br>기본 마나 재생 <icon>기본 마나 재생</icon> <value>225%</value></stats>'
        +'<br><br><passive>태초의 빛</passive><br><mana>기본 마나 재생 100%당</mana> <hb>체력 회복 및 보호막 효과가 3%</hb>, <jml>주문력이 5</jml> 증가합니다.'
        +'<br><br><passive>광휘</passive><br>소환사 주문 가속이 18 증가합니다.'
        +'<br><br><etc>이 세상의 모든 힘은 별에서 왔다고 합니다.</etc>'
        +'<br><br><ornn>오른이 아군일 경우에만 가능</ornn></maintext>' :



        v.name == '수호자의 보주' ? v.description = '<maintext><stats>주문력 <icon>주문력</icon> <value>50</value><br>체력 <icon>체력</icon> <value>150</value></stats>'
        +'<br><br><ul><li><passive>회복:</passive> 5초마다 <mana>10의 마나</mana>를 회복합니다. 마나를 획득할 수 없으면 <hb>15의 체력</hb>을 회복합니다.</li></ul></maintext>' :
        v.name == '수호자의 검' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>30</value><br>체력 <icon>체력</icon> <value>150</value><br>스킬 가속 <icon>스킬 가속</icon> <value>15</value></stats></maintext>' :
        v.name == '수호자의 망치' ? v.description = '<maintext><stats>공격력 <icon>공격력</icon> <value>25</value><br>체력 <icon>체력</icon> <value>150</value><br>생명력 흡수 <icon>생명력 흡수</icon> <value>7%</value></stats></maintext>' :
        v.name == '수호자의 뿔피리' ? v.description = '<maintext><stats>체력 <icon>체력</icon> <value>150</value></stats>'
        +'<br><br><ul><li><passive>회복:</passive> 5초마다 <hb>체력을 20</hb> 회복합니다.</li><li><passive>불굴의 의지:</passive> 적 챔피언의 기본 공격과 스킬 공격 피해량을 15만큼 막아줍니다. (지속 피해 스킬의 경우 25%의 효과)</li></ul></maintext>' :
        
        v.description = 'description error'
    })} 
    {all.map(v=>{
        v.name == '마나무네' ? v.into = ['3042'] : undefined
        v.name == '대천사의 지팡이' ? v.into = ['3040']: undefined
        v.name == '혹한의 손길' ? v.into = ['3121'] : undefined
    })}
    function Item({name}) {
        return <div className="inline-block">
            {all.map((v,i)=>
                    v.name == name ? i < 345 && i != 66 ? 
                    <Popover> 
                        <PopoverTrigger>
                            <img className="w-[50px] h-[50px] m-[6px] rounded-md inline-block hover:brightness-50 hover:p-[2px] [cursor:pointer]" src={`/image/item/${v.image['full'].replace('png','jpg')}`} alt={v.name + i}/>
                        </PopoverTrigger>
                        <PopoverContent bg={'#061118'} w={'auto'} minW={'300px'} maxW={'400px'} borderColor={'#45432a'} borderWidth={'2px'}>
                            <PopoverArrow bg={'#061118'}/>
                            <PopoverHeader borderColor={'#45432a'} borderBottomWidth={'2px'} p={'5px'} maxH={'60px'} h={'auto'} display={'flex'}>
                                <Image w={'45px'} h={'45px'} mr={'5px'} src={`/image/item/${v.image['full'].replace('png','jpg')}`}/>
                                <Text w={'auto'} display={'inline-block'}>
                                    <Text color={'#e6ddc9'}>{v.name}</Text>
                                    <Image w={'15px'} display={'inline-block'} transform={'translateY(-10%)'} mr={'5px'} src={"/image/icon/골드.jpg"} alt='골드'/>
                                    <Text color={"#c7ab6e"} display={'inline-block'}>{onoff ? v.gold['total'] : <>{v.gold['sell']}<div className="text-[#50504d] inline-block">(= 판매가)</div></>}</Text>
                                </Text>
                            </PopoverHeader>
                            <PopoverBody color={'#e6ddc9'} p={'5px'} fontSize={'0.9rem'} borderColor={'#45432a'} borderBottomWidth={'2px'} overflow={'hidden'} position={'relative'}>      
                                {onoff 
                                ? <div dangerouslySetInnerHTML={{ __html: v.description
                                    .replaceAll('<icon>공격력</icon>','<icon><img src="/image/icon/공격력.jpg"/></icon>')
                                    .replaceAll('<icon>주문력</icon>','<icon><img src="/image/icon/주문력.jpg"/></icon>')
                                    .replaceAll('<icon>공격 속도</icon>','<icon><img src="/image/icon/공격_속도.jpg"/></icon>')
                                    .replaceAll('<icon>치명타 확률</icon>','<icon><img src="/image/icon/치명타_확률.jpg"/></icon>')
                                    .replaceAll('<icon>마법 관통력</icon>','<icon><img src="/image/icon/마법_관통력.jpg"/></icon>')
                                    .replaceAll('<icon>물리 관통력</icon>','<icon><img src="/image/icon/물리_관통력.jpg"/></icon>')
                                    .replaceAll('<icon>방어력</icon>','<icon><img src="/image/icon/방어력.jpg"/></icon>')
                                    .replaceAll('<icon>마법 저항력</icon>','<icon><img src="/image/icon/마법_저항력.jpg"/></icon>')
                                    .replaceAll('<icon>기본 체력 재생</icon>','<icon><img src="/image/icon/기본_체력_재생.jpg"/></icon>')
                                    .replaceAll('<icon>체력</icon>','<icon><img src="/image/icon/체력.jpg"/></icon>')
                                    .replaceAll('<icon>기본 마나 재생</icon>','<icon><img src="/image/icon/기본_마나_재생.jpg"/></icon>')
                                    .replaceAll('<icon>마나</icon>','<icon><img src="/image/icon/마나.jpg"/></icon>')
                                    .replaceAll('<icon>스킬 가속</icon>','<icon><img src="/image/icon/스킬_가속.jpg"/></icon>')
                                    .replaceAll('<icon>이동 속도</icon>','<icon><img src="/image/icon/이동_속도.jpg"/></icon>')
                                    .replaceAll('<icon>강인함</icon>','<icon><img src="/image/icon/강인함.jpg"/></icon>')
                                    .replaceAll('<icon>생명력 흡수</icon>','<icon><img src="/image/icon/생명력_흡수.jpg"/></icon>')
                                    .replaceAll('<icon>근거리</icon>','<icon><img src="/image/icon/근거리.jpg"/></icon>')
                                    .replaceAll('<icon>원거리</icon>','<icon><img src="/image/icon/원거리.jpg"/></icon>')
                                    .replaceAll('<icon>레벨</icon>','<icon><img src="/image/icon/레벨.jpg"/></icon>')
                                    .replaceAll('<icon>골드</icon>','<icon><img src="/image/icon/골드.jpg"/></icon>')
                                    .replaceAll('<icon>사용 시</icon>','<icon2><img src="/image/icon/사용_시.jpg"/></icon2>')
                                    .replaceAll('<icon>적중 시</icon>','<icon2><img src="/image/icon/적중_시.jpg"/></icon2>')
                                    .replaceAll('<icon>쿨다운</icon>','<icon2><img src="/image/icon/쿨다운.jpg"/></icon2>')
                                    .replaceAll('<icon>체력 회복 및 보호막</icon>','<icon2><img src="/image/icon/체력_회복_및_보호막.jpg"/></icon2>')
                                    .replaceAll('<icon>치명타 피해량</icon>','<icon2><img src="/image/icon/치명타_피해량.jpg"/></icon2>')
                                    .replace('<passive>주문 검</passive>','<passive>주문 검</passive> <icon2><img src="/image/icon/쿨다운.jpg"/></icon2> (1.5초)')
                                    .replace(v.name != '자자크의 셰계가시' || v.name != '피의 노래' || v.name != '태양의 썰매' || v.name != '꿈 생성기' || v.name != '천상의 이의'? '<active>활성화</active>'  
                                    : undefined,'<icon2><img src="/image/icon/사용_시.jpg"/></icon2> <active>활성화</active> <icon2><img src="/image/icon/쿨다운.jpg"/></icon2>')
                                }}></div>
                                : <>
                                    <div className="pb-[5px] border-b-2 border-[#45432a]">
                                        <Swiper
                                            modules={[Navigation]}
                                            spaceBetween={5}
                                            slidesPerView={8}
                                            >
                                            {v.into ? v.into.map(v=>
                                            v == '3005' || v == '6656' || v == '6671' || v == '223057' || v == '4003' ? undefined:
                                            <SwiperSlide><Image w={'35px'} src={`/image/item/${v}.jpg`} alt={v}/></SwiperSlide>  
                                            ):undefined}
                                        </Swiper>
                                    </div>
                                    <div className="flex pt-[5px] w-full"><img className="w-[35px] m-[auto]" src={`/image/item/${v.image['full'].replace('png','jpg')}`} alt={v.name}/></div>
                                    {v.from ? <div className="flex pt-[5px] w-full">{v.from.map(v=><img className="w-[35px] m-[auto]" src={`/image/item/${v}.jpg`}/>)}</div> : undefined}
                                </>
                                    
                                } 
                            </PopoverBody>
                            <PopoverFooter border={'0px'} textAlign={'right'}>
                                <Button w={'20px'} h={'20px'} bg={'#50504d'} p={'5px'} onClick={() => setonoff(!onoff)}>
                                    <RepeatIcon color={"#ffe284"}/>
                                </Button>
                            </PopoverFooter>
                        </PopoverContent>
                    </Popover>
                    
                    : undefined : undefined)}
            </div>
    }
    return  <>
            {checkedItems[0] ? <><div className="w-[100%] font-bold ml-[6px]">장화</div>
                <Item name='장화'/>
                <Item name='신속의 장화'/>
                <Item name='명석함의 아이오니아 장화'/>
                <Item name='기동력의 장화'/>
                <Item name='광전사의 군화'/>
                <Item name='마법사의 신발'/>
                <Item name='판금 장화'/>
                <Item name='헤르메스의 발걸음'/>
            </> : undefined}
            {checkedItems[1] ? <><div className="w-[100%] font-bold ml-[6px]">시작</div>
                    <Item name='도란의 반지'/>
                    <Item name='도란의 검'/>
                    <Item name='도란의 방패'/>
                    <Item name='새끼 화염발톱'/>
                    <Item name='새끼 바람돌이'/>
                    <Item name='새끼 이끼쿵쿵이'/>
                    <Item name='세계 지도집'/>
                    <Item name='암흑의 인장'/>
                    <Item name='여신의 눈물'/>
                    <Item name='수확의 낫'/>
            </> : undefined}
            {checkedItems[2] ? <><div className="w-[100%] font-bold ml-[6px]">기본</div>
                 <Item name='빛나는 티끌'/>
                 <Item name='요정의 부적'/>
                 <Item name='단검'/>
                 <Item name='천 갑옷'/>
                 <Item name='원기 회복의 구슬'/>
                 <Item name='사파이어 수정'/>
                 <Item name='롱소드'/>
                 <Item name='증폭의 고서'/>
                 <Item name='루비 수정'/>
                 <Item name='마법무효화의 망토'/>
                 <Item name='민첩성의 망토'/>
                 <Item name='방출의 마법봉'/>
                 <Item name='곡괭이'/>
                 <Item name='쓸데없이 큰 지팡이'/>
                 <Item name='B.F. 대검'/>
             </> : undefined}
            {checkedItems[3] ? <><div className="w-[100%] font-bold ml-[6px]">서사</div>
                <Item name='처형인의 대검'/>
                <Item name='흡혈의 낫'/>
                <Item name='광휘의 검'/>
                <Item name='콜필드의 전투 망치'/>
                <Item name='탐식의 망치'/>
                <Item name='땅굴 채굴기'/>
                <Item name='티아맷'/>
                <Item name='강철 인장'/>
                <Item name='주문포식자'/>
                <Item name='곡궁'/>
                <Item name='키르히아이스의 파편'/>
                <Item name='열정의 검'/>
                <Item name='온기가 필요한 자의 도끼'/>
                <Item name='절정의 화살'/>
                <Item name='수은 장식띠'/>
                <Item name='최후의 속삭임'/>
                <Item name='꽁지깃'/>
                <Item name='톱날 단검'/>
                <Item name='야수화'/>
                <Item name='망각의 구'/>
                <Item name='에테르 환영'/>
                <Item name='악마의 마법서'/>
                <Item name='마법공학 교류 발전기'/>
                <Item name='역병의 보석'/>
                <Item name='사라진 양피지'/>
                <Item name='억겁의 카탈리스트'/>
                <Item name='기괴한 가면'/>
                <Item name='추적자의 팔목 보호대'/>
                <Item name='신록의 장벽'/>
                <Item name='점화석'/>
                <Item name='쇠사슬 조끼'/>
                <Item name='덤불 조끼'/>
                <Item name='수정 팔 보호구'/>
                <Item name='비상의 월갑'/>
                <Item name='얼음 방패'/>
                <Item name='음전자 망토'/>
                <Item name='거인의 허리띠'/>
                <Item name='파수꾼의 갑옷'/>
                <Item name='바미의 불씨'/>
                <Item name='망령의 두건'/>
                <Item name='금지된 우상'/>
                <Item name='밴들유리 거울'/>
                <Item name='감시하는 와드석'/>
            </> : undefined}
            {checkedItems[4] ? <><div className="w-[100%] font-bold ml-[6px]">전설</div>
                <Item name='마법사의 최후'/>
                <Item name='월식'/>
                <Item name='맬모셔스의 아귀'/>
                <Item name='화공 펑크 사슬검'/>
                <Item name='마나무네'/>
                <Item name='실험적 마공학판'/>
                <Item name='선체파괴자'/>
                <Item name='칠흑의 양날 도끼'/>
                <Item name='스테락의 도전'/>
                <Item name='쇼진의 창'/>
                <Item name='갈라진 하늘'/>
                <Item name='몰락한 왕의 검'/>
                <Item name='죽음의 무도'/>
                <Item name='수호 천사'/>
                <Item name='굶주린 히드라'/>
                <Item name='거대한 히드라'/>
                <Item name='발걸음 분쇄기'/>
                <Item name='삼위일체'/>
                <Item name='스태틱의 단검'/>
                <Item name='루난의 허리케인'/>
                <Item name='유령 무희'/>
                <Item name='구인수의 격노검'/>
                <Item name='징수의 총'/>
                <Item name='크라켄 학살자'/>
                <Item name='고속 연사포'/>
                <Item name='정수 약탈자'/>
                <Item name='불멸의 철갑궁'/>
                <Item name='헤르메스의 시미터'/>
                <Item name='필멸자의 운명'/>
                <Item name='도미닉 경의 인사'/>
                <Item name='경계'/>
                <Item name='폭풍갈퀴'/>
                <Item name='무한의 대검'/>
                <Item name='나보리 신속검'/>
                <Item name='피바라기'/>
                <Item name='독사의 송곳니'/>
                <Item name='그림자 검'/>
                <Item name='요우무의 유령검'/>
                <Item name='기회'/>
                <Item name='밤의 끝자락'/>
                <Item name='벼락폭풍검'/>
                <Item name='오만'/>
                <Item name='원칙의 원형낫'/>
                <Item name='불경한 히드라'/>
                <Item name='세릴다의 원한'/>
                <Item name='메자이의 영혼약탈자'/>
                <Item name='모렐로노미콘'/>
                <Item name='마법공학 로켓 벨트'/>
                <Item name='영겁의 지팡이'/>
                <Item name='라일라이의 수정홀'/>
                <Item name='지평선의 초점'/>
                <Item name='악의'/>
                <Item name='무덤꽃'/>
                <Item name='폭풍 쇄도'/>
                <Item name='루덴의 동반자'/>
                <Item name='대천사의 지팡이'/>
                <Item name='내셔의 이빨'/>
                <Item name='리안드리의 고통'/>
                <Item name='우주의 추진력'/>
                <Item name='균열 생성기'/>
                <Item name='공허의 지팡이'/>
                <Item name='밴시의 장막'/>
                <Item name='리치베인'/>
                <Item name='그림자불꽃'/>
                <Item name='존야의 모래시계'/>
                <Item name='라바돈의 죽음모자'/>
                <Item name='지크의 융합'/>
                <Item name='얼어붙은 심장'/>
                <Item name='혹한의 손길'/>
                <Item name='심연의 가면'/>
                <Item name='증오의 사슬'/>
                <Item name='얼어붙은 건틀릿'/>
                <Item name='가시 갑옷'/>
                <Item name='란두인의 예언'/>
                <Item name='태양불꽃 방패'/>
                <Item name='끝없는 절망'/>
                <Item name='대자연의 힘'/>
                <Item name='공허한 광휘'/>
                <Item name='정령의 형상'/>
                <Item name='케이닉 루컨'/>
                <Item name='망자의 갑옷'/>
                <Item name='강철심장'/>
                <Item name='워모그의 갑옷'/>
                <Item name='해신 작쇼'/>
                <Item name='자자크의 세계가시'/>
                <Item name='피의 노래'/>
                <Item name='태양의 썰매'/>
                <Item name='꿈 생성기'/>
                <Item name='천상의 이의'/>
                <Item name='슈렐리아의 군가'/>
                <Item name='헬리아의 메아리'/>
                <Item name='월석 재생기'/>
                <Item name='기사의 맹세'/>
                <Item name='강철의 솔라리 펜던트'/>
                <Item name='제국의 명령'/>
                <Item name='불타는 향로'/>
                <Item name='흐르는 물의 지팡이'/>
                <Item name='구원'/>
                <Item name='미카엘의 축복'/>
                <Item name='경계의 와드석'/>
                <Item name='개척자'/>
                <Item name='새벽심장'/>
            </> : undefined}
            {checkedItems[5] ? <><div className="w-[100%] font-bold ml-[6px]">소모품</div>
                <Item name='체력 물약'/>
                <Item name='충전형 물약'/>
                <Item name='부패 물약'/>
                <Item name='투명 와드'/>
                <Item name='예언자의 렌즈'/>
                <Item name='망원형 개조'/>
                <Item name='마법의 영약'/>
                <Item name='분노의 영약'/>
                <Item name='강철의 영약'/>
                <Item name='제어 와드'/>
            </> : undefined}
            {checkedItems[6] ? <><div className="w-[100%] font-bold ml-[6px]">여눈</div>
                <Item name='무라마나'/>
                <Item name='대천사의 포옹'/>
                <Item name='종말의 겨울'/>
            </> : undefined}
            {checkedItems[7] ? <><div className="w-[100%] font-bold ml-[6px]">오른</div>
                <Item name='천제 정렬'/>
                <Item name='터.보.추.진.기'/>
                <Item name='흑요석 양날 도끼'/>
                <Item name='몽상파쇄자'/>
                <Item name='쇼진의 결의'/>
                <Item name='천상의 몰락'/>
                <Item name='무한한 삼위일체'/>
                <Item name='들끓는 슬픔'/>
                <Item name='쓰러진 용의 제물'/>
                <Item name='폭풍의 눈'/>
                <Item name='궁극의 검'/>
                <Item name='요우무의 각성'/>
                <Item name='확실성'/>
                <Item name='선풍검'/>
                <Item name='영혼의 평정'/>
                <Item name='업그레이드 비행팩'/>
                <Item name='무한 융합'/>
                <Item name='다수의 원한'/>
                <Item name='무기의 위력'/>
                <Item name='남작의 선물'/>
                <Item name='리안드리의 슬픔'/>
                <Item name='이케시아의 저주'/>
                <Item name='라바돈의 죽음왕관'/>
                <Item name='얼어붙은 주먹'/>
                <Item name='떠도는 희망'/>
                <Item name='레비아탄'/>
                <Item name='무언의 기생갑'/>
                <Item name='슈렐리아의 진혼곡'/>
                <Item name='비명을 지르는 도시의 외침'/>
                <Item name='성운 투척기'/>
                <Item name='황금 새벽의 유물함'/>
                <Item name='해오름'/>
            </> : undefined}
            {checkedItems[8] ? <><div className="w-[100%] font-bold ml-[6px]">칼바람</div>
                <Item name='수호자의 뿔피리'/>
                <Item name='수호자의 망치'/>
                <Item name='수호자의 보주'/>
                <Item name='수호자의 검'/>
            </> : undefined}</>
}
/* <div>{v.from ? v.from.map(v=><img className="w-[40px]" src={`/image/item/${v}.jpg`}/>) :undefined}</div> */