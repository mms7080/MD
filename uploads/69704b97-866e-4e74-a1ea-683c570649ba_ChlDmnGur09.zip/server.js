import express from 'express';
import session from 'express-session';
import redis from 'redis';
import connectRedis from 'connect-redis';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import passport from 'passport'
import multer from 'multer';
import sirv from 'sirv';
import compression from 'compression';
import fs from 'fs';

dotenv.config({path:'./.env',encoding:"UTF-8"});
const app = express({xPoweredBy:false});
app.set('view engine', 'ejs');
app.set('views', 'src/views');



const templateBuild = 
    fs.readFileSync('./dist/client/index.html',{encoding:'utf-8'});
const ssrManifest = 
    fs.readFileSync('./dist/client/.vite/ssr-manifest.json',{encoding:'utf-8'});
const renderBuild = 
    (await import('./dist/server/index-server.js')).render;

app.use('/', compression())
app.use('/', sirv('./dist/client',{extensions:[]}));

app.use('/image', express.static('image',{
    dotfiles:'ignore',
    extensions:[],
    fallthrough:true,
    immutable:false,
    index:false,
    redirect:false
}))
app.use('/', async (req,res,next)=>{
    try{
        const url = req.originalUrl.replace('/',"");
        let template = 
            templateBuild;
        let render = 
            renderBuild;
        res.status(200).set({'Content-Type':'text/html'}).send(
            template.replace(
                '<!--root-container-->',
                (await render(url, ssrManifest)).html
            )
        )
    } catch(e) {next(new Error('react'))}
})




app.listen(3000,()=>{
    console.log('Port ' + 3000 + ' server open!');
})